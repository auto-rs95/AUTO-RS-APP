-- ============================================================
-- MIGRATION 2 — Créneaux RDV + statut véhicule public
-- À exécuter dans Supabase > SQL Editor > New query
-- (s'ajoute au schema.sql déjà exécuté, ne le remplace pas)
-- ============================================================

-- ---------- CRÉNEAUX DE RENDEZ-VOUS (déclarés par toi, réservés par le client) ----------
create table availability_slots (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  date date not null,
  heure text not null,
  reserve boolean default false,
  reserve_par_nom text,
  reserve_par_telephone text,
  appointment_id uuid references appointments(id) on delete set null,
  created_at timestamptz default now()
);

alter table availability_slots enable row level security;

create policy "owner_full_access_slots" on availability_slots for all using (auth.uid() = owner_id);
create policy "public_read_slots" on availability_slots for select using (true);

create index idx_slots_owner on availability_slots(owner_id);
create index idx_slots_date on availability_slots(date);

-- Fonction sécurisée : réserve un créneau seulement s'il est encore libre.
-- Évite qu'un créneau soit pris en double si deux clients cliquent en même temps.
create or replace function reserve_slot(
  slot_id uuid,
  nom text,
  telephone text
) returns boolean
language plpgsql
security definer
as $$
declare
  updated_count int;
begin
  update availability_slots
  set reserve = true, reserve_par_nom = nom, reserve_par_telephone = telephone
  where id = slot_id and reserve = false;
  get diagnostics updated_count = row_count;
  return updated_count > 0;
end;
$$;

grant execute on function reserve_slot to anon, authenticated;

-- ---------- STATUT VÉHICULE VISIBLE SUR LE SITE PUBLIC ----------
-- 'disponible' (point vert) | 'preparation' (point orange) | 'vendu' (point rouge, bloqué)
alter table vehicles add column if not exists statut_vente text default 'disponible';

-- ---------- TEXTE À PROPOS (si pas déjà ajouté par une migration précédente) ----------
alter table company add column if not exists a_propos_texte text;
