-- ============================================================
-- AUTO RS MULTI SERVICES — Schéma Supabase
-- À exécuter dans Supabase > SQL Editor > New query
-- ============================================================

-- Extension pour générer des UUID
create extension if not exists "uuid-ossp";

-- ---------- VÉHICULES (Achat / Revente) ----------
create table vehicles (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  marque text,
  modele text,
  plaque text,
  carburant text,
  boite text,
  kilometrage integer,
  date_achat date,
  date_vente date,
  prix_achat numeric default 0,
  prix_vente numeric,
  statut text default 'reparation',
  statut_vente text default 'disponible', -- 'disponible' | 'preparation' | 'vendu' (site public)
  acheteur_nom text,
  acheteur_contact text,
  remarques text,
  photos jsonb default '[]'::jsonb,
  photo_principale_idx integer,
  documents jsonb default '{}'::jsonb,
  depenses jsonb default '[]'::jsonb,
  ordre bigint,
  -- Visibilité publique pour le site vitrine (vente de véhicules)
  publie boolean default false,
  created_at timestamptz default now()
);

-- ---------- CLIENTS & PRESTATIONS ----------
create table clients (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  nom text,
  telephone text,
  adresse text,
  vehicule_marque text,
  vehicule_modele text,
  plaque text,
  kilometrage integer,
  remarques text,
  interventions jsonb default '[]'::jsonb,
  created_at timestamptz default now()
);

-- ---------- STOCK PIÈCES ----------
create table stock (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  reference text,
  designation text,
  quantite integer default 0,
  created_at timestamptz default now()
);

-- ---------- AGENDA (rendez-vous) ----------
create table appointments (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  date date,
  heure text,
  client_nom text,
  client_telephone text,
  adresse text,
  vehicule_info text,
  type_prestation text,
  notes text,
  statut text default 'prevu',
  -- Champs pour les RDV pris depuis le site public
  source text default 'interne', -- 'interne' | 'site_public'
  type_demande text, -- 'reparation' | 'visite_achat'
  symptomes jsonb default '[]'::jsonb,
  lien_annonce text,
  distance_km numeric,
  frais_deplacement numeric,
  valide boolean default false, -- false = en attente de validation par toi
  created_at timestamptz default now()
);

-- ---------- DEVIS & FACTURES ----------
create table quotes (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  numero text,
  type text default 'prestationMecanique',
  statut text default 'devis',
  paiement_statut text default 'nonPaye',
  date date,
  client_nom text,
  client_telephone text,
  client_email text,
  vehicule_marque text,
  vehicule_modele text,
  plaque text,
  kilometrage integer,
  lignes jsonb default '[]'::jsonb,
  notes text,
  -- Champs pour les demandes de devis venant du site public
  source text default 'interne',
  categorie_panne text[],
  description_libre text,
  photos jsonb default '[]'::jsonb,
  traite boolean default false,
  created_at timestamptz default now()
);

-- ---------- PRESTATIONS LIBRES (bibliothèque réutilisable) ----------
create table prestations_libres (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  libelle text,
  montant_ttc numeric default 0,
  created_at timestamptz default now()
);

-- ---------- GALERIE (réalisations passées, visible publiquement) ----------
create table gallery (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  photo text not null, -- image base64
  legende text,
  ordre bigint,
  created_at timestamptz default now()
);

-- ---------- INFOS SOCIÉTÉ ----------
create table company (
  id uuid primary key default uuid_generate_v4(),
  owner_id uuid not null default auth.uid(),
  nom text,
  siret text,
  siren text,
  tva text,
  forme text,
  adresse text,
  dirigeant text,
  taux_tva numeric default 20,
  logo text,
  adresse_base text default 'Argenteuil', -- pour le calcul de déplacement
  km_offerts numeric default 7,
  tarif_par_km numeric default 2,
  a_propos_texte text
);

-- ============================================================
-- SÉCURITÉ (Row Level Security)
-- Principe : toi (propriétaire connecté) as accès total à tes données.
-- Le public (client non connecté) ne peut QUE :
--   - lire les véhicules marqués "publié" (vente de véhicules)
--   - créer des demandes de RDV / devis (jamais les lire ni les modifier)
-- ============================================================

alter table vehicles enable row level security;
alter table clients enable row level security;
alter table stock enable row level security;
alter table appointments enable row level security;
alter table quotes enable row level security;
alter table prestations_libres enable row level security;
alter table company enable row level security;
alter table gallery enable row level security;

-- Toi : accès total à tes propres données
create policy "owner_full_access_vehicles" on vehicles for all using (auth.uid() = owner_id);
create policy "owner_full_access_clients" on clients for all using (auth.uid() = owner_id);
create policy "owner_full_access_stock" on stock for all using (auth.uid() = owner_id);
create policy "owner_full_access_appointments" on appointments for all using (auth.uid() = owner_id);
create policy "owner_full_access_quotes" on quotes for all using (auth.uid() = owner_id);
create policy "owner_full_access_prestations" on prestations_libres for all using (auth.uid() = owner_id);
create policy "owner_full_access_company" on company for all using (auth.uid() = owner_id);
create policy "owner_full_access_gallery" on gallery for all using (auth.uid() = owner_id);

-- Public : lecture de la galerie (réalisations passées)
create policy "public_read_gallery" on gallery for select using (true);

-- Public : lecture des véhicules publiés uniquement (site vitrine)
create policy "public_read_published_vehicles" on vehicles for select using (publie = true);

-- Public : création de demandes de RDV (sans lecture ni modification possible)
create policy "public_insert_appointments" on appointments for insert with check (source = 'site_public');

-- Public : création de demandes de devis (sans lecture ni modification possible)
create policy "public_insert_quotes" on quotes for insert with check (source = 'site_public');

-- ============================================================
-- Index utiles pour les performances
-- ============================================================
create index idx_vehicles_owner on vehicles(owner_id);
create index idx_vehicles_publie on vehicles(publie) where publie = true;
create index idx_clients_owner on clients(owner_id);
create index idx_appointments_owner on appointments(owner_id);
create index idx_appointments_date on appointments(date);
create index idx_quotes_owner on quotes(owner_id);
