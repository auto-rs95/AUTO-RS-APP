import React, { useState } from 'react';
import { Lock, AlertCircle } from 'lucide-react';
import { supabase } from './supabaseClient.js';

export default function LoginScreen({ onLoggedIn }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    if (!email.trim() || !password) return;
    setLoading(true);
    setError('');
    const { error: authError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    setLoading(false);
    if (authError) {
      setError('Email ou mot de passe incorrect.');
      return;
    }
    onLoggedIn();
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center px-6">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-3 mb-8 justify-center">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#e8c25a] to-[#a8791a] flex items-center justify-center shrink-0 shadow-lg shadow-black/30">
            <span className="font-display text-[#0a0a0a] text-lg font-black tracking-tighter">RS</span>
          </div>
          <div>
            <h1 className="font-display text-xl text-[#f2eee4] leading-tight">AUTO RS</h1>
            <p className="text-[10px] text-[#a89a6e] uppercase tracking-[0.15em] font-medium">Multi Services</p>
          </div>
        </div>

        <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-5">
            <Lock size={16} className="text-[#d4a72c]" />
            <h2 className="font-display text-base text-[#f2eee4]">Espace administrateur</h2>
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-[#2a1a16] border border-[#4d2d28] text-[#e8c8c2] text-sm rounded-lg px-3 py-2.5 mb-4">
              <AlertCircle size={14} className="shrink-0" />
              {error}
            </div>
          )}

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-[#8a8478] mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                className="input"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#8a8478] mb-1.5">Mot de passe</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                className="input"
              />
            </div>
            <button
              onClick={handleLogin}
              disabled={!email.trim() || !password || loading}
              className="w-full bg-[#d4a72c] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3 mt-2"
            >
              {loading ? 'Connexion…' : 'Se connecter'}
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Oswald:wght@500;600;700&display=swap');
        .font-display { font-family: 'Oswald', system-ui, sans-serif; font-weight: 600; letter-spacing: -0.01em; }
        .input { width: 100%; background: #1c1a14; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; font-family: 'Inter', system-ui, sans-serif; }
        .input:focus { border-color: #d4a72c; }
      `}</style>
    </div>
  );
}
