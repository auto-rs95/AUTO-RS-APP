import React, { useState } from 'react';
import { ChevronLeft, Plus, X, Trash2, Search, Minus, Package } from 'lucide-react';
import { newStockItem, uid } from './data.js';

export default function StockSpace({ stock, onUpdateAll, onBack }) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');

  function addItem(data) {
    onUpdateAll([newStockItem(data), ...stock]);
    setShowForm(false);
  }

  function updateQty(id, delta) {
    onUpdateAll(stock.map((s) => (s.id === id ? { ...s, quantite: Math.max(0, (Number(s.quantite) || 0) + delta) } : s)));
  }

  function deleteItem(id) {
    onUpdateAll(stock.filter((s) => s.id !== id));
  }

  const filtered = stock.filter((s) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return s.reference.toLowerCase().includes(q) || s.designation.toLowerCase().includes(q);
  });

  return (
    <div className="max-w-2xl mx-auto pb-28">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="font-display text-xl text-[#f2eee4]">Stock pièces</h1>
          <p className="text-[12px] text-[#8a8478]">{stock.length} référence{stock.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div className="px-5">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6458]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher référence, désignation…"
            className="w-full bg-[#16140f] border border-[#2a2620] rounded-xl pl-9 pr-9 py-2.5 text-sm text-[#f2eee4] outline-none focus:border-[#8a8478]"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6a6458]">
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      <div className="px-5 pt-4 space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
              <Package size={20} className="text-[#4a4438]" />
            </div>
            <p className="text-[#8a8478] text-sm">{stock.length > 0 ? 'Aucun résultat.' : 'Stock vide pour l\'instant.'}</p>
          </div>
        ) : (
          filtered.map((item) => {
            const qty = Number(item.quantite) || 0;
            const isLow = qty <= 2;
            return (
              <div key={item.id} className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-[#f2eee4] truncate">{item.designation || 'Sans nom'}</p>
                  <p className="font-mono text-[11px] text-[#6a6458] mt-0.5">{item.reference || '—'}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => updateQty(item.id, -1)} className="w-7 h-7 rounded-lg bg-[#1c1a14] border border-[#2a2620] flex items-center justify-center text-[#8a8478]">
                    <Minus size={13} />
                  </button>
                  <span className={`font-mono text-sm font-semibold w-6 text-center ${isLow ? 'text-[#d97a6c]' : 'text-[#f2eee4]'}`}>{qty}</span>
                  <button onClick={() => updateQty(item.id, 1)} className="w-7 h-7 rounded-lg bg-[#1c1a14] border border-[#2a2620] flex items-center justify-center text-[#8a8478]">
                    <Plus size={13} />
                  </button>
                  <button onClick={() => deleteItem(item.id)} className="text-[#5a5448] ml-1"><Trash2 size={15} /></button>
                </div>
              </div>
            );
          })
        )}
      </div>

      <button
        onClick={() => setShowForm(true)}
        className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#8a8478] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
        aria-label="Ajouter une pièce"
      >
        <Plus size={26} strokeWidth={2.5} />
      </button>

      {showForm && <StockForm onClose={() => setShowForm(false)} onSubmit={addItem} />}
    </div>
  );
}

function StockForm({ onClose, onSubmit }) {
  const [reference, setReference] = useState('');
  const [designation, setDesignation] = useState('');
  const [quantite, setQuantite] = useState(1);

  function submit() {
    if (!designation.trim()) return;
    onSubmit({ reference: reference.trim(), designation: designation.trim(), quantite: Number(quantite) || 0 });
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={onClose}>
      <div className="bg-[#16140f] border-t sm:border border-[#2a2620] rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 pb-7" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-[#f2eee4]">Nouvelle pièce</h3>
          <button onClick={onClose} className="text-[#8a8478]"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <Field label="Désignation">
            <input value={designation} onChange={(e) => setDesignation(e.target.value)} placeholder="Plaquettes de frein avant" className="input" autoFocus />
          </Field>
          <Field label="Référence (optionnel)">
            <input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="REF-12345" className="input font-mono" />
          </Field>
          <Field label="Quantité en stock">
            <input type="number" inputMode="numeric" value={quantite} onChange={(e) => setQuantite(e.target.value)} className="input font-mono" />
          </Field>
          <button
            onClick={submit}
            disabled={!designation.trim()}
            className="w-full bg-[#8a8478] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3 mt-2"
          >
            Ajouter au stock
          </button>
        </div>
        <style>{`
          .input { width: 100%; background: #1c1a14; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
          .input:focus { border-color: #8a8478; }
          .input::placeholder { color: #5a5448; }
        `}</style>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}
