import React, { useState, useRef } from 'react';
import {
  ChevronLeft, Plus, Search, X, Edit3, Trash2, Calendar, Gauge, Receipt, Phone, Star, Clock, MapPin, PhoneCall,
} from 'lucide-react';
import {
  newClient, newIntervention, computeClientTotals, computeInterventionTotal, isClientFidele, revisionSuggestion,
  formatEUR, formatEURPrecise, formatDate, formatKm, todayISO, uid, wazeLink, telLink,
} from './data.js';

export default function ClientsSpace({ clients, onUpdateAll, onBack }) {
  const [view, setView] = useState('list');
  const [activeId, setActiveId] = useState(null);
  const [search, setSearch] = useState('');

  function persist(next) {
    onUpdateAll(next);
  }

  function addClient(data) {
    persist([newClient(data), ...clients]);
    setView('list');
  }

  function updateClient(id, patch) {
    persist(clients.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }

  function deleteClient(id) {
    persist(clients.filter((c) => c.id !== id));
    setView('list');
    setActiveId(null);
  }

  const active = clients.find((c) => c.id === activeId);

  const filtered = clients.filter((c) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      c.nom.toLowerCase().includes(q) ||
      (c.plaque || '').toLowerCase().includes(q) ||
      (c.telephone || '').toLowerCase().includes(q) ||
      (c.vehiculeMarque || '').toLowerCase().includes(q)
    );
  });

  if (view === 'form') {
    return <ClientForm title="Nouveau client" onCancel={() => setView('list')} onSubmit={addClient} />;
  }

  if (view === 'detail' && active) {
    return (
      <ClientDetail
        client={active}
        onBack={() => { setView('list'); setActiveId(null); }}
        onUpdate={(patch) => updateClient(active.id, patch)}
        onDelete={() => deleteClient(active.id)}
      />
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-28">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="font-display text-xl text-[#f2eee4]">Clients & Prestations</h1>
          <p className="text-[12px] text-[#8a8478]">{clients.length} client{clients.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div className="px-5">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6458]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher nom, téléphone, plaque…"
            className="w-full bg-[#16140f] border border-[#2a2620] rounded-xl pl-9 pr-9 py-2.5 text-sm text-[#f2eee4] outline-none focus:border-[#5b9bd5]"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6a6458]">
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      <div className="px-5 pt-4 space-y-2.5">
        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
              <Phone size={20} className="text-[#4a4438]" />
            </div>
            <p className="text-[#8a8478] text-sm">{clients.length > 0 ? 'Aucun résultat.' : 'Aucun client pour l\'instant.'}</p>
          </div>
        ) : (
          filtered.map((c) => {
            const { totalHT, count } = computeClientTotals(c);
            const fidele = isClientFidele(c);
            return (
              <button
                key={c.id}
                onClick={() => { setActiveId(c.id); setView('detail'); }}
                className="w-full text-left bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 flex items-center justify-between gap-3 active:scale-[0.98] transition-transform"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-display text-[15px] text-[#f2eee4] truncate">{c.nom || 'Sans nom'}</h3>
                    {fidele && <Star size={12} className="text-[#d4a72c] fill-[#d4a72c] shrink-0" />}
                  </div>
                  <p className="text-[12px] text-[#8a8478] mt-0.5">
                    {[c.vehiculeMarque, c.vehiculeModele].filter(Boolean).join(' ') || 'Véhicule non précisé'}
                    {c.plaque ? ` · ${c.plaque}` : ''}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="font-mono text-sm font-semibold text-[#f2eee4]">{formatEUR(totalHT)}</p>
                  <p className="text-[10px] text-[#6a6458]">{count} interv.</p>
                </div>
              </button>
            );
          })
        )}
      </div>

      <button
        onClick={() => setView('form')}
        className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#5b9bd5] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
        aria-label="Ajouter un client"
      >
        <Plus size={26} strokeWidth={2.5} />
      </button>
    </div>
  );
}

function ClientForm({ title, initial, onCancel, onSubmit }) {
  const [nom, setNom] = useState(initial?.nom || '');
  const [telephone, setTelephone] = useState(initial?.telephone || '');
  const [adresse, setAdresse] = useState(initial?.adresse || '');
  const [vehiculeMarque, setVehiculeMarque] = useState(initial?.vehiculeMarque || '');
  const [vehiculeModele, setVehiculeModele] = useState(initial?.vehiculeModele || '');
  const [plaque, setPlaque] = useState(initial?.plaque || '');
  const [kilometrage, setKilometrage] = useState(initial?.kilometrage ?? '');
  const [remarques, setRemarques] = useState(initial?.remarques || '');

  function handleSubmit() {
    if (!nom.trim()) return;
    onSubmit({
      nom: nom.trim(),
      telephone: telephone.trim(),
      adresse: adresse.trim(),
      vehiculeMarque: vehiculeMarque.trim(),
      vehiculeModele: vehiculeModele.trim(),
      plaque: plaque.trim().toUpperCase(),
      kilometrage: kilometrage === '' ? '' : Number(kilometrage),
      remarques,
    });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onCancel} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">{title}</h1>
      </div>

      <div className="px-5 pt-2 space-y-5">
        <Field label="Nom du client *">
          <input value={nom} onChange={(e) => setNom(e.target.value)} placeholder="M. Dupont" className="input" autoFocus />
        </Field>

        <Field label="Téléphone">
          <input value={telephone} onChange={(e) => setTelephone(e.target.value)} placeholder="06 12 34 56 78" className="input font-mono" />
        </Field>

        <Field label="Adresse">
          <input value={adresse} onChange={(e) => setAdresse(e.target.value)} placeholder="12 rue de la République, Argenteuil" className="input" />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Marque véhicule">
            <input value={vehiculeMarque} onChange={(e) => setVehiculeMarque(e.target.value)} placeholder="Renault" className="input" />
          </Field>
          <Field label="Modèle">
            <input value={vehiculeModele} onChange={(e) => setVehiculeModele(e.target.value)} placeholder="Clio" className="input" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Plaque">
            <input value={plaque} onChange={(e) => setPlaque(e.target.value)} placeholder="AB-123-CD" className="input font-mono" />
          </Field>
          <Field label="Kilométrage">
            <input type="number" inputMode="numeric" value={kilometrage} onChange={(e) => setKilometrage(e.target.value)} placeholder="85000" className="input font-mono" />
          </Field>
        </div>

        <Field label="Remarques">
          <textarea value={remarques} onChange={(e) => setRemarques(e.target.value)} placeholder="Infos utiles sur ce client…" rows={3} className="input resize-none" />
        </Field>

        <button
          onClick={handleSubmit}
          disabled={!nom.trim()}
          className="w-full bg-[#5b9bd5] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3.5 mt-2 active:scale-[0.99] transition-transform"
        >
          Enregistrer le client
        </button>
      </div>
      <GlobalInputStyles />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function GlobalInputStyles() {
  return (
    <style>{`
      .input { width: 100%; background: #16140f; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
      .input:focus { border-color: #5b9bd5; }
      .input::placeholder { color: #5a5448; }
    `}</style>
  );
}

function ClientDetail({ client, onBack, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showInterForm, setShowInterForm] = useState(false);

  const { totalHT, totalTVA, totalTTC, count } = computeClientTotals(client);
  const fidele = isClientFidele(client);
  const suggestion = revisionSuggestion(client);

  if (editing) {
    return (
      <ClientForm
        title="Modifier le client"
        initial={client}
        onCancel={() => setEditing(false)}
        onSubmit={(data) => { onUpdate(data); setEditing(false); }}
      />
    );
  }

  function addIntervention(data) {
    onUpdate({ interventions: [...(client.interventions || []), newIntervention(data)] });
    setShowInterForm(false);
  }

  function deleteIntervention(id) {
    onUpdate({ interventions: client.interventions.filter((i) => i.id !== id) });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-display text-xl text-[#f2eee4] leading-tight">{client.nom}</h1>
              {fidele && <Star size={14} className="text-[#d4a72c] fill-[#d4a72c]" />}
            </div>
            <p className="font-mono text-xs text-[#8a8478]">{client.telephone || 'Pas de téléphone'}</p>
          </div>
        </div>
        <button onClick={() => setEditing(true)} className="p-2 rounded-lg bg-[#16140f] border border-[#2a2620] text-[#8a8478]">
          <Edit3 size={16} />
        </button>
      </div>

      {fidele && (
        <div className="px-5">
          <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-[#d4a72c]/15 text-[#d4a72c]">
            <Star size={11} className="fill-[#d4a72c]" /> Client fidèle
          </span>
        </div>
      )}

      {suggestion && (
        <div className="px-5 pt-3">
          <div className="bg-[#2a2210] border border-[#4d3d1a] rounded-xl p-3.5 flex items-start gap-2.5">
            <Clock size={15} className="text-[#d4a72c] shrink-0 mt-0.5" />
            <p className="text-[12.5px] text-[#e8d8a8]">
              Probablement à relancer pour une révision
              {suggestion.joursDepuis ? ` — ${Math.round(suggestion.joursDepuis / 30)} mois` : ''}
              {suggestion.ecartKm ? ` · ~${suggestion.ecartKm.toLocaleString('fr-FR')} km depuis la dernière visite` : ''}.
            </p>
          </div>
        </div>
      )}

      {(client.telephone || client.adresse) && (
        <div className="px-5 pt-3 grid grid-cols-2 gap-3">
          {client.telephone && (
            <a
              href={telLink(client.telephone)}
              className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-2.5 text-sm"
            >
              <PhoneCall size={14} /> Appeler
            </a>
          )}
          {client.adresse && (
            <a
              href={wazeLink(client.adresse)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-2.5 text-sm"
            >
              <MapPin size={14} /> Itinéraire
            </a>
          )}
        </div>
      )}

      <div className="px-5 pt-4 space-y-5">
        <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-5">
          <span className="text-xs font-medium text-[#8a8478] uppercase tracking-wide">Total facturé (HT)</span>
          <div className="font-display text-3xl text-[#f2eee4] mt-1">{formatEUR(totalHT)}</div>
          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[#2a2620]">
            <Stat label="TVA (20%)" value={formatEURPrecise(totalTVA)} />
            <Stat label="Total TTC" value={formatEUR(totalTTC)} />
            <Stat label="Interventions" value={String(count)} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <InfoCard icon={<Gauge size={14} />} label="Véhicule" value={[client.vehiculeMarque, client.vehiculeModele].filter(Boolean).join(' ') || '—'} />
          <InfoCard icon={<Gauge size={14} />} label="Kilométrage" value={formatKm(client.kilometrage)} />
        </div>
        {client.plaque && <InfoCard icon={<Gauge size={14} />} label="Plaque" value={client.plaque} full />}
        {client.adresse && <InfoCard icon={<MapPin size={14} />} label="Adresse" value={client.adresse} full />}

        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478]">
              Interventions ({(client.interventions || []).length})
            </h2>
            <button onClick={() => setShowInterForm(true)} className="text-[#5b9bd5] text-xs font-semibold flex items-center gap-1">
              <Plus size={14} /> Ajouter
            </button>
          </div>

          {(client.interventions || []).length === 0 ? (
            <p className="text-[#5a5448] text-sm py-3">Aucune intervention enregistrée.</p>
          ) : (
            <div className="space-y-2.5">
              {[...client.interventions]
                .sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0))
                .map((it) => {
                  const { ht, tva, ttc, rentabiliteHoraire } = computeInterventionTotal(it);
                  return (
                    <div key={it.id} className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-[#f2eee4] truncate">{it.piece || 'Intervention'}</p>
                          <div className="flex items-center gap-3 mt-1 text-[11px] text-[#7a766f] flex-wrap">
                            <span className="flex items-center gap-1"><Calendar size={10} />{formatDate(it.date)}</span>
                            {it.kilometrage !== '' && it.kilometrage != null && (
                              <span className="flex items-center gap-1"><Gauge size={10} />{formatKm(it.kilometrage)}</span>
                            )}
                            {rentabiliteHoraire != null && (
                              <span className="flex items-center gap-1 text-[#d4a72c]"><Clock size={10} />{formatEUR(rentabiliteHoraire)}/h</span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="font-mono text-sm font-semibold text-[#f2eee4]">{formatEUR(ttc)}</span>
                          <button onClick={() => deleteIntervention(it.id)} className="text-[#5a5448]"><X size={15} /></button>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-[#2a2620]">
                        <Stat label="Pièce (TTC)" value={formatEUR(it.prixPieceTTC ?? it.prixPiece)} />
                        <Stat label="Main d'œuvre (TTC)" value={formatEUR(it.tarifMainOeuvreTTC ?? it.tarifMainOeuvre)} />
                        <Stat label="TVA (20%)" value={formatEURPrecise(tva)} />
                      </div>
                      {it.facture && (
                        <div className="mt-3">
                          <img src={it.facture} alt="Facture" className="w-full max-h-40 object-cover rounded-lg border border-[#2a2620]" />
                        </div>
                      )}
                      {it.notes && <p className="text-xs text-[#8a8478] mt-2 whitespace-pre-wrap">{it.notes}</p>}
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        <div>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-2">Remarques</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-xl p-4 min-h-[60px]">
            <p className="text-sm text-[#c4bfb2] whitespace-pre-wrap">{client.remarques || '—'}</p>
          </div>
        </div>

        <div className="pt-4">
          {!confirmDelete ? (
            <button onClick={() => setConfirmDelete(true)} className="w-full text-[#d97a6c] text-sm font-medium py-3 flex items-center justify-center gap-2">
              <Trash2 size={15} /> Supprimer ce client
            </button>
          ) : (
            <div className="bg-[#2a1a16] border border-[#4d2d28] rounded-xl p-4">
              <p className="text-sm text-[#e8c8c2] mb-3">Suppression définitive. Confirmer ?</p>
              <div className="flex gap-2">
                <button onClick={() => setConfirmDelete(false)} className="flex-1 bg-[#16140f] rounded-lg py-2.5 text-sm font-medium text-[#f2eee4]">Annuler</button>
                <button onClick={onDelete} className="flex-1 bg-[#c44536] rounded-lg py-2.5 text-sm font-medium text-white">Supprimer</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showInterForm && <InterventionModal onClose={() => setShowInterForm(false)} onSubmit={addIntervention} />}
      <GlobalInputStyles />
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <p className="text-[10px] text-[#6a6458] uppercase tracking-wide">{label}</p>
      <p className="font-mono text-sm font-semibold text-[#f2eee4] mt-0.5">{value}</p>
    </div>
  );
}

function InfoCard({ icon, label, value, full }) {
  return (
    <div className={`bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 ${full ? 'col-span-2' : ''}`}>
      <div className="flex items-center gap-1.5 text-[#6a6458] text-[11px] mb-1">
        {icon}<span>{label}</span>
      </div>
      <p className="text-sm font-medium text-[#f2eee4]">{value}</p>
    </div>
  );
}

function InterventionModal({ onClose, onSubmit }) {
  const [piece, setPiece] = useState('');
  const [date, setDate] = useState(todayISO());
  const [kilometrage, setKilometrage] = useState('');
  const [prixPieceTTC, setPrixPieceTTC] = useState('');
  const [tarifMainOeuvreTTC, setTarifMainOeuvreTTC] = useState('');
  const [dureeHeures, setDureeHeures] = useState('');
  const [notes, setNotes] = useState('');
  const [facture, setFacture] = useState(null);
  const fileRef = useRef(null);

  const totalTTC = (Number(prixPieceTTC) || 0) + (Number(tarifMainOeuvreTTC) || 0);
  const totalHT = totalTTC / 1.2;
  const totalTVA = totalTTC - totalHT;

  function handleFacture(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setFacture(reader.result);
    reader.readAsDataURL(file);
  }

  function submit() {
    if (!piece.trim()) return;
    onSubmit({
      piece: piece.trim(),
      date,
      kilometrage: kilometrage === '' ? '' : Number(kilometrage),
      prixPieceTTC: prixPieceTTC === '' ? 0 : Number(prixPieceTTC),
      tarifMainOeuvreTTC: tarifMainOeuvreTTC === '' ? 0 : Number(tarifMainOeuvreTTC),
      dureeHeures: dureeHeures === '' ? '' : Number(dureeHeures),
      notes: notes.trim(),
      facture,
    });
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50 overflow-y-auto" onClick={onClose}>
      <div className="bg-[#16140f] border-t sm:border border-[#2a2620] rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 pb-7 my-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-[#f2eee4]">Nouvelle intervention</h3>
          <button onClick={onClose} className="text-[#8a8478]"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <Field label="Pièce / intervention">
            <input value={piece} onChange={(e) => setPiece(e.target.value)} placeholder="Plaquettes de frein avant" className="input" autoFocus />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Date">
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
            </Field>
            <Field label="Kilométrage">
              <input type="number" inputMode="numeric" value={kilometrage} onChange={(e) => setKilometrage(e.target.value)} placeholder="120000" className="input font-mono" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Prix pièce — TTC (€)">
              <input type="number" inputMode="decimal" value={prixPieceTTC} onChange={(e) => setPrixPieceTTC(e.target.value)} placeholder="0" className="input font-mono" />
            </Field>
            <Field label="Main d'œuvre — TTC (€)">
              <input type="number" inputMode="decimal" value={tarifMainOeuvreTTC} onChange={(e) => setTarifMainOeuvreTTC(e.target.value)} placeholder="0" className="input font-mono" />
            </Field>
          </div>

          {totalTTC > 0 && (
            <div className="bg-[#1c1a14] border border-[#2a2620] rounded-lg px-3.5 py-2.5 flex items-center justify-between text-xs">
              <span className="text-[#8a8478]">HT : <span className="font-mono text-[#f2eee4]">{totalHT.toFixed(2)} €</span></span>
              <span className="text-[#8a8478]">TVA : <span className="font-mono text-[#f2eee4]">{totalTVA.toFixed(2)} €</span></span>
              <span className="text-[#d4a72c] font-semibold">TTC : <span className="font-mono">{totalTTC.toFixed(2)} €</span></span>
            </div>
          )}

          <Field label="Durée (heures, optionnel)">
            <input type="number" inputMode="decimal" value={dureeHeures} onChange={(e) => setDureeHeures(e.target.value)} placeholder="1.5" className="input font-mono" />
          </Field>
          <p className="text-[11px] text-[#5a5448] -mt-2">La rentabilité horaire se calcule uniquement sur la main d'œuvre, pas sur le prix des pièces.</p>

          <Field label="Notes">
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Détails de l'intervention…" rows={2} className="input resize-none" />
          </Field>

          <div>
            <label className="block text-xs font-medium text-[#8a8478] mb-1.5">Facture</label>
            {facture ? (
              <div className="relative">
                <img src={facture} alt="Facture" className="w-full max-h-40 object-cover rounded-lg border border-[#2a2620]" />
                <button onClick={() => setFacture(null)} className="absolute top-1.5 right-1.5 bg-black/60 rounded-full p-1 text-white">
                  <X size={12} />
                </button>
              </div>
            ) : (
              <button onClick={() => fileRef.current?.click()} className="w-full border border-dashed border-[#2a2620] rounded-xl py-4 flex flex-col items-center gap-1.5 text-[#5a5448]">
                <Receipt size={18} />
                <span className="text-xs">Photo de la facture</span>
              </button>
            )}
            <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleFacture} />
          </div>

          <button
            onClick={submit}
            disabled={!piece.trim()}
            className="w-full bg-[#5b9bd5] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3 mt-2"
          >
            Ajouter
          </button>
        </div>
        <GlobalInputStyles />
      </div>
    </div>
  );
}
