import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://nhudnuoblwmcmqjwrckm.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_L4XwYiOdt3c_SB3B7xmM_g_5OQqTW8c';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
