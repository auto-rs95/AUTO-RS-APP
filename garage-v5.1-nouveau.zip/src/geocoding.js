// Géocodage gratuit via Nominatim (OpenStreetMap) — pas de clé API nécessaire.
// Limite d'usage raisonnable : 1 requête/seconde, largement suffisant pour ce volume.

const geocodeCache = new Map();

export async function geocodeAddress(address) {
  if (!address || !address.trim()) return null;
  const key = address.trim().toLowerCase();
  if (geocodeCache.has(key)) return geocodeCache.get(key);

  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(address)}`;
    const res = await fetch(url, {
      headers: { 'Accept-Language': 'fr' },
    });
    if (!res.ok) return null;
    const results = await res.json();
    if (!results || results.length === 0) return null;
    const coords = { lat: parseFloat(results[0].lat), lon: parseFloat(results[0].lon) };
    geocodeCache.set(key, coords);
    return coords;
  } catch (e) {
    console.error('Erreur géocodage:', e);
    return null;
  }
}
