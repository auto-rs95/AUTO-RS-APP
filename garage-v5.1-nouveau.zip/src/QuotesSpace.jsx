import React, { useState, useRef, useEffect } from 'react';
import {
  ChevronLeft, Plus, X, Trash2, FileText, Check, Car, Wrench, Mail, MessageCircle, Receipt,
  Download, BookOpen, ChevronDown,
} from 'lucide-react';
import {
  newQuote, newQuoteLine, computeQuoteTotals, nextQuoteNumber, formatEUR, formatEURPrecise,
  formatDate, todayISO, MENTIONS_LEGALES, PAIEMENT_STATUTS, DEFAULT_COMPANY,
  newPrestationLibre,
} from './data.js';
import { PrestationsLibresAPI, CompanyAPI } from './supabaseApi.js';
import { generateQuotePDF } from './pdfGenerator.js';

export default function QuotesSpace({ quotes, onUpdateAll, onBack }) {
  const [view, setView] = useState('list');
  const [activeId, setActiveId] = useState(null);
  const [tab, setTab] = useState('devis'); // 'devis' | 'factures'

  function persist(next) {
    onUpdateAll(next);
  }

  function addQuote(data) {
    const numero = nextQuoteNumber(quotes);
    const q = newQuote({ ...data, numero });
    persist([q, ...quotes]);
    setActiveId(q.id);
    setView('detail');
  }

  function updateQuote(id, patch) {
    persist(quotes.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  }

  function deleteQuote(id) {
    persist(quotes.filter((q) => q.id !== id));
    setView('list');
    setActiveId(null);
  }

  const active = quotes.find((q) => q.id === activeId);

  if (view === 'form') {
    return <QuoteForm title="Nouveau devis" onCancel={() => setView('list')} onSubmit={addQuote} />;
  }

  if (view === 'detail' && active) {
    return (
      <QuoteDetail
        quote={active}
        onBack={() => { setView('list'); setActiveId(null); }}
        onUpdate={(patch) => updateQuote(active.id, patch)}
        onDelete={() => deleteQuote(active.id)}
      />
    );
  }

  const devis = quotes.filter((q) => q.statut === 'devis');
  const factures = quotes.filter((q) => q.statut === 'facture');
  const list = tab === 'devis' ? devis : factures;

  return (
    <div className="max-w-2xl mx-auto pb-28">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="font-display text-xl text-[#f2eee4]">Devis & Factures</h1>
          <p className="text-[12px] text-[#8a8478]">{quotes.length} document{quotes.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div className="px-5">
        <div className="flex bg-[#16140f] border border-[#2a2620] rounded-xl p-1 gap-1">
          <button
            onClick={() => setTab('devis')}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${
              tab === 'devis' ? 'bg-[#5b9bd5] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            Devis ({devis.length})
          </button>
          <button
            onClick={() => setTab('factures')}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${
              tab === 'factures' ? 'bg-[#7fc28a] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            Factures ({factures.length})
          </button>
        </div>
      </div>

      <div className="px-5 pt-4 space-y-2">
        {list.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
              <Receipt size={20} className="text-[#4a4438]" />
            </div>
            <p className="text-[#8a8478] text-sm">
              {tab === 'devis' ? 'Aucun devis pour l\'instant.' : 'Aucune facture pour l\'instant.'}
            </p>
          </div>
        ) : (
          list.map((q) => {
            const { ttc } = computeQuoteTotals(q);
            const paiementInfo = PAIEMENT_STATUTS.find((s) => s.id === q.paiementStatut) || PAIEMENT_STATUTS[0];
            return (
              <button
                key={q.id}
                onClick={() => { setActiveId(q.id); setView('detail'); }}
                className="w-full text-left bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 flex items-center justify-between gap-3 active:scale-[0.98] transition-transform"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  {q.type === 'achatRevente' ? <Car size={15} className="text-[#d4a72c] shrink-0" /> : <Wrench size={15} className="text-[#5b9bd5] shrink-0" />}
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#f2eee4] truncate">{q.clientNom || 'Client non précisé'}</p>
                    <p className="text-[11px] text-[#6a6458] font-mono">{q.numero} · {formatDate(q.date)}</p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-mono text-sm font-semibold text-[#f2eee4] block">{formatEUR(ttc)}</span>
                  {q.statut === 'facture' && (
                    <span className="text-[10px] font-semibold" style={{ color: paiementInfo.color }}>{paiementInfo.label}</span>
                  )}
                </div>
              </button>
            );
          })
        )}
      </div>

      <button
        onClick={() => setView('form')}
        className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#e07856] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
        aria-label="Nouveau devis"
      >
        <Plus size={26} strokeWidth={2.5} />
      </button>
    </div>
  );
}

function QuoteForm({ title, initial, onCancel, onSubmit }) {
  const [type, setType] = useState(initial?.type || 'prestationMecanique');
  const [date, setDate] = useState(initial?.date || todayISO());
  const [clientNom, setClientNom] = useState(initial?.clientNom || '');
  const [clientTelephone, setClientTelephone] = useState(initial?.clientTelephone || '');
  const [clientEmail, setClientEmail] = useState(initial?.clientEmail || '');
  const [vehiculeMarque, setVehiculeMarque] = useState(initial?.vehiculeMarque || '');
  const [vehiculeModele, setVehiculeModele] = useState(initial?.vehiculeModele || '');
  const [plaque, setPlaque] = useState(initial?.plaque || '');
  const [kilometrage, setKilometrage] = useState(initial?.kilometrage ?? '');
  const [lignes, setLignes] = useState(initial?.lignes?.length ? initial.lignes : [newQuoteLine()]);
  const [notes, setNotes] = useState(initial?.notes || '');
  const [prestationsLibres, setPrestationsLibres] = useState([]);
  const [showLibrary, setShowLibrary] = useState(false);

  useEffect(() => {
    PrestationsLibresAPI.list().then(setPrestationsLibres);
  }, []);

  function updateLigne(idx, patch) {
    setLignes(lignes.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  function addLigne() {
    setLignes([...lignes, newQuoteLine()]);
  }

  function removeLigne(idx) {
    if (lignes.length === 1) return;
    setLignes(lignes.filter((_, i) => i !== idx));
  }

  function addFromLibrary(prestation) {
    const emptyIdx = lignes.findIndex((l) => !l.libelle.trim());
    const newLine = newQuoteLine({ libelle: prestation.libelle, montantTTC: prestation.montantTTC });
    if (emptyIdx !== -1) {
      setLignes(lignes.map((l, i) => (i === emptyIdx ? newLine : l)));
    } else {
      setLignes([...lignes, newLine]);
    }
    setShowLibrary(false);
  }

  async function saveToLibrary(idx) {
    const l = lignes[idx];
    if (!l.libelle.trim()) return;
    const created = await PrestationsLibresAPI.insert(newPrestationLibre({ libelle: l.libelle, montantTTC: l.montantTTC }));
    if (created) setPrestationsLibres([...prestationsLibres, created]);
  }

  async function deleteFromLibrary(id) {
    await PrestationsLibresAPI.remove(id);
    setPrestationsLibres(prestationsLibres.filter((p) => p.id !== id));
  }

  const totalTTC = lignes.reduce((s, l) => s + (Number(l.montantTTC) || 0), 0);

  function handleSubmit() {
    if (!clientNom.trim() || lignes.every((l) => !l.libelle.trim())) return;
    onSubmit({
      type, date,
      clientNom: clientNom.trim(),
      clientTelephone: clientTelephone.trim(),
      clientEmail: clientEmail.trim(),
      vehiculeMarque: vehiculeMarque.trim(),
      vehiculeModele: vehiculeModele.trim(),
      plaque: plaque.trim().toUpperCase(),
      kilometrage: kilometrage === '' ? '' : Number(kilometrage),
      lignes: lignes.filter((l) => l.libelle.trim()),
      notes: notes.trim(),
    });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onCancel} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">{title}</h1>
      </div>

      <div className="px-5 pt-2 space-y-5">
        <Field label="Type de document">
          <div className="flex gap-2">
            <TypeButton active={type === 'achatRevente'} onClick={() => setType('achatRevente')} icon={<Car size={14} />} label="Achat/Revente" color="#d4a72c" />
            <TypeButton active={type === 'prestationMecanique'} onClick={() => setType('prestationMecanique')} icon={<Wrench size={14} />} label="Prestation mécanique" color="#5b9bd5" />
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Client *">
            <input value={clientNom} onChange={(e) => setClientNom(e.target.value)} placeholder="M. Dupont" className="input" autoFocus />
          </Field>
          <Field label="Date">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Téléphone">
            <input value={clientTelephone} onChange={(e) => setClientTelephone(e.target.value)} placeholder="06 12 34 56 78" className="input font-mono" />
          </Field>
          <Field label="Email">
            <input type="email" value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} placeholder="client@email.com" className="input" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Marque véhicule">
            <input value={vehiculeMarque} onChange={(e) => setVehiculeMarque(e.target.value)} placeholder="Renault" className="input" />
          </Field>
          <Field label="Modèle">
            <input value={vehiculeModele} onChange={(e) => setVehiculeModele(e.target.value)} placeholder="Clio" className="input" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Plaque">
            <input value={plaque} onChange={(e) => setPlaque(e.target.value)} placeholder="AB-123-CD" className="input font-mono" />
          </Field>
          <Field label="Kilométrage">
            <input type="number" inputMode="numeric" value={kilometrage} onChange={(e) => setKilometrage(e.target.value)} placeholder="85000" className="input font-mono" />
          </Field>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-xs font-medium text-[#8a8478]">Lignes (tâche + tarif TTC)</label>
            <div className="flex items-center gap-3">
              <button onClick={() => setShowLibrary(true)} className="text-[#5b9bd5] text-xs font-semibold flex items-center gap-1">
                <BookOpen size={13} /> Bibliothèque
              </button>
              <button onClick={addLigne} className="text-[#e07856] text-xs font-semibold flex items-center gap-1">
                <Plus size={13} /> Ligne
              </button>
            </div>
          </div>
          <div className="space-y-2">
            {lignes.map((l, idx) => (
              <div key={l.id} className="flex items-stretch gap-2">
                <input
                  value={l.libelle}
                  onChange={(e) => updateLigne(idx, { libelle: e.target.value })}
                  placeholder="Ex : Remplacement plaquettes avant"
                  className="input flex-1 min-w-0"
                />
                <input
                  type="number"
                  inputMode="decimal"
                  value={l.montantTTC}
                  onChange={(e) => updateLigne(idx, { montantTTC: e.target.value === '' ? '' : Number(e.target.value) })}
                  placeholder="0 €"
                  className="input font-mono shrink-0"
                  style={{ width: '88px' }}
                />
                {l.libelle.trim() && (
                  <button onClick={() => saveToLibrary(idx)} title="Enregistrer dans la bibliothèque" className="text-[#5b9bd5] shrink-0 px-1">
                    <BookOpen size={15} />
                  </button>
                )}
                <button onClick={() => removeLigne(idx)} disabled={lignes.length === 1} className="text-[#5a5448] disabled:opacity-20 shrink-0 px-1">
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
          {totalTTC > 0 && (
            <div className="bg-[#1c1a14] border border-[#2a2620] rounded-lg px-3.5 py-2.5 mt-3 flex items-center justify-between">
              <span className="text-xs text-[#8a8478]">Total TTC</span>
              <span className="font-mono text-base font-semibold text-[#e07856]">{formatEUR(totalTTC)}</span>
            </div>
          )}
        </div>

        <Field label="Notes (optionnel)">
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Précisions complémentaires…" rows={3} className="input resize-none" />
        </Field>

        <div className="bg-[#1c1a14] border border-[#2a2620] rounded-lg p-3.5">
          <p className="text-[11px] text-[#8a8478] italic">{MENTIONS_LEGALES[type]}</p>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!clientNom.trim()}
          className="w-full bg-[#e07856] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3.5 mt-2 active:scale-[0.99] transition-transform"
        >
          Créer le devis
        </button>
      </div>

      {showLibrary && (
        <LibraryModal
          prestations={prestationsLibres}
          onSelect={addFromLibrary}
          onDelete={deleteFromLibrary}
          onClose={() => setShowLibrary(false)}
        />
      )}

      <GlobalInputStyles />
    </div>
  );
}

function LibraryModal({ prestations, onSelect, onDelete, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={onClose}>
      <div
        className="bg-[#16140f] border-t sm:border border-[#2a2620] rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 pb-7 max-h-[70vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-[#f2eee4]">Bibliothèque</h3>
          <button onClick={onClose} className="text-[#8a8478]"><X size={20} /></button>
        </div>
        {prestations.length === 0 ? (
          <p className="text-[#5a5448] text-sm py-6 text-center">
            Aucune prestation enregistrée encore.<br />Enregistre une ligne depuis un devis pour la retrouver ici.
          </p>
        ) : (
          <div className="space-y-2">
            {prestations.map((p) => (
              <div key={p.id} className="flex items-center justify-between gap-2 bg-[#1c1a14] border border-[#2a2620] rounded-lg p-3">
                <button onClick={() => onSelect(p)} className="flex-1 text-left min-w-0">
                  <p className="text-sm text-[#f2eee4] truncate">{p.libelle}</p>
                  <p className="font-mono text-xs text-[#5b9bd5]">{formatEUR(p.montantTTC)}</p>
                </button>
                <button onClick={() => onDelete(p.id)} className="text-[#5a5448] shrink-0"><Trash2 size={15} /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TypeButton({ active, onClick, icon, label, color }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold border"
      style={active ? { backgroundColor: color, borderColor: color, color: '#0a0a0a' } : { borderColor: '#2a2620', color: '#8a8478' }}
    >
      {icon} {label}
    </button>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function GlobalInputStyles() {
  return (
    <style>{`
      .input { width: 100%; background: #16140f; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
      .input:focus { border-color: #e07856; }
      .input::placeholder { color: #5a5448; }
    `}</style>
  );
}

function QuoteDetail({ quote, onBack, onUpdate, onDelete }) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const { ht, tva, ttc } = computeQuoteTotals(quote);
  const [company, setCompany] = useState(DEFAULT_COMPANY);
  useEffect(() => {
    CompanyAPI.get().then((c) => setCompany(c ? { ...DEFAULT_COMPANY, ...c } : DEFAULT_COMPANY));
  }, []);
  const isFacture = quote.statut === 'facture';

  function convertToFacture() {
    onUpdate({ statut: 'facture' });
  }

  function downloadPDF() {
    generateQuotePDF(quote, company);
  }

  function setPaiementStatut(statutId) {
    onUpdate({ paiementStatut: statutId });
  }

  function buildDocumentText() {
    const lines = quote.lignes.map((l) => `${l.libelle} : ${formatEUR(l.montantTTC)}`).join('\n');
    return [
      `${isFacture ? 'FACTURE' : 'DEVIS'} ${quote.numero}`,
      company.nom,
      `${company.siret ? 'SIRET : ' + company.siret : ''}`,
      `${company.tva ? 'TVA : ' + company.tva : ''}`,
      company.adresse,
      '',
      `Client : ${quote.clientNom}`,
      quote.clientTelephone ? `Tél : ${quote.clientTelephone}` : '',
      [quote.vehiculeMarque, quote.vehiculeModele].filter(Boolean).join(' '),
      quote.plaque ? `Plaque : ${quote.plaque}` : '',
      quote.kilometrage !== '' && quote.kilometrage != null ? `Kilométrage : ${quote.kilometrage} km` : '',
      '',
      lines,
      '',
      `Total HT : ${formatEURPrecise(ht)}`,
      `TVA (20%) : ${formatEURPrecise(tva)}`,
      `Total TTC : ${formatEUR(ttc)}`,
      '',
      MENTIONS_LEGALES[quote.type],
    ].filter(Boolean).join('\n');
  }

  function shareByEmail() {
    const subject = encodeURIComponent(`${isFacture ? 'Facture' : 'Devis'} ${quote.numero} — Auto RS Multi Services`);
    const body = encodeURIComponent(buildDocumentText());
    const to = quote.clientEmail || '';
    window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
  }

  function shareBySMS() {
    const body = encodeURIComponent(buildDocumentText());
    window.location.href = `sms:${quote.clientTelephone || ''}?body=${body}`;
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
          <div>
            <h1 className="font-display text-xl text-[#f2eee4] leading-tight">{quote.numero}</h1>
            <p className="text-xs text-[#8a8478]">{formatDate(quote.date)}</p>
          </div>
        </div>
        <span
          className="text-xs font-semibold px-2.5 py-1 rounded-full"
          style={isFacture ? { backgroundColor: '#7fc28a22', color: '#7fc28a' } : { backgroundColor: '#5b9bd522', color: '#5b9bd5' }}
        >
          {isFacture ? 'Facture' : 'Devis'}
        </span>
      </div>

      <div className="px-5 space-y-5">
        <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-5">
          <span className="text-xs font-medium text-[#8a8478] uppercase tracking-wide">Total TTC</span>
          <div className="font-display text-3xl text-[#f2eee4] mt-1">{formatEUR(ttc)}</div>
          <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-[#2a2620]">
            <Stat label="HT" value={formatEURPrecise(ht)} />
            <Stat label="TVA (20%)" value={formatEURPrecise(tva)} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <InfoCard label="Client" value={quote.clientNom || '—'} />
          <InfoCard label="Téléphone" value={quote.clientTelephone || '—'} />
          <InfoCard label="Véhicule" value={[quote.vehiculeMarque, quote.vehiculeModele].filter(Boolean).join(' ') || '—'} />
          <InfoCard label="Plaque" value={quote.plaque || '—'} />
        </div>

        <div>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-2">Détail</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-xl divide-y divide-[#2a2620]">
            {quote.lignes.map((l) => (
              <div key={l.id} className="flex items-center justify-between px-3.5 py-2.5">
                <span className="text-sm text-[#f2eee4]">{l.libelle}</span>
                <span className="font-mono text-sm text-[#e07856]">{formatEUR(l.montantTTC)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1c1a14] border border-[#2a2620] rounded-lg p-3.5">
          <p className="text-[11px] text-[#8a8478] italic">{MENTIONS_LEGALES[quote.type]}</p>
        </div>

        {isFacture && (
          <div>
            <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-2">Statut de paiement</h2>
            <div className="flex gap-2">
              {PAIEMENT_STATUTS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setPaiementStatut(s.id)}
                  className="flex-1 py-2.5 rounded-xl text-xs font-semibold border"
                  style={
                    quote.paiementStatut === s.id
                      ? { backgroundColor: s.color, borderColor: s.color, color: '#0a0a0a' }
                      : { borderColor: '#2a2620', color: '#8a8478' }
                  }
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={downloadPDF}
          className="w-full flex items-center justify-center gap-2 bg-[#d4a72c] text-[#0a0a0a] font-semibold rounded-xl py-3.5 active:scale-[0.99] transition-transform"
        >
          <Download size={16} /> Télécharger le PDF
        </button>

        {!isFacture && (
          <button
            onClick={convertToFacture}
            className="w-full flex items-center justify-center gap-2 bg-[#7fc28a] text-[#0a0a0a] font-semibold rounded-xl py-3 active:scale-[0.99] transition-transform"
          >
            <Check size={16} /> Transformer en facture
          </button>
        )}

        <div className="grid grid-cols-2 gap-3">
          <button onClick={shareByEmail} className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-3">
            <Mail size={15} /> Email
          </button>
          <button onClick={shareBySMS} className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-3">
            <MessageCircle size={15} /> SMS
          </button>
        </div>
        <p className="text-[10px] text-[#5a5448] text-center -mt-3">
          Email/SMS envoient le détail en texte. Pour joindre le PDF, télécharge-le puis ajoute-le manuellement à ton message.
        </p>

        <div className="pt-2">
          {!confirmDelete ? (
            <button onClick={() => setConfirmDelete(true)} className="w-full text-[#d97a6c] text-sm font-medium py-3 flex items-center justify-center gap-2">
              <Trash2 size={15} /> Supprimer ce document
            </button>
          ) : (
            <div className="bg-[#2a1a16] border border-[#4d2d28] rounded-xl p-4">
              <p className="text-sm text-[#e8c8c2] mb-3">Suppression définitive. Confirmer ?</p>
              <div className="flex gap-2">
                <button onClick={() => setConfirmDelete(false)} className="flex-1 bg-[#16140f] rounded-lg py-2.5 text-sm font-medium text-[#f2eee4]">Annuler</button>
                <button onClick={onDelete} className="flex-1 bg-[#c44536] rounded-lg py-2.5 text-sm font-medium text-white">Supprimer</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <p className="text-[10px] text-[#6a6458] uppercase tracking-wide">{label}</p>
      <p className="font-mono text-sm font-semibold text-[#f2eee4] mt-0.5">{value}</p>
    </div>
  );
}

function InfoCard({ label, value }) {
  return (
    <div className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5">
      <p className="text-[11px] text-[#6a6458] mb-1">{label}</p>
      <p className="text-sm font-medium text-[#f2eee4] truncate">{value}</p>
    </div>
  );
}
