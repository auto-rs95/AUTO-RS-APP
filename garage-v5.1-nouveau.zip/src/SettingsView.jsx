import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, Download, Upload, Building2, Check, AlertTriangle, ImagePlus, X, LogOut, Images, Trash2, GripVertical } from 'lucide-react';
import { DEFAULT_COMPANY, newGalleryItem } from './data.js';
import {
  VehiclesAPI, ClientsAPI, StockAPI, AppointmentsAPI, QuotesAPI, PrestationsLibresAPI, CompanyAPI, GalleryAPI,
} from './supabaseApi.js';

export default function SettingsView({ onBack, onDataImported, onLogout }) {
  const [company, setCompany] = useState(DEFAULT_COMPANY);
  const [companyLoaded, setCompanyLoaded] = useState(false);
  const [status, setStatus] = useState(null); // { type: 'success'|'error', msg }
  const [gallery, setGallery] = useState([]);
  const fileRef = useRef(null);
  const logoRef = useRef(null);
  const galleryRef = useRef(null);

  useEffect(() => {
    CompanyAPI.get().then((c) => {
      setCompany(c ? { ...DEFAULT_COMPANY, ...c } : DEFAULT_COMPANY);
      setCompanyLoaded(true);
    });
    GalleryAPI.list().then(setGallery);
  }, []);

  function handleGalleryUpload(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    Promise.all(
      files.map(
        (f) =>
          new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.readAsDataURL(f);
          })
      )
    ).then(async (urls) => {
      const inserted = await Promise.all(urls.map((photo) => GalleryAPI.insert(newGalleryItem({ photo }))));
      setGallery([...gallery, ...inserted.filter(Boolean)]);
    });
    e.target.value = '';
  }

  async function removeGalleryItem(id) {
    await GalleryAPI.remove(id);
    setGallery(gallery.filter((g) => g.id !== id));
  }

  async function handleExport() {
    setStatus(null);
    const [vehicles, clients, stock, appointments, quotes, prestationsLibres, companyData] = await Promise.all([
      VehiclesAPI.list(),
      ClientsAPI.list(),
      StockAPI.list(),
      AppointmentsAPI.list(),
      QuotesAPI.list(),
      PrestationsLibresAPI.list(),
      CompanyAPI.get(),
    ]);
    const data = {
      version: 3,
      exportedAt: new Date().toISOString(),
      vehicles, clients, stock, appointments, quotes, prestationsLibres,
      company: companyData,
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `autors-sauvegarde-${date}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setStatus({ type: 'success', msg: 'Sauvegarde téléchargée.' });
  }

  function handleImportFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || typeof data !== 'object') throw new Error('Format invalide');

        // Supprime les données actuelles puis réinsère celles du fichier.
        const [curVehicles, curClients, curStock, curAppointments, curQuotes] = await Promise.all([
          VehiclesAPI.list(), ClientsAPI.list(), StockAPI.list(), AppointmentsAPI.list(), QuotesAPI.list(),
        ]);
        await Promise.all([
          ...curVehicles.map((v) => VehiclesAPI.remove(v.id)),
          ...curClients.map((c) => ClientsAPI.remove(c.id)),
          ...curStock.map((s) => StockAPI.remove(s.id)),
          ...curAppointments.map((a) => AppointmentsAPI.remove(a.id)),
          ...curQuotes.map((q) => QuotesAPI.remove(q.id)),
        ]);
        await Promise.all([
          ...(data.vehicles || []).map((v) => VehiclesAPI.insert(v)),
          ...(data.clients || []).map((c) => ClientsAPI.insert(c)),
          ...(data.stock || []).map((s) => StockAPI.insert(s)),
          ...(data.appointments || []).map((a) => AppointmentsAPI.insert(a)),
          ...(data.quotes || []).map((q) => QuotesAPI.insert(q)),
        ]);
        if (data.company) await CompanyAPI.upsert(data.company);

        setStatus({ type: 'success', msg: 'Données restaurées avec succès.' });
        onDataImported();
      } catch (err) {
        setStatus({ type: 'error', msg: 'Fichier invalide, restauration impossible.' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  async function updateCompanyField(field, value) {
    const next = { ...company, [field]: value };
    setCompany(next);
    await CompanyAPI.upsert({ [field]: value });
  }

  function handleLogoUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      updateCompanyField('logo', reader.result);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  }

  function removeLogo() {
    updateCompanyField('logo', null);
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">Réglages</h1>
      </div>

      {status && (
        <div className="px-5 mb-4">
          <div className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm ${
            status.type === 'success' ? 'bg-[#1a2a1d] text-[#7fc28a] border border-[#2d3d2e]' : 'bg-[#2a1a16] text-[#e8c8c2] border border-[#4d2d28]'
          }`}>
            {status.type === 'success' ? <Check size={15} /> : <AlertTriangle size={15} />}
            {status.msg}
          </div>
        </div>
      )}

      <div className="px-5 space-y-6">
        <section>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-3">Sauvegarde des données</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4 space-y-3">
            <p className="text-[13px] text-[#8a8478]">
              Tes données sont stockées en ligne (Supabase), accessibles depuis n'importe quel appareil après connexion. Exporte régulièrement une sauvegarde supplémentaire par sécurité.
            </p>
            <button onClick={handleExport} className="w-full flex items-center justify-center gap-2 bg-[#d4a72c] text-[#0a0a0a] font-semibold rounded-xl py-3 active:scale-[0.99] transition-transform">
              <Download size={16} /> Exporter une sauvegarde
            </button>
            <button onClick={() => fileRef.current?.click()} className="w-full flex items-center justify-center gap-2 bg-[#1c1a14] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-3 active:scale-[0.99] transition-transform">
              <Upload size={16} /> Restaurer une sauvegarde
            </button>
            <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={handleImportFile} />
            <p className="text-[11px] text-[#5a5448]">⚠️ Restaurer une sauvegarde remplace toutes les données actuelles.</p>
          </div>
        </section>

        <section>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-3">Logo</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4">
            <p className="text-[13px] text-[#8a8478] mb-3">
              Utilisé sur l'écran d'accueil de l'app et sur les devis/factures PDF.
            </p>
            {company.logo ? (
              <div className="flex items-center gap-3">
                <img src={company.logo} alt="Logo" className="w-16 h-16 rounded-xl object-cover border border-[#2a2620]" />
                <div className="flex-1 flex gap-2">
                  <button onClick={() => logoRef.current?.click()} className="flex-1 bg-[#1c1a14] border border-[#2a2620] text-[#f2eee4] text-sm font-medium rounded-lg py-2">
                    Changer
                  </button>
                  <button onClick={removeLogo} className="text-[#d97a6c] p-2"><X size={18} /></button>
                </div>
              </div>
            ) : (
              <button onClick={() => logoRef.current?.click()} className="w-full flex items-center justify-center gap-2 bg-[#1c1a14] border border-dashed border-[#2a2620] text-[#8a8478] font-medium rounded-xl py-4">
                <ImagePlus size={16} /> Ajouter le logo
              </button>
            )}
            <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
          </div>
        </section>

        <section>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-3">Galerie (site public)</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4">
            <p className="text-[13px] text-[#8a8478] mb-3">
              Photos de vos réalisations passées, visibles par les clients sur le site public.
            </p>
            {gallery.length > 0 && (
              <div className="grid grid-cols-3 gap-2 mb-3">
                {gallery.map((g) => (
                  <div key={g.id} className="relative aspect-square rounded-lg overflow-hidden bg-[#1c1a14] border border-[#2a2620]">
                    <img src={g.photo} alt="" className="w-full h-full object-cover" />
                    <button onClick={() => removeGalleryItem(g.id)} className="absolute top-1 right-1 bg-black/60 rounded-full p-1 text-white">
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <button onClick={() => galleryRef.current?.click()} className="w-full flex items-center justify-center gap-2 bg-[#1c1a14] border border-dashed border-[#2a2620] text-[#8a8478] font-medium rounded-xl py-4">
              <Images size={16} /> Ajouter des photos
            </button>
            <input ref={galleryRef} type="file" accept="image/*" multiple className="hidden" onChange={handleGalleryUpload} />
          </div>
        </section>

        <section>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-3">Informations société</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-2 text-[#d4a72c] mb-1">
              <Building2 size={16} />
              <span className="text-sm font-semibold">Utilisées pour les factures PDF</span>
            </div>
            <CompanyField label="Nom" value={company.nom} onChange={(v) => updateCompanyField('nom', v)} />
            <CompanyField label="SIRET" value={company.siret} onChange={(v) => updateCompanyField('siret', v)} mono />
            <CompanyField label="N° TVA" value={company.tva} onChange={(v) => updateCompanyField('tva', v)} mono />
            <CompanyField label="Adresse" value={company.adresse} onChange={(v) => updateCompanyField('adresse', v)} />
            <CompanyField label="Dirigeant" value={company.dirigeant} onChange={(v) => updateCompanyField('dirigeant', v)} />
          </div>
        </section>

        <section>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-3">À propos (site public)</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4">
            <p className="text-[13px] text-[#8a8478] mb-3">
              Texte affiché sur la page "À propos" du site public. Modifiable à tout moment.
            </p>
            <textarea
              value={company.aProposTexte || ''}
              onChange={(e) => updateCompanyField('aProposTexte', e.target.value)}
              rows={8}
              className="input resize-none"
            />
          </div>
        </section>

        <section>
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#d97a6c] font-semibold rounded-xl py-3"
          >
            <LogOut size={16} /> Se déconnecter
          </button>
        </section>
      </div>

      <style>{`
        .input { width: 100%; background: #1c1a14; border: 1px solid #2a2620; border-radius: 10px; padding: 10px 12px; color: #f2eee4; font-size: 13.5px; outline: none; }
        .input:focus { border-color: #d4a72c; }
      `}</style>
    </div>
  );
}

function CompanyField({ label, value, onChange, mono }) {
  return (
    <div>
      <label className="block text-[11px] font-medium text-[#6a6458] mb-1">{label}</label>
      <input value={value || ''} onChange={(e) => onChange(e.target.value)} className={`input ${mono ? 'font-mono' : ''}`} />
    </div>
  );
}
