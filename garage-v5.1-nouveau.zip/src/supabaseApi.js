import { supabase } from './supabaseClient.js';

// ============================================================
// Couche d'accès aux données Supabase.
// Convention : la base utilise du snake_case (date_vente, prix_achat...),
// le code JS utilise du camelCase (dateVente, prixAchat...).
// Les fonctions toRow()/fromRow() font la conversion.
// ============================================================

function camelToSnake(obj) {
  const out = {};
  Object.entries(obj).forEach(([k, v]) => {
    const snake = k.replace(/[A-Z]/g, (m) => '_' + m.toLowerCase());
    out[snake] = v;
  });
  return out;
}

function snakeToCamel(obj) {
  const out = {};
  Object.entries(obj).forEach(([k, v]) => {
    const camel = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    out[camel] = v;
  });
  return out;
}

async function fetchAll(table, orderBy = null) {
  let query = supabase.from(table).select('*');
  if (orderBy) query = query.order(orderBy, { ascending: false });
  const { data, error } = await query;
  if (error) {
    console.error(`Erreur lecture ${table}:`, error.message);
    return [];
  }
  return (data || []).map(snakeToCamel);
}

async function insertRow(table, row) {
  const { data, error } = await supabase.from(table).insert(camelToSnake(row)).select().single();
  if (error) {
    console.error(`Erreur insertion ${table}:`, error.message);
    return null;
  }
  return snakeToCamel(data);
}

async function updateRow(table, id, patch) {
  const { data, error } = await supabase.from(table).update(camelToSnake(patch)).eq('id', id).select().single();
  if (error) {
    console.error(`Erreur mise à jour ${table}:`, error.message);
    return null;
  }
  return snakeToCamel(data);
}

async function deleteRow(table, id) {
  const { error } = await supabase.from(table).delete().eq('id', id);
  if (error) {
    console.error(`Erreur suppression ${table}:`, error.message);
    return false;
  }
  return true;
}

// ---------- Availability slots (agenda de créneaux RDV) ----------
export const SlotsAPI = {
  list: () => fetchAll('availability_slots', 'date'),
  insert: (s) => insertRow('availability_slots', s),
  remove: (id) => deleteRow('availability_slots', id),

  async listPublicFuture() {
    const today = new Date().toISOString().slice(0, 10);
    const { data, error } = await supabase
      .from('availability_slots')
      .select('*')
      .gte('date', today)
      .order('date', { ascending: true })
      .order('heure', { ascending: true });
    if (error) {
      console.error('Erreur lecture créneaux publics:', error.message);
      return [];
    }
    return (data || []).map(snakeToCamel);
  },

  // Réservation atomique via fonction Postgres sécurisée : évite qu'un créneau
  // soit pris en double si deux clients cliquent au même moment.
  async reserve(slotId, nom, telephone) {
    const { data, error } = await supabase.rpc('reserve_slot', {
      slot_id: slotId,
      nom,
      telephone,
    });
    if (error) {
      console.error('Erreur réservation créneau:', error.message);
      return false;
    }
    return data === true;
  },
};

// ---------- Gallery (réalisations passées) ----------
export const GalleryAPI = {
  list: () => fetchAll('gallery', 'ordre'),
  insert: (g) => insertRow('gallery', g),
  update: (id, patch) => updateRow('gallery', id, patch),
  remove: (id) => deleteRow('gallery', id),
  async listPublic() {
    const { data, error } = await supabase.from('gallery').select('*').order('ordre', { ascending: false });
    if (error) {
      console.error('Erreur lecture galerie publique:', error.message);
      return [];
    }
    return (data || []).map(snakeToCamel);
  },
};

// ---------- Public (site vitrine, sans authentification) ----------
export const PublicAPI = {
  async listPublishedVehicles() {
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('publie', true)
      .order('ordre', { ascending: false });
    if (error) {
      console.error('Erreur lecture véhicules publiés:', error.message);
      return [];
    }
    return (data || []).map(snakeToCamel);
  },

  async submitAppointment(appointment) {
    const row = camelToSnake({ ...appointment, source: 'site_public', valide: false });
    const { data, error } = await supabase.from('appointments').insert(row).select().single();
    if (error) {
      console.error('Erreur envoi RDV public:', error.message);
      return null;
    }
    return snakeToCamel(data);
  },

  async submitQuoteRequest(quoteRequest) {
    const row = camelToSnake({ ...quoteRequest, source: 'site_public', statut: 'devis', traite: false });
    const { data, error } = await supabase.from('quotes').insert(row).select().single();
    if (error) {
      console.error('Erreur envoi demande devis publique:', error.message);
      return null;
    }
    return snakeToCamel(data);
  },
};
// ---------- Vehicles ----------
export const VehiclesAPI = {
  list: () => fetchAll('vehicles', 'ordre'),
  insert: (v) => insertRow('vehicles', v),
  update: (id, patch) => updateRow('vehicles', id, patch),
  remove: (id) => deleteRow('vehicles', id),
};

// ---------- Clients ----------
export const ClientsAPI = {
  list: () => fetchAll('clients', 'created_at'),
  insert: (c) => insertRow('clients', c),
  update: (id, patch) => updateRow('clients', id, patch),
  remove: (id) => deleteRow('clients', id),
};

// ---------- Stock ----------
export const StockAPI = {
  list: () => fetchAll('stock', 'created_at'),
  insert: (s) => insertRow('stock', s),
  update: (id, patch) => updateRow('stock', id, patch),
  remove: (id) => deleteRow('stock', id),
};

// ---------- Appointments ----------
export const AppointmentsAPI = {
  list: () => fetchAll('appointments', 'created_at'),
  insert: (a) => insertRow('appointments', a),
  update: (id, patch) => updateRow('appointments', id, patch),
  remove: (id) => deleteRow('appointments', id),
};

// ---------- Quotes ----------
export const QuotesAPI = {
  list: () => fetchAll('quotes', 'created_at'),
  insert: (q) => insertRow('quotes', q),
  update: (id, patch) => updateRow('quotes', id, patch),
  remove: (id) => deleteRow('quotes', id),
};

// ---------- Prestations libres ----------
export const PrestationsLibresAPI = {
  list: () => fetchAll('prestations_libres', 'created_at'),
  insert: (p) => insertRow('prestations_libres', p),
  remove: (id) => deleteRow('prestations_libres', id),
};

// ---------- Company (une seule ligne par utilisateur) ----------
export const CompanyAPI = {
  async get() {
    const { data, error } = await supabase.from('company').select('*').maybeSingle();
    if (error) {
      console.error('Erreur lecture company:', error.message);
      return null;
    }
    return data ? snakeToCamel(data) : null;
  },
  async upsert(company) {
    const existing = await CompanyAPI.get();
    if (existing) {
      return updateRow('company', existing.id, company);
    }
    return insertRow('company', company);
  },
};
