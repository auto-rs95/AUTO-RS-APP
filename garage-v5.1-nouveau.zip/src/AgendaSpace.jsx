import React, { useState, useMemo, useEffect } from 'react';
import { ChevronLeft, Plus, X, Trash2, Clock, Check, Ban, CalendarDays, MapPin, PhoneCall, CalendarPlus } from 'lucide-react';
import { newAppointment, sortAppointments, formatDate, todayISO, PRESTATION_TYPES, wazeLink, telLink, newAvailabilitySlot } from './data.js';
import { SlotsAPI } from './supabaseApi.js';

function groupByDate(list) {
  const groups = {};
  list.forEach((a) => {
    const key = a.date || 'sans-date';
    if (!groups[key]) groups[key] = [];
    groups[key].push(a);
  });
  return groups;
}

function isPast(dateStr) {
  if (!dateStr) return false;
  return dateStr < todayISO();
}

export default function AgendaSpace({ appointments, onUpdateAll, onBack }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [tab, setTab] = useState('avenir'); // avenir | passes | creneaux
  const [slots, setSlots] = useState([]);
  const [showSlotForm, setShowSlotForm] = useState(false);

  useEffect(() => {
    SlotsAPI.list().then(setSlots);
  }, []);

  async function addSlot(data) {
    const created = await SlotsAPI.insert(newAvailabilitySlot(data));
    if (created) setSlots([...slots, created]);
    setShowSlotForm(false);
  }

  async function removeSlot(id) {
    await SlotsAPI.remove(id);
    setSlots(slots.filter((s) => s.id !== id));
  }

  function addAppointment(data) {
    onUpdateAll([...appointments, newAppointment(data)]);
    setShowForm(false);
  }

  function updateAppointment(id, patch) {
    onUpdateAll(appointments.map((a) => (a.id === id ? { ...a, ...patch } : a)));
  }

  function deleteAppointment(id) {
    onUpdateAll(appointments.filter((a) => a.id !== id));
    setEditing(null);
  }

  const sorted = sortAppointments(appointments);
  const upcoming = sorted.filter((a) => !isPast(a.date) && a.statut !== 'annule');
  const past = sortAppointments(appointments.filter((a) => isPast(a.date) || a.statut !== 'prevu')).reverse();

  const list = tab === 'avenir' ? upcoming : past;
  const grouped = useMemo(() => groupByDate(list), [list]);
  const dateKeys = Object.keys(grouped).sort((a, b) => (tab === 'avenir' ? a.localeCompare(b) : b.localeCompare(a)));

  if (editing) {
    return (
      <AppointmentForm
        title="Modifier le rendez-vous"
        initial={editing}
        onCancel={() => setEditing(null)}
        onSubmit={(data) => { updateAppointment(editing.id, data); setEditing(null); }}
        onDelete={() => deleteAppointment(editing.id)}
      />
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-28">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="font-display text-xl text-[#f2eee4]">Agenda</h1>
          <p className="text-[12px] text-[#8a8478]">{appointments.length} rendez-vous</p>
        </div>
      </div>

      <div className="px-5">
        <div className="flex bg-[#16140f] border border-[#2a2620] rounded-xl p-1 gap-1">
          <button
            onClick={() => setTab('avenir')}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'avenir' ? 'bg-[#7fc28a] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            À venir ({upcoming.length})
          </button>
          <button
            onClick={() => setTab('passes')}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'passes' ? 'bg-[#7fc28a] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            Passés
          </button>
          <button
            onClick={() => setTab('creneaux')}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'creneaux' ? 'bg-[#7fc28a] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            Créneaux publics
          </button>
        </div>
      </div>

      {(tab === 'avenir' || tab === 'passes') && (
        <div className="px-5 pt-4 space-y-5">
          {dateKeys.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
                <CalendarDays size={20} className="text-[#4a4438]" />
              </div>
              <p className="text-[#8a8478] text-sm">
                {tab === 'avenir' ? 'Aucun rendez-vous à venir.' : 'Aucun rendez-vous passé.'}
              </p>
            </div>
          ) : (
            dateKeys.map((dateKey) => (
              <div key={dateKey}>
                <h2 className="font-display text-sm text-[#8a8478] uppercase tracking-wide mb-2">
                  {dateKey === 'sans-date' ? 'Sans date' : formatDate(dateKey)}
                </h2>
                <div className="space-y-2">
                  {grouped[dateKey].map((a) => (
                    <AppointmentCard key={a.id} appt={a} onClick={() => setEditing(a)} />
                  ))}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'creneaux' && (
        <SlotsManager slots={slots} onAdd={() => setShowSlotForm(true)} onRemove={removeSlot} />
      )}

      {tab !== 'creneaux' && (
        <button
          onClick={() => setShowForm(true)}
          className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#7fc28a] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
          aria-label="Ajouter un rendez-vous"
        >
          <Plus size={26} strokeWidth={2.5} />
        </button>
      )}

      {tab === 'creneaux' && (
        <button
          onClick={() => setShowSlotForm(true)}
          className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#7fc28a] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
          aria-label="Ajouter un créneau"
        >
          <CalendarPlus size={24} />
        </button>
      )}

      {showForm && (
        <AppointmentForm
          title="Nouveau rendez-vous"
          onCancel={() => setShowForm(false)}
          onSubmit={addAppointment}
        />
      )}

      {showSlotForm && (
        <SlotForm onCancel={() => setShowSlotForm(false)} onSubmit={addSlot} />
      )}
    </div>
  );
}

function SlotsManager({ slots, onRemove }) {
  const today = todayISO();
  const future = slots.filter((s) => s.date >= today);
  const grouped = useMemo(() => groupByDate(future), [future]);
  const dateKeys = Object.keys(grouped).sort();

  return (
    <div className="px-5 pt-4 space-y-5">
      <p className="text-[12px] text-[#8a8478]">
        Ces créneaux sont visibles sur le site public. Un client peut en réserver un librement, sans validation de ta part.
      </p>
      {dateKeys.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
            <CalendarPlus size={20} className="text-[#4a4438]" />
          </div>
          <p className="text-[#8a8478] text-sm">Aucun créneau publié pour l'instant.</p>
        </div>
      ) : (
        dateKeys.map((dateKey) => (
          <div key={dateKey}>
            <h2 className="font-display text-sm text-[#8a8478] uppercase tracking-wide mb-2">{formatDate(dateKey)}</h2>
            <div className="space-y-2">
              {grouped[dateKey].map((s) => (
                <div key={s.id} className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#1c1a14] flex items-center justify-center">
                      <Clock size={14} className="text-[#7a7468]" />
                    </div>
                    <div>
                      <p className="font-mono text-sm text-[#f2eee4]">{s.heure}</p>
                      {s.reserve ? (
                        <p className="text-[11px] text-[#d97a6c]">Réservé — {s.reserveParNom}</p>
                      ) : (
                        <p className="text-[11px] text-[#7fc28a]">Disponible</p>
                      )}
                    </div>
                  </div>
                  <button onClick={() => onRemove(s.id)} className="text-[#5a5448]"><X size={16} /></button>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function SlotForm({ onCancel, onSubmit }) {
  const [date, setDate] = useState(todayISO());
  const [heure, setHeure] = useState('');

  function submit() {
    if (!date || !heure) return;
    onSubmit({ date, heure });
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={onCancel}>
      <div className="bg-[#16140f] border-t sm:border border-[#2a2620] rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 pb-7" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-[#f2eee4]">Nouveau créneau</h3>
          <button onClick={onCancel} className="text-[#8a8478]"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <Field label="Date">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" autoFocus />
          </Field>
          <Field label="Heure">
            <input type="time" value={heure} onChange={(e) => setHeure(e.target.value)} className="input font-mono" />
          </Field>
          <button
            onClick={submit}
            disabled={!date || !heure}
            className="w-full bg-[#7fc28a] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3 mt-2"
          >
            Publier ce créneau
          </button>
        </div>
        <style>{`
          .input { width: 100%; background: #1c1a14; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
          .input:focus { border-color: #7fc28a; }
        `}</style>
      </div>
    </div>
  );
}

function AppointmentCard({ appt, onClick }) {
  const statutStyle = {
    prevu: { label: 'Prévu', color: '#5b9bd5' },
    termine: { label: 'Terminé', color: '#7fc28a' },
    annule: { label: 'Annulé', color: '#d97a6c' },
  }[appt.statut] || { label: 'Prévu', color: '#5b9bd5' };

  return (
    <div className="w-full text-left bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5">
      <button onClick={onClick} className="w-full flex items-center gap-3 active:scale-[0.98] transition-transform">
        <div className="w-11 h-11 rounded-xl bg-[#1c1a14] flex flex-col items-center justify-center shrink-0 text-[#f2eee4]">
          <Clock size={14} className="text-[#7a7468]" />
          <span className="font-mono text-[11px] mt-0.5">{appt.heure || '—'}</span>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-[#f2eee4] truncate">{appt.typePrestation || 'Prestation'}</p>
          <p className="text-[12px] text-[#8a8478] truncate mt-0.5">
            {[appt.clientNom, appt.vehiculeInfo].filter(Boolean).join(' · ') || 'Sans détail'}
          </p>
        </div>
        <span
          className="text-[10px] font-semibold px-2 py-1 rounded-full shrink-0"
          style={{ backgroundColor: `${statutStyle.color}22`, color: statutStyle.color }}
        >
          {statutStyle.label}
        </span>
      </button>
      {(appt.clientTelephone || appt.adresse) && (
        <div className="flex gap-2 mt-3 pt-3 border-t border-[#2a2620]">
          {appt.clientTelephone && (
            <a
              href={telLink(appt.clientTelephone)}
              onClick={(e) => e.stopPropagation()}
              className="flex-1 flex items-center justify-center gap-1.5 bg-[#1c1a14] border border-[#2a2620] text-[#f2eee4] text-xs font-semibold rounded-lg py-2"
            >
              <PhoneCall size={12} /> Appeler
            </a>
          )}
          {appt.adresse && (
            <a
              href={wazeLink(appt.adresse)}
              target="_blank"
              rel="noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="flex-1 flex items-center justify-center gap-1.5 bg-[#1c1a14] border border-[#2a2620] text-[#f2eee4] text-xs font-semibold rounded-lg py-2"
            >
              <MapPin size={12} /> Itinéraire
            </a>
          )}
        </div>
      )}
    </div>
  );
}

function AppointmentForm({ title, initial, onCancel, onSubmit, onDelete }) {
  const [date, setDate] = useState(initial?.date || todayISO());
  const [heure, setHeure] = useState(initial?.heure || '');
  const [clientNom, setClientNom] = useState(initial?.clientNom || '');
  const [clientTelephone, setClientTelephone] = useState(initial?.clientTelephone || '');
  const [adresse, setAdresse] = useState(initial?.adresse || '');
  const [vehiculeInfo, setVehiculeInfo] = useState(initial?.vehiculeInfo || '');
  const [typePrestation, setTypePrestation] = useState(initial?.typePrestation || '');
  const [notes, setNotes] = useState(initial?.notes || '');
  const [statut, setStatut] = useState(initial?.statut || 'prevu');
  const [confirmDelete, setConfirmDelete] = useState(false);

  function handleSubmit() {
    if (!date) return;
    onSubmit({
      date, heure,
      clientNom: clientNom.trim(),
      clientTelephone: clientTelephone.trim(),
      adresse: adresse.trim(),
      vehiculeInfo: vehiculeInfo.trim(),
      typePrestation, notes: notes.trim(), statut,
    });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onCancel} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">{title}</h1>
      </div>

      <div className="px-5 pt-2 space-y-5">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date *">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
          </Field>
          <Field label="Heure">
            <input type="time" value={heure} onChange={(e) => setHeure(e.target.value)} className="input font-mono" />
          </Field>
        </div>

        <Field label="Voiture / véhicule">
          <input value={vehiculeInfo} onChange={(e) => setVehiculeInfo(e.target.value)} placeholder="Clio grise, AB-123-CD…" className="input" autoFocus />
        </Field>

        <Field label="Client (optionnel)">
          <input value={clientNom} onChange={(e) => setClientNom(e.target.value)} placeholder="M. Dupont" className="input" />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Téléphone">
            <input value={clientTelephone} onChange={(e) => setClientTelephone(e.target.value)} placeholder="06 12 34 56 78" className="input font-mono" />
          </Field>
          <Field label="Adresse">
            <input value={adresse} onChange={(e) => setAdresse(e.target.value)} placeholder="12 rue de la République" className="input" />
          </Field>
        </div>

        <Field label="Type de prestation">
          <div className="flex flex-wrap gap-2">
            {PRESTATION_TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTypePrestation(t)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
                  typePrestation === t ? 'bg-[#7fc28a] text-[#0a0a0a] border-[#7fc28a]' : 'text-[#8a8478] border-[#2a2620] bg-transparent'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </Field>

        {initial && (
          <Field label="Statut">
            <div className="flex gap-2">
              <StatutButton active={statut === 'prevu'} onClick={() => setStatut('prevu')} color="#5b9bd5" icon={<Clock size={13} />} label="Prévu" />
              <StatutButton active={statut === 'termine'} onClick={() => setStatut('termine')} color="#7fc28a" icon={<Check size={13} />} label="Terminé" />
              <StatutButton active={statut === 'annule'} onClick={() => setStatut('annule')} color="#d97a6c" icon={<Ban size={13} />} label="Annulé" />
            </div>
          </Field>
        )}

        <Field label="Notes">
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Détails utiles…" rows={3} className="input resize-none" />
        </Field>

        <button
          onClick={handleSubmit}
          disabled={!date}
          className="w-full bg-[#7fc28a] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3.5 mt-2 active:scale-[0.99] transition-transform"
        >
          {initial ? 'Enregistrer les modifications' : 'Ajouter le rendez-vous'}
        </button>

        {initial && onDelete && (
          <div className="pt-2">
            {!confirmDelete ? (
              <button onClick={() => setConfirmDelete(true)} className="w-full text-[#d97a6c] text-sm font-medium py-3 flex items-center justify-center gap-2">
                <Trash2 size={15} /> Supprimer ce rendez-vous
              </button>
            ) : (
              <div className="bg-[#2a1a16] border border-[#4d2d28] rounded-xl p-4">
                <p className="text-sm text-[#e8c8c2] mb-3">Suppression définitive. Confirmer ?</p>
                <div className="flex gap-2">
                  <button onClick={() => setConfirmDelete(false)} className="flex-1 bg-[#16140f] rounded-lg py-2.5 text-sm font-medium text-[#f2eee4]">Annuler</button>
                  <button onClick={onDelete} className="flex-1 bg-[#c44536] rounded-lg py-2.5 text-sm font-medium text-white">Supprimer</button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        .input { width: 100%; background: #16140f; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
        .input:focus { border-color: #7fc28a; }
        .input::placeholder { color: #5a5448; }
      `}</style>
    </div>
  );
}

function StatutButton({ active, onClick, color, icon, label }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold border"
      style={active ? { backgroundColor: color, borderColor: color, color: '#0a0a0a' } : { borderColor: '#2a2620', color: '#8a8478' }}
    >
      {icon} {label}
    </button>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}
