import { computeQuoteTotals, formatEURPrecise, formatEUR, formatDate, MENTIONS_LEGALES, PAIEMENT_STATUTS } from './data.js';

// Génère et télécharge un PDF de devis/facture en utilisant jsPDF (chargé via CDN, window.jspdf).
export function generateQuotePDF(quote, company) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const pageWidth = 210;
  const margin = 18;
  let y = 20;

  const isFacture = quote.statut === 'facture';
  const { ht, tva, ttc } = computeQuoteTotals(quote);

  // --- En-tête : logo + identité société ---
  if (company.logo) {
    try {
      doc.addImage(company.logo, 'PNG', margin, y, 26, 26);
    } catch (e) {
      // si le format n'est pas PNG, on tente JPEG en repli silencieux
      try { doc.addImage(company.logo, 'JPEG', margin, y, 26, 26); } catch (e2) { /* logo ignoré */ }
    }
  }

  const textX = company.logo ? margin + 32 : margin;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(20, 20, 20);
  doc.text(company.nom || '', textX, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(90, 90, 90);
  let infoY = y + 12;
  const infoLines = [
    company.adresse,
    company.siret ? `SIRET : ${company.siret}` : '',
    company.tva ? `TVA : ${company.tva}` : '',
  ].filter(Boolean);
  infoLines.forEach((line) => {
    doc.text(line, textX, infoY);
    infoY += 4.2;
  });

  // --- Titre document + numéro, aligné à droite ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(20, 20, 20);
  doc.text(isFacture ? 'FACTURE' : 'DEVIS', pageWidth - margin, y + 6, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(90, 90, 90);
  doc.text(`N° ${quote.numero}`, pageWidth - margin, y + 13, { align: 'right' });
  doc.text(`Date : ${formatDate(quote.date)}`, pageWidth - margin, y + 18, { align: 'right' });

  y = 55;
  doc.setDrawColor(210, 210, 210);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // --- Bloc client / véhicule ---
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(20, 20, 20);
  doc.text('Client', margin, y);
  doc.text('Véhicule', pageWidth / 2 + 5, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(60, 60, 60);
  const clientLines = [
    quote.clientNom,
    quote.clientTelephone,
    quote.clientEmail,
  ].filter(Boolean);
  const vehiculeLines = [
    [quote.vehiculeMarque, quote.vehiculeModele].filter(Boolean).join(' '),
    quote.plaque ? `Plaque : ${quote.plaque}` : '',
    quote.kilometrage !== '' && quote.kilometrage != null ? `Kilométrage : ${quote.kilometrage} km` : '',
  ].filter(Boolean);

  const maxLines = Math.max(clientLines.length, vehiculeLines.length, 1);
  for (let i = 0; i < maxLines; i++) {
    if (clientLines[i]) doc.text(clientLines[i], margin, y);
    if (vehiculeLines[i]) doc.text(vehiculeLines[i], pageWidth / 2 + 5, y);
    y += 4.5;
  }

  y += 8;

  // --- Tableau des lignes ---
  doc.setFillColor(20, 20, 20);
  doc.rect(margin, y, pageWidth - margin * 2, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(255, 255, 255);
  doc.text('Désignation', margin + 3, y + 5.5);
  doc.text('Montant TTC', pageWidth - margin - 3, y + 5.5, { align: 'right' });
  y += 8;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(40, 40, 40);
  doc.setFontSize(9.5);
  (quote.lignes || []).forEach((l, idx) => {
    const rowHeight = 8;
    if (idx % 2 === 1) {
      doc.setFillColor(245, 245, 245);
      doc.rect(margin, y, pageWidth - margin * 2, rowHeight, 'F');
    }
    doc.setTextColor(40, 40, 40);
    doc.text(l.libelle || '', margin + 3, y + 5.5);
    doc.text(formatEUR(l.montantTTC), pageWidth - margin - 3, y + 5.5, { align: 'right' });
    y += rowHeight;
  });

  y += 3;
  doc.setDrawColor(210, 210, 210);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // --- Totaux ---
  const totalsX = pageWidth - margin - 60;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(80, 80, 80);
  doc.text('Total HT', totalsX, y);
  doc.text(formatEURPrecise(ht), pageWidth - margin, y, { align: 'right' });
  y += 5.5;
  doc.text('TVA (20%)', totalsX, y);
  doc.text(formatEURPrecise(tva), pageWidth - margin, y, { align: 'right' });
  y += 7;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(20, 20, 20);
  doc.text('Total TTC', totalsX, y);
  doc.text(formatEUR(ttc), pageWidth - margin, y, { align: 'right' });
  y += 10;

  // --- Statut de paiement (facture uniquement) ---
  if (isFacture) {
    const statutInfo = PAIEMENT_STATUTS.find((s) => s.id === quote.paiementStatut) || PAIEMENT_STATUTS[0];
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    const rgb = hexToRgb(statutInfo.color);
    doc.setTextColor(rgb.r, rgb.g, rgb.b);
    doc.text(`Statut de paiement : ${statutInfo.label}`, margin, y);
    y += 8;
  }

  // --- Notes ---
  if (quote.notes) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(80, 80, 80);
    const noteLines = doc.splitTextToSize(quote.notes, pageWidth - margin * 2);
    doc.text(noteLines, margin, y);
    y += noteLines.length * 4.5 + 4;
  }

  // --- Mention légale ---
  y = Math.max(y, 250);
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  const mentionLines = doc.splitTextToSize(MENTIONS_LEGALES[quote.type], pageWidth - margin * 2);
  doc.text(mentionLines, margin, y);
  y += mentionLines.length * 3.8 + 6;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(150, 150, 150);
  doc.text(`${company.nom} — ${company.forme || ''} — ${company.dirigeant || ''}`, margin, 285);

  const filename = `${isFacture ? 'facture' : 'devis'}-${quote.numero}.pdf`;
  doc.save(filename);
}

function hexToRgb(hex) {
  const clean = hex.replace('#', '');
  const bigint = parseInt(clean, 16);
  return { r: (bigint >> 16) & 255, g: (bigint >> 8) & 255, b: bigint & 255 };
}
