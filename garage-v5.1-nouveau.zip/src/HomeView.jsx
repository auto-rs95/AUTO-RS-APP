import React, { useState, useEffect } from 'react';
import { Car, Wrench, Package, BarChart3, ChevronRight, Settings, CalendarDays, Receipt, Clock, AlertCircle } from 'lucide-react';
import { todayISO, sortAppointments, formatKm } from './data.js';
import { CompanyAPI } from './supabaseApi.js';

export default function HomeView({ vehicles, clients, stock, appointments, quotes, onNavigate }) {
  const vendus = vehicles.filter((v) => v.statut === 'vendu').length;
  const enCours = vehicles.length - vendus;

  const totalInterventions = clients.reduce((s, c) => s + (c.interventions || []).length, 0);

  const stockBas = stock.filter((s) => Number(s.quantite) <= 2).length;

  const today = todayISO();
  const todaysAppointments = sortAppointments(
    (appointments || []).filter((a) => a.date === today && a.statut !== 'annule')
  );
  const upcomingCount = (appointments || []).filter((a) => a.date >= today && a.statut !== 'annule').length;

  const devisEnAttente = (quotes || []).filter((q) => q.statut === 'devis').length;

  const [logo, setLogo] = useState(null);
  useEffect(() => {
    CompanyAPI.get().then((c) => setLogo(c?.logo || null));
  }, []);

  const hasTodayBlock = todaysAppointments.length > 0 || stockBas > 0;

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <header className="px-5 pt-8 pb-6 flex items-start justify-between">
        <div className="flex items-center gap-3">
          {logo ? (
            <img src={logo} alt="Logo" className="w-11 h-11 rounded-xl object-cover shrink-0 shadow-lg shadow-black/30" />
          ) : (
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#e8c25a] to-[#a8791a] flex items-center justify-center shrink-0 shadow-lg shadow-black/30">
              <span className="font-display text-[#0a0a0a] text-lg font-black tracking-tighter">RS</span>
            </div>
          )}
          <div>
            <h1 className="font-display text-xl text-[#f2eee4] leading-tight">AUTO RS</h1>
            <p className="text-[10px] text-[#a89a6e] uppercase tracking-[0.15em] font-medium">Multi Services</p>
          </div>
        </div>
        <button onClick={() => onNavigate('settings')} className="p-2 text-[#7a7468] mt-1">
          <Settings size={20} />
        </button>
      </header>

      {hasTodayBlock && (
        <div className="px-5 pb-3">
          <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-4 space-y-3">
            <h2 className="font-display text-sm text-[#8a8478] uppercase tracking-wide">Aujourd'hui</h2>

            {todaysAppointments.length > 0 && (
              <div className="space-y-2">
                {todaysAppointments.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => onNavigate('agenda')}
                    className="w-full flex items-center gap-2.5 text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#1c1a14] flex items-center justify-center shrink-0">
                      <Clock size={13} className="text-[#7fc28a]" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-[#f2eee4] truncate">
                        {a.heure ? `${a.heure} · ` : ''}{a.typePrestation || 'Rendez-vous'}
                      </p>
                      <p className="text-[11px] text-[#6a6458] truncate">
                        {[a.clientNom, a.vehiculeInfo].filter(Boolean).join(' · ') || 'Sans détail'}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {stockBas > 0 && (
              <button onClick={() => onNavigate('stock')} className="w-full flex items-center gap-2.5 text-left">
                <div className="w-8 h-8 rounded-lg bg-[#1c1a14] flex items-center justify-center shrink-0">
                  <AlertCircle size={13} className="text-[#d97a6c]" />
                </div>
                <p className="text-sm text-[#e8c8c2]">
                  {stockBas} pièce{stockBas !== 1 ? 's' : ''} en stock bas
                </p>
              </button>
            )}
          </div>
        </div>
      )}

      <div className="px-5 space-y-3">
        <SpaceCard
          icon={<Car size={20} />}
          title="Achat / Revente"
          subtitle={`${enCours} en cours · ${vendus} vendu${vendus !== 1 ? 's' : ''}`}
          onClick={() => onNavigate('vehicles')}
          accent="#d4a72c"
        />

        <SpaceCard
          icon={<CalendarDays size={20} />}
          title="Agenda"
          subtitle={`${(appointments || []).length} rendez-vous`}
          metric={upcomingCount > 0 ? String(upcomingCount) : null}
          metricLabel="à venir"
          onClick={() => onNavigate('agenda')}
          accent="#7fc28a"
        />

        <SpaceCard
          icon={<Wrench size={20} />}
          title="Clients & Prestations"
          subtitle={`${clients.length} client${clients.length !== 1 ? 's' : ''} · ${totalInterventions} intervention${totalInterventions !== 1 ? 's' : ''}`}
          onClick={() => onNavigate('clients')}
          accent="#5b9bd5"
        />

        <SpaceCard
          icon={<Package size={20} />}
          title="Stock pièces"
          subtitle={`${stock.length} référence${stock.length !== 1 ? 's' : ''}${stockBas > 0 ? ` · ${stockBas} en alerte` : ''}`}
          onClick={() => onNavigate('stock')}
          accent="#8a8478"
          alert={stockBas > 0}
        />

        <SpaceCard
          icon={<Receipt size={20} />}
          title="Devis & Factures"
          subtitle={`${(quotes || []).length} document${(quotes || []).length !== 1 ? 's' : ''}`}
          metric={devisEnAttente > 0 ? String(devisEnAttente) : null}
          metricLabel="devis en attente"
          onClick={() => onNavigate('quotes')}
          accent="#e07856"
        />

        <SpaceCard
          icon={<BarChart3 size={20} />}
          title="Statistiques"
          subtitle="Chiffre d'affaires, marges, TVA"
          onClick={() => onNavigate('stats')}
          accent="#c98bd6"
        />
      </div>

      <div className="px-5 mt-8">
        <div className="h-px bg-gradient-to-r from-transparent via-[#3a342a] to-transparent" />
        <p className="text-center text-[11px] text-[#5a5448] mt-4 font-mono">99 Av. Achille Peretti · Neuilly-sur-Seine</p>
      </div>
    </div>
  );
}

function SpaceCard({ icon, title, subtitle, metric, metricLabel, onClick, accent, alert }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-[#16140f] border border-[#2a2620] rounded-2xl p-4 flex items-center gap-4 active:scale-[0.98] transition-transform hover:border-[#3a342a]"
      style={{ borderLeftWidth: '3px', borderLeftColor: accent }}
    >
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
        style={{ backgroundColor: `${accent}1a`, color: accent }}
      >
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h2 className="font-display text-base text-[#f2eee4]">{title}</h2>
          {alert && <span className="w-1.5 h-1.5 rounded-full bg-[#d97a6c]" />}
        </div>
        <p className="text-[13px] text-[#8a8478] mt-0.5">{subtitle}</p>
      </div>
      {metric ? (
        <div className="text-right shrink-0">
          <p className="font-mono text-sm font-semibold text-[#f2eee4]">{metric}</p>
          <p className="text-[10px] text-[#6a6458]">{metricLabel}</p>
        </div>
      ) : (
        <ChevronRight size={18} className="text-[#4a4438] shrink-0" />
      )}
    </button>
  );
}
