import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import PublicSite from './PublicSite.jsx';
import LoginScreen from './LoginScreen.jsx';
import { supabase } from './supabaseClient.js';
import './index.css';

const isAdminPage = window.location.pathname.startsWith('/admin');

function Root() {
  const [session, setSession] = useState(undefined); // undefined = en cours de vérification

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  // Tout ce qui n'est pas /admin est le site public vitrine, sans authentification.
  if (!isAdminPage) return <PublicSite />;

  if (session === undefined) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#d4a72c] font-mono text-sm tracking-widest animate-pulse">CHARGEMENT…</div>
      </div>
    );
  }

  if (!session) {
    return <LoginScreen onLoggedIn={() => {}} />;
  }

  return <App />;
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>
);
