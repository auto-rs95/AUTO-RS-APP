import React, { useState, useMemo } from 'react';
import { ChevronLeft, Car, Wrench, Layers, Download } from 'lucide-react';
import {
  computeStats, listAvailableMonths, listAvailableYears, formatEUR, formatEURPrecise, exportAccountingCSV,
} from './data.js';

function monthLabel(key) {
  if (!key) return '';
  const [y, m] = key.split('-');
  const date = new Date(Number(y), Number(m) - 1, 1);
  return date.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
}

export default function StatsSpace({ vehicles, clients, quotes, onBack }) {
  const months = useMemo(() => listAvailableMonths(vehicles, clients), [vehicles, clients]);
  const years = useMemo(() => listAvailableYears(vehicles, clients), [vehicles, clients]);

  const [periodType, setPeriodType] = useState('all'); // all | month | year
  const [periodValue, setPeriodValue] = useState(months[0] || '');
  const [yearValue, setYearValue] = useState(years[0] || '');
  const [view, setView] = useState('combine'); // combine | separe

  const period =
    periodType === 'month' && periodValue ? { type: 'month', value: periodValue } :
    periodType === 'year' && yearValue ? { type: 'year', value: yearValue } :
    null;

  const stats = useMemo(() => computeStats(vehicles, clients, period), [vehicles, clients, period]);

  function handleExportCSV() {
    const csv = exportAccountingCSV(vehicles, clients, quotes || []);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `autors-export-comptable-${date}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">Statistiques</h1>
      </div>

      <div className="px-5 space-y-3">
        <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-5 px-5 scrollbar-none">
          <Chip active={periodType === 'all'} onClick={() => setPeriodType('all')} label="Tout" />
          <Chip active={periodType === 'month'} onClick={() => setPeriodType('month')} label="Par mois" />
          <Chip active={periodType === 'year'} onClick={() => setPeriodType('year')} label="Par année" />
        </div>

        {periodType === 'month' && months.length > 0 && (
          <select value={periodValue} onChange={(e) => setPeriodValue(e.target.value)} className="select-period">
            {months.map((m) => <option key={m} value={m}>{monthLabel(m)}</option>)}
          </select>
        )}
        {periodType === 'year' && years.length > 0 && (
          <select value={yearValue} onChange={(e) => setYearValue(e.target.value)} className="select-period">
            {years.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        )}
        {((periodType === 'month' && months.length === 0) || (periodType === 'year' && years.length === 0)) && (
          <p className="text-[#5a5448] text-xs">Pas encore de données pour cette vue.</p>
        )}

        <div className="flex bg-[#16140f] border border-[#2a2620] rounded-xl p-1 gap-1">
          <button
            onClick={() => setView('combine')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
              view === 'combine' ? 'bg-[#c98bd6] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            <Layers size={14} /> Combiné
          </button>
          <button
            onClick={() => setView('separe')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
              view === 'separe' ? 'bg-[#c98bd6] text-[#0a0a0a]' : 'text-[#8a8478]'
            }`}
          >
            Séparé
          </button>
        </div>
      </div>

      <div className="px-5 pt-5 space-y-5">
        {view === 'combine' ? (
          <>
            <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-5">
              <span className="text-xs font-medium text-[#8a8478] uppercase tracking-wide">Chiffre d'affaires net combiné (HT)</span>
              <div className="font-display text-3xl text-[#f2eee4] mt-1">{formatEUR(stats.caCombineHT)}</div>
              <p className="text-[11px] text-[#6a6458] mt-1">Marge nette véhicules + prestations HT</p>
              <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-[#2a2620]">
                <Stat label="TVA combinée totale" value={formatEURPrecise(stats.tvaCombinee)} accent="#d4a72c" />
                <Stat label="Véhicules + prestations" value={`${stats.nbVehiculesVendus + stats.nbPrestations}`} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <MiniCard icon={<Car size={14} />} label="Voitures vendues" value={String(stats.nbVehiculesVendus)} />
              <MiniCard icon={<Wrench size={14} />} label="Prestations" value={String(stats.nbPrestations)} />
            </div>
          </>
        ) : (
          <>
            <SectionBlock
              icon={<Car size={16} />}
              title="Achat / Revente"
              accent="#d4a72c"
              rows={[
                ["Chiffre d'affaires (ventes)", formatEUR(stats.vehicleCA)],
                ['Marge brute (base TVA)', formatEUR(stats.vehicleMargeBrute)],
                ['Marge nette (après dépenses)', formatEUR(stats.vehicleMargeNette)],
                ['TVA sur marge (20%)', formatEURPrecise(stats.vehicleTVA)],
                ['Véhicules vendus', String(stats.nbVehiculesVendus)],
              ]}
            />
            <SectionBlock
              icon={<Wrench size={16} />}
              title="Prestations mécaniques"
              accent="#5b9bd5"
              rows={[
                ['Total facturé HT', formatEUR(stats.prestaHT)],
                ['TVA (20%)', formatEURPrecise(stats.prestaTVA)],
                ['Total TTC', formatEUR(stats.prestaTTC)],
                ['Nombre de prestations', String(stats.nbPrestations)],
              ]}
            />
          </>
        )}

        <button
          onClick={handleExportCSV}
          className="w-full flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-3.5 active:scale-[0.99] transition-transform"
        >
          <Download size={16} /> Export comptable (CSV pour le comptable)
        </button>
        <p className="text-[11px] text-[#5a5448] text-center -mt-3">
          Fichier détaillé HT / TVA / TTC ligne par ligne, à transmettre tel quel à ton comptable.
        </p>
      </div>

      <style>{`
        .select-period {
          width: 100%; background: #16140f; border: 1px solid #2a2620; border-radius: 10px;
          padding: 10px 13px; color: #f2eee4; font-size: 14px; outline: none; appearance: none;
        }
        .select-period:focus { border-color: #c98bd6; }
      `}</style>
    </div>
  );
}

function Chip({ active, onClick, label }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
        active ? 'bg-[#c98bd6] text-[#0a0a0a] border-[#c98bd6]' : 'bg-transparent text-[#8a8478] border-[#2a2620]'
      }`}
    >
      {label}
    </button>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div>
      <p className="text-[10px] text-[#6a6458] uppercase tracking-wide">{label}</p>
      <p className="font-mono text-sm font-semibold mt-0.5" style={{ color: accent || '#f2eee4' }}>{value}</p>
    </div>
  );
}

function MiniCard({ icon, label, value }) {
  return (
    <div className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5">
      <div className="flex items-center gap-1.5 text-[#6a6458] text-[11px] mb-1">
        {icon}<span>{label}</span>
      </div>
      <p className="font-display text-xl text-[#f2eee4]">{value}</p>
    </div>
  );
}

function SectionBlock({ icon, title, accent, rows }) {
  return (
    <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-5" style={{ borderLeftWidth: '3px', borderLeftColor: accent }}>
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${accent}1a`, color: accent }}>
          {icon}
        </div>
        <h2 className="font-display text-base text-[#f2eee4]">{title}</h2>
      </div>
      <div className="space-y-2.5">
        {rows.map(([label, value]) => (
          <div key={label} className="flex items-center justify-between">
            <span className="text-[13px] text-[#8a8478]">{label}</span>
            <span className="font-mono text-sm font-semibold text-[#f2eee4]">{value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
