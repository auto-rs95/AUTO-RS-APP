// ============================================================
// CŒUR DE DONNÉES — Auto RS Multi Services
// Stockage: Supabase (base en ligne). Ce fichier contient les fonctions
// de fabrique (newX), de calcul (TVA, marges) et de formatage, indépendantes
// de la source de données. L'accès à Supabase se fait via supabaseApi.js.
// ============================================================

export function uid() {
  // UUID v4 — compatible avec le type `uuid` de PostgreSQL/Supabase.
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Repli si crypto.randomUUID indisponible (anciens navigateurs)
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

// ---------- Formatting ----------

export function formatEUR(n) {
  const v = Number(n) || 0;
  return v.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' €';
}

export function formatEURPrecise(n) {
  const v = Number(n) || 0;
  return v.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}

export function formatDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  if (isNaN(date)) return '—';
  return date.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatKm(km) {
  if (km === '' || km == null) return '—';
  return Number(km).toLocaleString('fr-FR') + ' km';
}

export function daysBetween(a, b) {
  if (!a || !b) return null;
  const d1 = new Date(a);
  const d2 = new Date(b);
  if (isNaN(d1) || isNaN(d2)) return null;
  return Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
}

// ---------- Vehicle (Achat / Revente) ----------

// ---------- Statut de vente (visible sur le site public) ----------

export const STATUT_VENTE = [
  { id: 'disponible', label: 'Disponible', color: '#7fc28a' },
  { id: 'preparation', label: 'En préparation', color: '#e3b341' },
  { id: 'vendu', label: 'Vendu', color: '#d97a6c' },
];

export function statutVenteInfo(id) {
  return STATUT_VENTE.find((s) => s.id === id) || STATUT_VENTE[0];
}

export const VEHICLE_STATUTS = [
  { id: 'reparation', label: 'En réparation', color: '#d4a72c' },
  { id: 'pret', label: 'Prêt à vendre', color: '#5b9bd5' },
  { id: 'negociation', label: 'En négociation', color: '#c98bd6' },
  { id: 'vendu', label: 'Vendu', color: '#7fc28a' },
];

export const DOCUMENT_TYPES = [
  { id: 'facture', label: 'Facture' },
  { id: 'carteGrise', label: 'Carte grise' },
  { id: 'controleTechnique', label: 'Contrôle technique' },
  { id: 'acteVente', label: 'Acte de vente' },
  { id: 'declarationAchat', label: "Déclaration d'achat" },
];

export function newVehicle(data = {}) {
  return {
    id: uid(),
    marque: data.marque || '',
    modele: data.modele || '',
    plaque: data.plaque || '',
    carburant: data.carburant || '',
    boite: data.boite || '',
    kilometrage: data.kilometrage ?? '',
    dateAchat: data.dateAchat || '',
    dateVente: data.dateVente || '',
    prixAchat: data.prixAchat || 0,
    prixVente: data.prixVente ?? '',
    statut: data.statut || 'reparation',
    acheteurNom: data.acheteurNom || '',
    acheteurContact: data.acheteurContact || '',
    remarques: data.remarques || '',
    photos: data.photos || [],
    photoPrincipaleIdx: data.photoPrincipaleIdx ?? null,
    documents: data.documents || {}, // { [DOCUMENT_TYPES.id]: base64Photo }
    depenses: data.depenses || [],
    ordre: data.ordre ?? Date.now(),
    publie: data.publie ?? false,
    statutVente: data.statutVente || 'disponible',
  };
}

export function vehiclePhotoPrincipale(v) {
  if (!v.photos || v.photos.length === 0) return null;
  const idx = v.photoPrincipaleIdx;
  if (idx != null && v.photos[idx]) return v.photos[idx];
  return v.photos[0];
}

export function leboncoinSearchLink(vehicle) {
  const q = [vehicle.marque, vehicle.modele].filter(Boolean).join(' ').trim();
  if (!q) return null;
  return `https://www.leboncoin.fr/recherche?category=2&text=${encodeURIComponent(q)}`;
}

export function buildTikTokShareText(vehicle) {
  const titre = [vehicle.marque, vehicle.modele].filter(Boolean).join(' ');
  const km = vehicle.kilometrage !== '' && vehicle.kilometrage != null ? `${Number(vehicle.kilometrage).toLocaleString('fr-FR')} km` : '';
  const lines = [
    `${titre || 'Véhicule'} 🔧`,
    km ? `${km} au compteur` : '',
    vehicle.carburant ? `${vehicle.carburant}${vehicle.boite ? ' · ' + vehicle.boite : ''}` : '',
    '',
    '#autors95 #mecaniqueauto #voccasion #garage',
  ].filter(Boolean);
  return lines.join('\n');
}

export function computeVehicleTotals(v) {
  const depenses = (v.depenses || []).reduce((s, d) => s + (Number(d.montant) || 0), 0);
  const achat = Number(v.prixAchat) || 0;
  const vente = v.prixVente !== '' && v.prixVente != null ? Number(v.prixVente) : null;
  const coutTotal = achat + depenses;
  const margeBrute = vente != null ? vente - achat : null; // marge TVA = vente - achat (hors dépenses, base légale)
  const margeNette = vente != null ? vente - coutTotal : null; // marge réelle après dépenses
  // TVA sur marge: marge brute (vente - achat) x 20/120, jamais négative
  const tva = margeBrute != null && margeBrute > 0 ? (margeBrute * 20) / 120 : 0;
  return { depenses, achat, vente, coutTotal, margeBrute, margeNette, tva };
}

// ---------- Client & Prestations (mécanique) ----------

export function newClient(data = {}) {
  return {
    id: uid(),
    nom: data.nom || '',
    telephone: data.telephone || '',
    adresse: data.adresse || '',
    vehiculeMarque: data.vehiculeMarque || '',
    vehiculeModele: data.vehiculeModele || '',
    plaque: data.plaque || '',
    kilometrage: data.kilometrage ?? '',
    remarques: data.remarques || '',
    interventions: data.interventions || [],
  };
}

export function newIntervention(data = {}) {
  return {
    id: uid(),
    date: data.date || todayISO(),
    piece: data.piece || '',
    kilometrage: data.kilometrage ?? '',
    prixPieceTTC: data.prixPieceTTC ?? data.prixPiece ?? 0,
    tarifMainOeuvreTTC: data.tarifMainOeuvreTTC ?? data.tarifMainOeuvre ?? 0,
    dureeHeures: data.dureeHeures ?? '',
    notes: data.notes || '',
    facture: data.facture || null,
  };
}

// La saisie se fait en TTC (prix réellement facturé au client).
// Le HT et la TVA sont déduits du TTC : HT = TTC / 1.20, TVA = TTC - HT.
export function computeInterventionTotal(it) {
  const pieceTTC = Number(it.prixPieceTTC ?? it.prixPiece) || 0;
  const moTTC = Number(it.tarifMainOeuvreTTC ?? it.tarifMainOeuvre) || 0;
  const ttc = pieceTTC + moTTC;
  const ht = ttc / 1.2;
  const tva = ttc - ht;
  const moHT = moTTC / 1.2; // seule la main d'œuvre compte pour la rentabilité horaire
  const duree = Number(it.dureeHeures) || 0;
  const rentabiliteHoraire = duree > 0 ? moHT / duree : null;
  return { ht, tva, ttc, pieceTTC, moTTC, rentabiliteHoraire };
}

export function computeClientTotals(client) {
  const interventions = client.interventions || [];
  const totalHT = interventions.reduce((s, it) => s + computeInterventionTotal(it).ht, 0);
  const totalTVA = interventions.reduce((s, it) => s + computeInterventionTotal(it).tva, 0);
  return { totalHT, totalTVA, totalTTC: totalHT + totalTVA, count: interventions.length };
}

export function isClientFidele(client) {
  return (client.interventions || []).length >= 3;
}

// Suggestion de relance révision : si la dernière intervention remonte à plus de
// 10 000 km (estimation, faute de connaître le kilométrage actuel réel) ou plus de 8 mois.
export function revisionSuggestion(client) {
  const interventions = client.interventions || [];
  if (interventions.length === 0) return null;
  const derniere = [...interventions].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0))[0];
  if (!derniere.date) return null;
  const joursDepuis = daysBetween(derniere.date, todayISO());
  if (joursDepuis == null) return null;
  const kmDerniere = Number(derniere.kilometrage) || 0;
  const kmActuel = Number(client.kilometrage) || 0;
  const ecartKm = kmActuel > 0 && kmDerniere > 0 ? kmActuel - kmDerniere : null;
  const suggereParTemps = joursDepuis >= 240; // ~8 mois
  const suggereParKm = ecartKm != null && ecartKm >= 10000;
  if (!suggereParTemps && !suggereParKm) return null;
  return { joursDepuis, ecartKm, derniere };
}

// ---------- Créneaux de disponibilité (agenda public) ----------

export function newAvailabilitySlot(data = {}) {
  return {
    id: uid(),
    date: data.date || todayISO(),
    heure: data.heure || '',
    reserve: data.reserve ?? false,
    reserveParNom: data.reserveParNom || '',
    reserveParTelephone: data.reserveParTelephone || '',
  };
}

// ---------- Rendez-vous (agenda local, sans réservation client) ----------

export const PRESTATION_TYPES = [
  'Vidange', 'Plaquettes / disques de frein', 'Diagnostic panne', 'Révision complète',
  'Pneumatiques', 'Embrayage', 'Courroie de distribution', 'Climatisation', 'Carrosserie', 'Autre',
];

export function newAppointment(data = {}) {
  return {
    id: uid(),
    date: data.date || todayISO(),
    heure: data.heure || '',
    clientNom: data.clientNom || '',
    clientTelephone: data.clientTelephone || '',
    adresse: data.adresse || '',
    vehiculeInfo: data.vehiculeInfo || '',
    typePrestation: data.typePrestation || '',
    notes: data.notes || '',
    statut: data.statut || 'prevu', // prevu | termine | annule
  };
}

// ---------- Site public : catégories de devis ----------

export const CATEGORIES_PANNE = [
  'Voyant moteur allumé',
  'Fumée noire',
  'Fumée blanche',
  'Perte de puissance',
  'Le moteur ne démarre pas',
  'Claquement / bruit anormal',
  'Fuite (huile, liquide…)',
  'Autre panne',
];

export const CATEGORIES_ENTRETIEN = [
  { id: 'vidange', label: 'Vidange', prixIndicatif: 60 },
  { id: 'filtres', label: 'Filtres (air / habitacle)', prixIndicatif: 25 },
  { id: 'plaquettes_avant', label: 'Plaquettes de frein avant', prixIndicatif: 90 },
  { id: 'disques_plaquettes_avant', label: 'Plaquettes + disques avant', prixIndicatif: 180 },
  { id: 'plaquettes_arriere', label: 'Plaquettes de frein arrière', prixIndicatif: 80 },
  { id: 'disques_plaquettes_arriere', label: 'Plaquettes + disques arrière', prixIndicatif: 160 },
  { id: 'courroie_accessoires', label: "Courroie d'accessoires", prixIndicatif: 90 },
  { id: 'nettoyage_fap', label: 'Nettoyage filtre à particules (FAP)', prixIndicatif: 150 },
  { id: 'distribution', label: 'Distribution', prixIndicatif: 350 },
  { id: 'batterie', label: 'Batterie', prixIndicatif: 120 },
  { id: 'climatisation', label: 'Climatisation', prixIndicatif: 70 },
  { id: 'autre_entretien', label: 'Autre entretien', prixIndicatif: 0 },
];

export function estimateEntretienTotal(selectedIds) {
  return CATEGORIES_ENTRETIEN
    .filter((c) => selectedIds.includes(c.id))
    .reduce((sum, c) => sum + c.prixIndicatif, 0);
}

// ---------- Calcul de frais de déplacement ----------
// Distance approximative "à vol d'oiseau" entre deux points GPS (formule de Haversine).
export function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function computeFraisDeplacement(distanceKmValue, company) {
  const kmOfferts = Number(company?.kmOfferts ?? 7);
  const tarifParKm = Number(company?.tarifParKm ?? 2);
  const distance = Number(distanceKmValue) || 0;
  const kmFactures = Math.max(0, distance - kmOfferts);
  return {
    distance,
    kmOfferts,
    kmFactures,
    montant: Math.round(kmFactures * tarifParKm * 100) / 100,
  };
}

export function wazeLink(adresse) {
  if (!adresse || !adresse.trim()) return null;
  return `https://waze.com/ul?q=${encodeURIComponent(adresse.trim())}&navigate=yes`;
}

export function telLink(telephone) {
  if (!telephone || !telephone.trim()) return null;
  return `tel:${telephone.trim().replace(/\s+/g, '')}`;
}

export function sortAppointments(list) {
  return [...list].sort((a, b) => {
    const da = `${a.date || ''}T${a.heure || '00:00'}`;
    const db = `${b.date || ''}T${b.heure || '00:00'}`;
    return da.localeCompare(db);
  });
}

// ---------- Devis & Factures ----------

export const MENTIONS_LEGALES = {
  achatRevente: "TVA non applicable sur le prix de vente, conformément à l'article 297 A du CGI — taxation sur la marge (régime des biens d'occasion).",
  prestationMecanique: "Devis établi sous réserve de démontage. Le prix définitif sera confirmé après inspection complète du véhicule et pourra être ajusté en cas de panne ou pièce supplémentaire constatée.",
};

export function newQuoteLine(data = {}) {
  return {
    id: uid(),
    libelle: data.libelle || '',
    montantTTC: data.montantTTC ?? 0,
  };
}

export function newQuote(data = {}) {
  return {
    id: uid(),
    numero: data.numero || '',
    type: data.type || 'prestationMecanique', // 'achatRevente' | 'prestationMecanique'
    statut: data.statut || 'devis', // 'devis' | 'facture'
    paiementStatut: data.paiementStatut || 'nonPaye', // 'nonPaye' | 'partiel' | 'paye' (pertinent seulement si statut = facture)
    date: data.date || todayISO(),
    clientNom: data.clientNom || '',
    clientTelephone: data.clientTelephone || '',
    clientEmail: data.clientEmail || '',
    vehiculeMarque: data.vehiculeMarque || '',
    vehiculeModele: data.vehiculeModele || '',
    plaque: data.plaque || '',
    kilometrage: data.kilometrage ?? '',
    lignes: data.lignes || [],
    notes: data.notes || '',
  };
}

export const PAIEMENT_STATUTS = [
  { id: 'nonPaye', label: 'Non payée', color: '#d97a6c' },
  { id: 'partiel', label: 'Payée partiellement', color: '#d4a72c' },
  { id: 'paye', label: 'Payée', color: '#7fc28a' },
];

// ---------- Bibliothèque de prestations / articles réutilisables ----------

export function newPrestationLibre(data = {}) {
  return {
    id: uid(),
    libelle: data.libelle || '',
    montantTTC: data.montantTTC ?? 0,
  };
}

export function computeQuoteTotals(quote) {
  const ttc = (quote.lignes || []).reduce((s, l) => s + (Number(l.montantTTC) || 0), 0);
  const ht = ttc / 1.2;
  const tva = ttc - ht;
  return { ht, tva, ttc };
}

export function nextQuoteNumber(quotes) {
  const year = new Date().getFullYear();
  const count = quotes.filter((q) => q.numero && q.numero.includes(String(year))).length;
  return `${year}-${String(count + 1).padStart(3, '0')}`;
}

// ---------- Galerie (réalisations passées) ----------

export function newGalleryItem(data = {}) {
  return {
    id: uid(),
    photo: data.photo || '',
    legende: data.legende || '',
    ordre: data.ordre ?? Date.now(),
  };
}

// ---------- Stock pièces ----------

export function newStockItem(data = {}) {
  return {
    id: uid(),
    reference: data.reference || '',
    designation: data.designation || '',
    quantite: data.quantite ?? 0,
  };
}

// ---------- Company info (pour futures factures PDF) ----------

export const DEFAULT_COMPANY = {
  nom: 'AUTO RS MULTI SERVICES',
  siret: '934 418 575 00015',
  siren: '934 418 575',
  tva: 'FR66934418575',
  forme: 'SAS',
  adresse: '99 Avenue Achille Peretti, 92200 Neuilly-sur-Seine',
  dirigeant: 'Firas Chamakh',
  tauxTVA: 20,
  logo: null, // image base64, ajoutée depuis les Réglages
  adresseBase: 'Argenteuil',
  kmOfferts: 7,
  tarifParKm: 2,
  aProposTexte: `Auto RS Multi Services, c'est un garage qui vient à vous.

Fini les rendez-vous à rallonge, les journées sans voiture, les trajets en garage. On se déplace directement chez vous, ou là où votre véhicule se trouve, avec le matériel et l'expertise pour intervenir sur place.

Entretien courant, diagnostic de panne, réparation mécanique : chaque intervention est faite avec la même exigence qu'en atelier, sans le déplacement pour vous.

Transparence sur les tarifs, devis clair avant toute intervention, et un seul objectif : vous redonner votre temps.`,
};

// ---------- Export comptable (CSV) ----------
// Format pensé pour un comptable : une ligne par opération, avec date, type,
// libellé, HT, TVA, TTC — directement importable dans Excel ou un logiciel compta.

function csvEscape(value) {
  const str = String(value ?? '');
  if (str.includes(';') || str.includes('"') || str.includes('\n')) {
    return '"' + str.replace(/"/g, '""') + '"';
  }
  return str;
}

function csvNumber(n) {
  return (Number(n) || 0).toFixed(2).replace('.', ',');
}

export function exportAccountingCSV(vehicles, clients, quotes = []) {
  const rows = [
    ['Date', 'Type', 'Référence / Plaque', 'Libellé', 'Montant HT', 'TVA', 'Montant TTC', 'Régime TVA'],
  ];

  // Ventes de véhicules (TVA sur marge)
  vehicles
    .filter((v) => v.dateVente && v.prixVente !== '' && v.prixVente != null)
    .forEach((v) => {
      const { margeBrute, tva } = computeVehicleTotals(v);
      rows.push([
        v.dateVente,
        'Vente véhicule',
        v.plaque || '',
        `${v.marque} ${v.modele}`.trim(),
        csvNumber((margeBrute || 0) - tva),
        csvNumber(tva),
        csvNumber(margeBrute || 0),
        'TVA sur marge (art. 297 A CGI)',
      ]);
      // Dépenses liées au véhicule (charges)
      (v.depenses || []).forEach((d) => {
        rows.push([
          d.date || v.dateAchat || '',
          'Charge véhicule',
          v.plaque || '',
          d.libelle || '',
          csvNumber(d.montant),
          csvNumber(0),
          csvNumber(d.montant),
          'N/A (charge)',
        ]);
      });
    });

  // Prestations mécaniques (TVA normale 20%)
  clients.forEach((c) => {
    (c.interventions || []).forEach((it) => {
      const { ht, tva, ttc } = computeInterventionTotal(it);
      rows.push([
        it.date || '',
        'Prestation mécanique',
        c.plaque || '',
        `${it.piece || 'Intervention'} — ${c.nom || ''}`.trim(),
        csvNumber(ht),
        csvNumber(tva),
        csvNumber(ttc),
        'TVA normale 20%',
      ]);
    });
  });

  // Factures émises (devis transformés en facture)
  quotes.filter((q) => q.statut === 'facture').forEach((q) => {
    const { ht, tva, ttc } = computeQuoteTotals(q);
    rows.push([
      q.date || '',
      q.type === 'achatRevente' ? 'Facture achat/revente' : 'Facture prestation',
      q.plaque || q.numero || '',
      `Facture ${q.numero || ''} — ${q.clientNom || ''}`.trim(),
      csvNumber(ht),
      csvNumber(tva),
      csvNumber(ttc),
      q.type === 'achatRevente' ? 'TVA sur marge (art. 297 A CGI)' : 'TVA normale 20%',
    ]);
  });

  rows.sort((a, b) => {
    if (a === rows[0]) return -1;
    if (b === rows[0]) return 1;
    return (a[0] || '').localeCompare(b[0] || '');
  });

  const csv = rows.map((row) => row.map(csvEscape).join(';')).join('\n');
  return '\uFEFF' + csv; // BOM pour compatibilité Excel avec les accents
}

// ---------- Statistics ----------

export function monthKey(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d)) return null;
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function computeStats(vehicles, clients, period) {
  // period: { type: 'month'|'year', value: '2026-06' or '2026' } or null for all-time
  function inPeriod(dateStr) {
    if (!period) return true;
    if (!dateStr) return false;
    if (period.type === 'year') return dateStr.slice(0, 4) === period.value;
    return monthKey(dateStr) === period.value;
  }

  const soldVehicles = vehicles.filter((v) => v.dateVente && inPeriod(v.dateVente));
  const vehicleCA = soldVehicles.reduce((s, v) => s + (Number(v.prixVente) || 0), 0);
  const vehicleAchatTotal = soldVehicles.reduce((s, v) => s + (Number(v.prixAchat) || 0), 0);
  const vehicleDepenses = soldVehicles.reduce(
    (s, v) => s + (v.depenses || []).reduce((s2, d) => s2 + (Number(d.montant) || 0), 0),
    0
  );
  const vehicleMargeBrute = vehicleCA - vehicleAchatTotal;
  const vehicleTVA = vehicleMargeBrute > 0 ? (vehicleMargeBrute * 20) / 120 : 0;
  const vehicleMargeNette = vehicleCA - vehicleAchatTotal - vehicleDepenses;

  const allInterventions = [];
  clients.forEach((c) => {
    (c.interventions || []).forEach((it) => {
      if (inPeriod(it.date)) allInterventions.push(it);
    });
  });
  const prestaHT = allInterventions.reduce((s, it) => s + computeInterventionTotal(it).ht, 0);
  const prestaTVA = allInterventions.reduce((s, it) => s + computeInterventionTotal(it).tva, 0);

  return {
    nbVehiculesVendus: soldVehicles.length,
    vehicleCA,
    vehicleMargeBrute,
    vehicleMargeNette,
    vehicleTVA,
    nbPrestations: allInterventions.length,
    prestaHT,
    prestaTVA,
    prestaTTC: prestaHT + prestaTVA,
    caCombineHT: vehicleMargeNette + prestaHT,
    tvaCombinee: vehicleTVA + prestaTVA,
  };
}

export function listAvailableMonths(vehicles, clients) {
  const set = new Set();
  vehicles.forEach((v) => {
    if (v.dateVente) set.add(monthKey(v.dateVente));
  });
  clients.forEach((c) =>
    (c.interventions || []).forEach((it) => {
      if (it.date) set.add(monthKey(it.date));
    })
  );
  return Array.from(set).filter(Boolean).sort().reverse();
}

export function listAvailableYears(vehicles, clients) {
  const months = listAvailableMonths(vehicles, clients);
  const years = new Set(months.map((m) => m.slice(0, 4)));
  return Array.from(years).sort().reverse();
}
