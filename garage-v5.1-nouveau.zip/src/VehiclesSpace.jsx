import React, { useState, useRef } from 'react';
import {
  ChevronLeft, Plus, Search, X, Edit3, Trash2, Calendar, Gauge,
  Camera, ImagePlus, ChevronUp, ChevronDown, Fuel, User, Car, FileText, Check, ExternalLink, Share2, Copy, Globe,
} from 'lucide-react';
import {
  newVehicle, computeVehicleTotals, formatEUR, formatEURPrecise, formatDate, formatKm,
  daysBetween, uid, VEHICLE_STATUTS, todayISO, vehiclePhotoPrincipale, DOCUMENT_TYPES,
  leboncoinSearchLink, buildTikTokShareText, STATUT_VENTE,
} from './data.js';

const CARBURANTS = ['Essence', 'Diesel', 'Hybride', 'Électrique', 'GPL'];
const BOITES = ['Manuelle', 'Automatique'];

function statutInfo(id) {
  return VEHICLE_STATUTS.find((s) => s.id === id) || VEHICLE_STATUTS[0];
}

export default function VehiclesSpace({ vehicles, onUpdateAll, onBack }) {
  const [view, setView] = useState('list');
  const [activeId, setActiveId] = useState(null);
  const [search, setSearch] = useState('');
  const [filterStatut, setFilterStatut] = useState('all');

  function persist(next) {
    onUpdateAll(next);
  }

  function addVehicle(data) {
    persist([newVehicle(data), ...vehicles]);
    setView('list');
  }

  function updateVehicle(id, patch) {
    persist(vehicles.map((v) => (v.id === id ? { ...v, ...patch } : v)));
  }

  function deleteVehicle(id) {
    persist(vehicles.filter((v) => v.id !== id));
    setView('list');
    setActiveId(null);
  }

  function reorder(newOrderIds) {
    const map = Object.fromEntries(vehicles.map((v) => [v.id, v]));
    persist(newOrderIds.map((id) => map[id]));
  }

  const active = vehicles.find((v) => v.id === activeId);

  const filtered = vehicles.filter((v) => {
    if (filterStatut !== 'all' && v.statut !== filterStatut) return false;
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      v.marque.toLowerCase().includes(q) ||
      v.modele.toLowerCase().includes(q) ||
      (v.plaque || '').toLowerCase().includes(q)
    );
  });

  if (view === 'form') {
    return <VehicleForm title="Nouveau véhicule" onCancel={() => setView('list')} onSubmit={addVehicle} />;
  }

  if (view === 'detail' && active) {
    return (
      <VehicleDetail
        vehicle={active}
        onBack={() => { setView('list'); setActiveId(null); }}
        onUpdate={(patch) => updateVehicle(active.id, patch)}
        onDelete={() => deleteVehicle(active.id)}
      />
    );
  }

  return (
    <div className="max-w-2xl mx-auto pb-28">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="font-display text-xl text-[#f2eee4]">Achat / Revente</h1>
          <p className="text-[12px] text-[#8a8478]">{vehicles.length} véhicule{vehicles.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div className="px-5 space-y-3">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6a6458]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher marque, modèle, plaque…"
            className="w-full bg-[#16140f] border border-[#2a2620] rounded-xl pl-9 pr-9 py-2.5 text-sm text-[#f2eee4] outline-none focus:border-[#d4a72c]"
          />
          {search && (
            <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6a6458]">
              <X size={14} />
            </button>
          )}
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-5 px-5 scrollbar-none">
          <FilterChip active={filterStatut === 'all'} onClick={() => setFilterStatut('all')} label="Tous" />
          {VEHICLE_STATUTS.map((s) => (
            <FilterChip
              key={s.id}
              active={filterStatut === s.id}
              onClick={() => setFilterStatut(s.id)}
              label={s.label}
              color={s.color}
            />
          ))}
        </div>
      </div>

      <div className="px-5 pt-4">
        {filtered.length === 0 ? (
          <EmptyState hasVehicles={vehicles.length > 0} />
        ) : (
          <ReorderableList
            vehicles={filtered}
            onReorder={reorder}
            onOpen={(id) => { setActiveId(id); setView('detail'); }}
            reorderDisabled={!!search.trim() || filterStatut !== 'all'}
          />
        )}
      </div>

      <button
        onClick={() => setView('form')}
        className="fixed bottom-6 right-1/2 translate-x-[calc(50%+1px)] sm:translate-x-0 sm:right-[max(1.5rem,calc(50%-20rem+1.5rem))] bg-[#d4a72c] text-[#0a0a0a] rounded-full w-14 h-14 flex items-center justify-center shadow-lg shadow-black/50 active:scale-95 transition-transform"
        aria-label="Ajouter un véhicule"
      >
        <Plus size={26} strokeWidth={2.5} />
      </button>
    </div>
  );
}

function FilterChip({ active, onClick, label, color }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
        active ? 'bg-[#d4a72c] text-[#0a0a0a] border-[#d4a72c]' : 'bg-transparent text-[#8a8478] border-[#2a2620]'
      }`}
    >
      {color && !active && <span className="inline-block w-1.5 h-1.5 rounded-full mr-1.5" style={{ backgroundColor: color }} />}
      {label}
    </button>
  );
}

function EmptyState({ hasVehicles }) {
  return (
    <div className="text-center py-16">
      <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
        <Car size={22} className="text-[#4a4438]" />
      </div>
      <p className="text-[#8a8478] text-sm">{hasVehicles ? 'Aucun résultat.' : "Aucun véhicule pour l'instant."}</p>
      {!hasVehicles && <p className="text-[#5a5448] text-xs mt-1">Ajoute ta première voiture pour démarrer le suivi.</p>}
    </div>
  );
}

function ShareTikTokButton({ vehicle }) {
  const [copied, setCopied] = useState(false);

  async function handleShare() {
    const text = buildTikTokShareText(vehicle);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      // Fallback si clipboard API indisponible
      alert(text);
    }
  }

  return (
    <button
      onClick={handleShare}
      className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-2.5 text-sm"
    >
      {copied ? <Check size={14} className="text-[#7fc28a]" /> : <Share2 size={14} />}
      {copied ? 'Copié !' : 'Texte TikTok'}
    </button>
  );
}

function VehicleThumbnail({ vehicle }) {
  const photo = vehiclePhotoPrincipale(vehicle);
  if (photo) {
    return (
      <img src={photo} alt="" className="w-11 h-11 rounded-lg object-cover shrink-0 border border-[#2a2620]" />
    );
  }
  return (
    <div className="w-11 h-11 rounded-lg bg-[#1c1a14] border border-[#2a2620] flex items-center justify-center shrink-0">
      <Car size={16} className="text-[#4a4438]" />
    </div>
  );
}

// ---------- Reorder list (boutons monter/descendre — fiable sur tactile) ----------

function ReorderableList({ vehicles, onReorder, onOpen, reorderDisabled }) {
  const order = vehicles.map((v) => v.id);
  const byId = Object.fromEntries(vehicles.map((v) => [v.id, v]));

  function move(idx, direction) {
    const newOrder = [...order];
    const target = idx + direction;
    if (target < 0 || target >= newOrder.length) return;
    [newOrder[idx], newOrder[target]] = [newOrder[target], newOrder[idx]];
    onReorder(newOrder);
  }

  return (
    <div className="space-y-2.5">
      {order.map((id, idx) => {
        const v = byId[id];
        if (!v) return null;
        const { margeNette } = computeVehicleTotals(v);
        const statut = statutInfo(v.statut);
        return (
          <div
            key={id}
            className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 flex items-center gap-3"
          >
            {!reorderDisabled && (
              <div className="flex flex-col gap-1 shrink-0">
                <button
                  onClick={() => move(idx, -1)}
                  disabled={idx === 0}
                  className="w-7 h-6 rounded-md bg-[#1c1a14] border border-[#2a2620] flex items-center justify-center text-[#8a8478] disabled:opacity-30"
                  aria-label="Monter"
                >
                  <ChevronUp size={14} />
                </button>
                <button
                  onClick={() => move(idx, 1)}
                  disabled={idx === order.length - 1}
                  className="w-7 h-6 rounded-md bg-[#1c1a14] border border-[#2a2620] flex items-center justify-center text-[#8a8478] disabled:opacity-30"
                  aria-label="Descendre"
                >
                  <ChevronDown size={14} />
                </button>
              </div>
            )}
            <button onClick={() => onOpen(id)} className="flex-1 min-w-0 text-left flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <VehicleThumbnail vehicle={v} />
                <div className="min-w-0">
                  <h3 className="font-display text-[15px] text-[#f2eee4] truncate">{v.marque} {v.modele}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                      style={{ backgroundColor: `${statut.color}22`, color: statut.color }}
                    >
                      {statut.label}
                    </span>
                    <span className="font-mono text-[11px] text-[#6a6458]">{v.plaque || '—'}</span>
                  </div>
                </div>
              </div>
              <div className="text-right shrink-0">
                {margeNette != null ? (
                  <span className={`font-mono text-sm font-semibold ${margeNette >= 0 ? 'text-[#7fc28a]' : 'text-[#d97a6c]'}`}>
                    {margeNette >= 0 ? '+' : ''}{formatEUR(margeNette)}
                  </span>
                ) : (
                  <span className="font-mono text-xs text-[#6a6458]">en cours</span>
                )}
              </div>
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ---------- Form (create / edit) ----------


function VehicleForm({ title, initial, onCancel, onSubmit }) {
  const [marque, setMarque] = useState(initial?.marque || '');
  const [modele, setModele] = useState(initial?.modele || '');
  const [plaque, setPlaque] = useState(initial?.plaque || '');
  const [carburant, setCarburant] = useState(initial?.carburant || '');
  const [boite, setBoite] = useState(initial?.boite || '');
  const [kilometrage, setKilometrage] = useState(initial?.kilometrage ?? '');
  const [dateAchat, setDateAchat] = useState(initial?.dateAchat || '');
  const [dateVente, setDateVente] = useState(initial?.dateVente || '');
  const [prixAchat, setPrixAchat] = useState(initial?.prixAchat ?? '');
  const [prixVente, setPrixVente] = useState(initial?.prixVente ?? '');
  const [statut, setStatut] = useState(initial?.statut || 'reparation');
  const [acheteurNom, setAcheteurNom] = useState(initial?.acheteurNom || '');
  const [acheteurContact, setAcheteurContact] = useState(initial?.acheteurContact || '');
  const [remarques, setRemarques] = useState(initial?.remarques || '');

  function handleSubmit() {
    if (!marque.trim()) return;
    onSubmit({
      marque: marque.trim(),
      modele: modele.trim(),
      plaque: plaque.trim().toUpperCase(),
      carburant,
      boite,
      kilometrage: kilometrage === '' ? '' : Number(kilometrage),
      dateAchat,
      dateVente,
      prixAchat: prixAchat === '' ? 0 : Number(prixAchat),
      prixVente: prixVente === '' ? '' : Number(prixVente),
      statut,
      acheteurNom: acheteurNom.trim(),
      acheteurContact: acheteurContact.trim(),
      remarques,
    });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onCancel} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="font-display text-xl text-[#f2eee4]">{title}</h1>
      </div>

      <div className="px-5 pt-2 space-y-5">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Marque *">
            <input value={marque} onChange={(e) => setMarque(e.target.value)} placeholder="Peugeot" className="input" autoFocus />
          </Field>
          <Field label="Modèle">
            <input value={modele} onChange={(e) => setModele(e.target.value)} placeholder="208" className="input" />
          </Field>
        </div>

        <Field label="Plaque">
          <input value={plaque} onChange={(e) => setPlaque(e.target.value)} placeholder="AB-123-CD" className="input font-mono" />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Carburant">
            <select value={carburant} onChange={(e) => setCarburant(e.target.value)} className="input">
              <option value="">—</option>
              {CARBURANTS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Boîte">
            <select value={boite} onChange={(e) => setBoite(e.target.value)} className="input">
              <option value="">—</option>
              {BOITES.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </Field>
        </div>

        <Field label="Kilométrage">
          <input type="number" inputMode="numeric" value={kilometrage} onChange={(e) => setKilometrage(e.target.value)} placeholder="120000" className="input font-mono" />
        </Field>

        <Field label="Statut">
          <div className="flex flex-wrap gap-2">
            {VEHICLE_STATUTS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setStatut(s.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
                  statut === s.id ? 'text-[#0a0a0a]' : 'text-[#8a8478] border-[#2a2620] bg-transparent'
                }`}
                style={statut === s.id ? { backgroundColor: s.color, borderColor: s.color } : {}}
              >
                {s.label}
              </button>
            ))}
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Date d'achat">
            <input type="date" value={dateAchat} onChange={(e) => setDateAchat(e.target.value)} className="input" />
          </Field>
          <Field label="Date de vente">
            <input type="date" value={dateVente} onChange={(e) => setDateVente(e.target.value)} className="input" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Prix d'achat (€)">
            <input type="number" inputMode="decimal" value={prixAchat} onChange={(e) => setPrixAchat(e.target.value)} placeholder="0" className="input font-mono" />
          </Field>
          <Field label="Prix de vente (€)">
            <input type="number" inputMode="decimal" value={prixVente} onChange={(e) => setPrixVente(e.target.value)} placeholder="0" className="input font-mono" />
          </Field>
        </div>

        {(statut === 'vendu' || prixVente !== '') && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Acheteur (nom)">
              <input value={acheteurNom} onChange={(e) => setAcheteurNom(e.target.value)} placeholder="M. Dupont" className="input" />
            </Field>
            <Field label="Contact acheteur">
              <input value={acheteurContact} onChange={(e) => setAcheteurContact(e.target.value)} placeholder="06 12 34 56 78" className="input" />
            </Field>
          </div>
        )}

        <Field label="Remarques">
          <textarea value={remarques} onChange={(e) => setRemarques(e.target.value)} placeholder="État général, travaux à prévoir, historique…" rows={4} className="input resize-none" />
        </Field>

        <button
          onClick={handleSubmit}
          disabled={!marque.trim()}
          className="w-full bg-[#d4a72c] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3.5 mt-2 active:scale-[0.99] transition-transform"
        >
          Enregistrer le véhicule
        </button>
      </div>

      <GlobalInputStyles />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function GlobalInputStyles() {
  return (
    <style>{`
      .input { width: 100%; background: #16140f; border: 1px solid #2a2620; border-radius: 10px; padding: 11px 13px; color: #f2eee4; font-size: 14.5px; outline: none; }
      .input:focus { border-color: #d4a72c; }
      .input::placeholder { color: #5a5448; }
      select.input { appearance: none; }
    `}</style>
  );
}

// ---------- Detail ----------

function DocumentsSection({ documents, onUpload, onRemove }) {
  const refs = useRef({});

  return (
    <div>
      <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-2">Documents</h2>
      <div className="space-y-2">
        {DOCUMENT_TYPES.map((doc) => {
          const photo = documents[doc.id];
          return (
            <div key={doc.id} className="bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText size={15} className="text-[#6a6458] shrink-0" />
                  <span className="text-sm text-[#f2eee4] truncate">{doc.label}</span>
                </div>
                {photo ? (
                  <button onClick={() => onRemove(doc.id)} className="text-[#d97a6c] text-xs font-medium flex items-center gap-1 shrink-0">
                    <X size={12} /> Retirer
                  </button>
                ) : (
                  <button
                    onClick={() => refs.current[doc.id]?.click()}
                    className="text-[#d4a72c] text-xs font-semibold flex items-center gap-1 shrink-0"
                  >
                    <Camera size={13} /> Ajouter
                  </button>
                )}
                <input
                  ref={(el) => (refs.current[doc.id] = el)}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => onUpload(doc.id, e.target.files?.[0])}
                />
              </div>
              {photo && (
                <img src={photo} alt={doc.label} className="w-full max-h-40 object-cover rounded-lg border border-[#2a2620] mt-3" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function VehicleDetail({ vehicle, onBack, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showDepForm, setShowDepForm] = useState(false);
  const fileInputRef = useRef(null);

  const { depenses, achat, vente, margeNette, margeBrute, tva } = computeVehicleTotals(vehicle);
  const holdDays = daysBetween(vehicle.dateAchat, vehicle.dateVente || todayISO());
  const statut = statutInfo(vehicle.statut);

  if (editing) {
    return (
      <VehicleForm
        title="Modifier le véhicule"
        initial={vehicle}
        onCancel={() => setEditing(false)}
        onSubmit={(data) => { onUpdate(data); setEditing(false); }}
      />
    );
  }

  function handleFiles(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    Promise.all(
      files.map(
        (f) =>
          new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.readAsDataURL(f);
          })
      )
    ).then((urls) => onUpdate({ photos: [...(vehicle.photos || []), ...urls] }));
    e.target.value = '';
  }

  function addDepense(dep) {
    onUpdate({ depenses: [...(vehicle.depenses || []), { id: uid(), ...dep }] });
    setShowDepForm(false);
  }

  function deleteDepense(id) {
    onUpdate({ depenses: vehicle.depenses.filter((d) => d.id !== id) });
  }

  function removePhoto(idx) {
    const newPhotos = vehicle.photos.filter((_, i) => i !== idx);
    let newIdx = vehicle.photoPrincipaleIdx;
    if (newIdx === idx) newIdx = null;
    else if (newIdx != null && newIdx > idx) newIdx -= 1;
    onUpdate({ photos: newPhotos, photoPrincipaleIdx: newIdx });
  }

  function setPhotoPrincipale(idx) {
    onUpdate({ photoPrincipaleIdx: idx });
  }

  function handleDocumentUpload(docId, file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      onUpdate({ documents: { ...(vehicle.documents || {}), [docId]: reader.result } });
    };
    reader.readAsDataURL(file);
  }

  function removeDocument(docId) {
    const next = { ...(vehicle.documents || {}) };
    delete next[docId];
    onUpdate({ documents: next });
  }

  return (
    <div className="max-w-2xl mx-auto pb-10">
      <div className="px-5 pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
          <div>
            <h1 className="font-display text-xl text-[#f2eee4] leading-tight">{vehicle.marque} {vehicle.modele}</h1>
            <p className="font-mono text-xs text-[#8a8478]">{vehicle.plaque || 'Sans plaque'}</p>
          </div>
        </div>
        <button onClick={() => setEditing(true)} className="p-2 rounded-lg bg-[#16140f] border border-[#2a2620] text-[#8a8478]">
          <Edit3 size={16} />
        </button>
      </div>

      <div className="px-5">
        <span
          className="inline-block text-xs font-semibold px-2.5 py-1 rounded-full"
          style={{ backgroundColor: `${statut.color}22`, color: statut.color }}
        >
          {statut.label}
        </span>
      </div>

      <div className="px-5 pt-3">
        <button
          onClick={() => onUpdate({ publie: !vehicle.publie })}
          className="w-full flex items-center justify-between bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5"
        >
          <div className="flex items-center gap-2.5">
            <Globe size={16} className={vehicle.publie ? 'text-[#7fc28a]' : 'text-[#6a6458]'} />
            <div className="text-left">
              <p className="text-sm font-medium text-[#f2eee4]">Visible sur le site public</p>
              <p className="text-[11px] text-[#6a6458]">
                {vehicle.publie ? 'Affiché dans "Véhicules en vente"' : 'Caché du site public'}
              </p>
            </div>
          </div>
          <div
            className="w-11 h-6 rounded-full relative transition-colors shrink-0"
            style={{ backgroundColor: vehicle.publie ? '#7fc28a' : '#2a2620' }}
          >
            <div
              className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform"
              style={{ transform: vehicle.publie ? 'translateX(22px)' : 'translateX(2px)' }}
            />
          </div>
        </button>

        {vehicle.publie && (
          <div className="mt-2.5 grid grid-cols-3 gap-2">
            {STATUT_VENTE.map((s) => (
              <button
                key={s.id}
                onClick={() => onUpdate({ statutVente: s.id })}
                className="py-2 rounded-lg text-[11px] font-semibold border flex items-center justify-center gap-1.5"
                style={
                  vehicle.statutVente === s.id
                    ? { backgroundColor: s.color, borderColor: s.color, color: '#0a0a0a' }
                    : { borderColor: '#2a2620', color: '#8a8478' }
                }
              >
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: vehicle.statutVente === s.id ? '#0a0a0a' : s.color }} />
                {s.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="px-5 pt-4 space-y-5">
        <div className="bg-[#16140f] border border-[#2a2620] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-[#8a8478] uppercase tracking-wide">Marge nette</span>
            {holdDays != null && (
              <span className="font-mono text-[11px] text-[#6a6458]">{holdDays}j {vehicle.dateVente ? 'de détention' : 'écoulés'}</span>
            )}
          </div>
          <div className={`font-display text-3xl ${margeNette == null ? 'text-[#8a8478]' : margeNette >= 0 ? 'text-[#7fc28a]' : 'text-[#d97a6c]'}`}>
            {margeNette == null ? 'En cours' : `${margeNette >= 0 ? '+' : ''}${formatEUR(margeNette)}`}
          </div>
          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[#2a2620]">
            <Stat label="Achat" value={formatEUR(achat)} />
            <Stat label="Dépenses" value={formatEUR(depenses)} />
            <Stat label="Vente" value={vente != null ? formatEUR(vente) : '—'} />
          </div>
          {margeBrute != null && (
            <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-[#2a2620]">
              <Stat label="Marge brute (TVA)" value={formatEUR(margeBrute)} />
              <Stat label="TVA sur marge (20%)" value={formatEURPrecise(tva)} />
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <a
            href={leboncoinSearchLink(vehicle)}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 bg-[#16140f] border border-[#2a2620] text-[#f2eee4] font-semibold rounded-xl py-2.5 text-sm"
          >
            <ExternalLink size={14} /> Vérifier le prix
          </a>
          <ShareTikTokButton vehicle={vehicle} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <InfoCard icon={<Calendar size={14} />} label="Date d'achat" value={formatDate(vehicle.dateAchat)} />
          <InfoCard icon={<Calendar size={14} />} label="Date de vente" value={vehicle.dateVente ? formatDate(vehicle.dateVente) : 'Non vendu'} />
          <InfoCard icon={<Gauge size={14} />} label="Kilométrage" value={formatKm(vehicle.kilometrage)} />
          <InfoCard icon={<Fuel size={14} />} label="Carburant / Boîte" value={[vehicle.carburant, vehicle.boite].filter(Boolean).join(' · ') || '—'} />
        </div>

        {vehicle.statut === 'vendu' && (vehicle.acheteurNom || vehicle.acheteurContact) && (
          <InfoCard icon={<User size={14} />} label="Acheteur" value={[vehicle.acheteurNom, vehicle.acheteurContact].filter(Boolean).join(' · ')} full />
        )}

        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478]">Dépenses ({(vehicle.depenses || []).length})</h2>
            <button onClick={() => setShowDepForm(true)} className="text-[#d4a72c] text-xs font-semibold flex items-center gap-1">
              <Plus size={14} /> Ajouter
            </button>
          </div>
          {(vehicle.depenses || []).length === 0 ? (
            <p className="text-[#5a5448] text-sm py-3">Aucune dépense enregistrée.</p>
          ) : (
            <div className="space-y-2">
              {vehicle.depenses.map((d) => (
                <div key={d.id} className="flex items-center justify-between bg-[#16140f] border border-[#2a2620] rounded-lg px-3.5 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm text-[#f2eee4] truncate">{d.libelle}</p>
                    {d.date && <p className="font-mono text-[10px] text-[#6a6458]">{formatDate(d.date)}</p>}
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono text-sm text-[#d97a6c]">-{formatEUR(d.montant)}</span>
                    <button onClick={() => deleteDepense(d.id)} className="text-[#5a5448]"><X size={15} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478]">Photos ({(vehicle.photos || []).length})</h2>
            <button onClick={() => fileInputRef.current?.click()} className="text-[#d4a72c] text-xs font-semibold flex items-center gap-1">
              <ImagePlus size={14} /> Ajouter
            </button>
            <input ref={fileInputRef} type="file" accept="image/*" multiple capture="environment" className="hidden" onChange={handleFiles} />
          </div>
          {(vehicle.photos || []).length === 0 ? (
            <button onClick={() => fileInputRef.current?.click()} className="w-full border border-dashed border-[#2a2620] rounded-xl py-8 flex flex-col items-center gap-2 text-[#5a5448]">
              <Camera size={22} />
              <span className="text-sm">Ajouter une photo</span>
            </button>
          ) : (
            <>
              <p className="text-[11px] text-[#5a5448] mb-2">Touche une photo pour la définir comme photo principale (étoile).</p>
              <div className="grid grid-cols-3 gap-2">
                {vehicle.photos.map((src, i) => {
                  const isPrincipale = (vehicle.photoPrincipaleIdx ?? 0) === i;
                  return (
                    <button
                      key={i}
                      onClick={() => setPhotoPrincipale(i)}
                      className="relative aspect-square rounded-lg overflow-hidden bg-[#16140f] border-2"
                      style={{ borderColor: isPrincipale ? '#d4a72c' : '#2a2620' }}
                    >
                      <img src={src} alt="" className="w-full h-full object-cover" />
                      {isPrincipale && (
                        <span className="absolute top-1 left-1 bg-[#d4a72c] rounded-full p-0.5">
                          <Check size={10} className="text-[#0a0a0a]" />
                        </span>
                      )}
                      <span
                        onClick={(e) => { e.stopPropagation(); removePhoto(i); }}
                        className="absolute top-1 right-1 bg-black/60 rounded-full p-1 text-white"
                      >
                        <X size={12} />
                      </span>
                    </button>
                  );
                })}
              </div>
            </>
          )}
        </div>

        <DocumentsSection
          documents={vehicle.documents || {}}
          onUpload={handleDocumentUpload}
          onRemove={removeDocument}
        />

        <div>
          <h2 className="font-display text-sm uppercase tracking-wide text-[#8a8478] mb-2">Remarques</h2>
          <div className="bg-[#16140f] border border-[#2a2620] rounded-xl p-4 min-h-[60px]">
            <p className="text-sm text-[#c4bfb2] whitespace-pre-wrap">{vehicle.remarques || '—'}</p>
          </div>
        </div>

        <div className="pt-4">
          {!confirmDelete ? (
            <button onClick={() => setConfirmDelete(true)} className="w-full text-[#d97a6c] text-sm font-medium py-3 flex items-center justify-center gap-2">
              <Trash2 size={15} /> Supprimer ce véhicule
            </button>
          ) : (
            <div className="bg-[#2a1a16] border border-[#4d2d28] rounded-xl p-4">
              <p className="text-sm text-[#e8c8c2] mb-3">Suppression définitive. Confirmer ?</p>
              <div className="flex gap-2">
                <button onClick={() => setConfirmDelete(false)} className="flex-1 bg-[#16140f] rounded-lg py-2.5 text-sm font-medium text-[#f2eee4]">Annuler</button>
                <button onClick={onDelete} className="flex-1 bg-[#c44536] rounded-lg py-2.5 text-sm font-medium text-white">Supprimer</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showDepForm && <DepenseModal onClose={() => setShowDepForm(false)} onSubmit={addDepense} />}
      <GlobalInputStyles />
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <p className="text-[10px] text-[#6a6458] uppercase tracking-wide">{label}</p>
      <p className="font-mono text-sm font-semibold text-[#f2eee4] mt-0.5">{value}</p>
    </div>
  );
}

function InfoCard({ icon, label, value, full }) {
  return (
    <div className={`bg-[#16140f] border border-[#2a2620] rounded-xl p-3.5 ${full ? 'col-span-2' : ''}`}>
      <div className="flex items-center gap-1.5 text-[#6a6458] text-[11px] mb-1">
        {icon}<span>{label}</span>
      </div>
      <p className="text-sm font-medium text-[#f2eee4]">{value}</p>
    </div>
  );
}

function DepenseModal({ onClose, onSubmit }) {
  const [libelle, setLibelle] = useState('');
  const [montant, setMontant] = useState('');
  const [date, setDate] = useState(todayISO());

  function submit() {
    if (!libelle.trim() || montant === '') return;
    onSubmit({ libelle: libelle.trim(), montant: Number(montant), date });
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-end sm:items-center justify-center z-50" onClick={onClose}>
      <div className="bg-[#16140f] border-t sm:border border-[#2a2620] rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 pb-7" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-lg text-[#f2eee4]">Nouvelle dépense</h3>
          <button onClick={onClose} className="text-[#8a8478]"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <Field label="Libellé">
            <input value={libelle} onChange={(e) => setLibelle(e.target.value)} placeholder="Plaquettes de frein, peinture…" className="input" autoFocus />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Montant (€)">
              <input type="number" inputMode="decimal" value={montant} onChange={(e) => setMontant(e.target.value)} placeholder="0" className="input font-mono" />
            </Field>
            <Field label="Date">
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
            </Field>
          </div>
          <button
            onClick={submit}
            disabled={!libelle.trim() || montant === ''}
            className="w-full bg-[#d4a72c] disabled:bg-[#2a2620] disabled:text-[#5a5448] text-[#0a0a0a] font-semibold rounded-xl py-3 mt-2"
          >
            Ajouter
          </button>
        </div>
        <GlobalInputStyles />
      </div>
    </div>
  );
}
