import React, { useState, useEffect } from 'react';
import HomeView from './HomeView.jsx';
import VehiclesSpace from './VehiclesSpace.jsx';
import ClientsSpace from './ClientsSpace.jsx';
import StockSpace from './StockSpace.jsx';
import StatsSpace from './StatsSpace.jsx';
import AgendaSpace from './AgendaSpace.jsx';
import QuotesSpace from './QuotesSpace.jsx';
import SettingsView from './SettingsView.jsx';
import {
  VehiclesAPI, ClientsAPI, StockAPI, AppointmentsAPI, QuotesAPI,
} from './supabaseApi.js';
import { supabase } from './supabaseClient.js';

// Réconcilie une ancienne et une nouvelle liste : déduit quoi insérer,
// mettre à jour, ou supprimer, puis envoie les bons appels à l'API Supabase.
// Permet aux composants enfants de continuer à fonctionner avec un simple
// onUpdateAll(nouvelleListe), comme avec le localStorage avant.
async function reconcile(api, prevList, nextList) {
  const prevIds = new Set(prevList.map((x) => x.id));
  const nextIds = new Set(nextList.map((x) => x.id));

  const toDelete = prevList.filter((x) => !nextIds.has(x.id));
  const toInsert = nextList.filter((x) => !prevIds.has(x.id));
  const toUpdate = nextList.filter((x) => {
    if (!prevIds.has(x.id)) return false;
    const prev = prevList.find((p) => p.id === x.id);
    return JSON.stringify(prev) !== JSON.stringify(x);
  });

  await Promise.all([
    ...toDelete.map((x) => api.remove(x.id)),
    ...toInsert.map((x) => api.insert(x)),
    ...toUpdate.map((x) => api.update(x.id, x)),
  ]);
}

export default function App() {
  const [route, setRoute] = useState('home');
  const [vehicles, setVehicles] = useState([]);
  const [clients, setClients] = useState([]);
  const [stock, setStock] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [syncError, setSyncError] = useState(null);

  async function loadAll() {
    const [v, c, s, a, q] = await Promise.all([
      VehiclesAPI.list(),
      ClientsAPI.list(),
      StockAPI.list(),
      AppointmentsAPI.list(),
      QuotesAPI.list(),
    ]);
    setVehicles(v);
    setClients(c);
    setStock(s);
    setAppointments(a);
    setQuotes(q);
  }

  useEffect(() => {
    loadAll().then(() => setLoaded(true));
  }, []);

  async function safeReconcile(api, prevList, nextList, setLocal) {
    setLocal(nextList); // mise à jour optimiste immédiate, l'app reste fluide
    try {
      await reconcile(api, prevList, nextList);
      setSyncError(null);
    } catch (e) {
      setSyncError("Erreur de synchronisation. Vérifie ta connexion internet.");
    }
  }

  function updateVehicles(next) {
    safeReconcile(VehiclesAPI, vehicles, next, setVehicles);
  }

  function updateClients(next) {
    safeReconcile(ClientsAPI, clients, next, setClients);
  }

  function updateStock(next) {
    safeReconcile(StockAPI, stock, next, setStock);
  }

  function updateAppointments(next) {
    safeReconcile(AppointmentsAPI, appointments, next, setAppointments);
  }

  function updateQuotes(next) {
    safeReconcile(QuotesAPI, quotes, next, setQuotes);
  }

  async function handleLogout() {
    await supabase.auth.signOut();
  }

  if (!loaded) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#d4a72c] font-mono text-sm tracking-widest animate-pulse">CHARGEMENT…</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#f2eee4]" style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Oswald:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
        .font-display { font-family: 'Oswald', system-ui, sans-serif; font-weight: 600; letter-spacing: -0.01em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .scrollbar-none::-webkit-scrollbar { display: none; }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(0.8); }
      `}</style>

      {syncError && (
        <div className="bg-[#c44536] text-white text-xs px-4 py-2 text-center font-medium">
          {syncError}
        </div>
      )}

      {route === 'home' && (
        <HomeView vehicles={vehicles} clients={clients} stock={stock} appointments={appointments} quotes={quotes} onNavigate={setRoute} />
      )}

      {route === 'vehicles' && (
        <VehiclesSpace vehicles={vehicles} onUpdateAll={updateVehicles} onBack={() => setRoute('home')} />
      )}

      {route === 'clients' && (
        <ClientsSpace clients={clients} onUpdateAll={updateClients} onBack={() => setRoute('home')} />
      )}

      {route === 'stock' && (
        <StockSpace stock={stock} onUpdateAll={updateStock} onBack={() => setRoute('home')} />
      )}

      {route === 'stats' && (
        <StatsSpace vehicles={vehicles} clients={clients} quotes={quotes} onBack={() => setRoute('home')} />
      )}

      {route === 'agenda' && (
        <AgendaSpace appointments={appointments} onUpdateAll={updateAppointments} onBack={() => setRoute('home')} />
      )}

      {route === 'quotes' && (
        <QuotesSpace quotes={quotes} onUpdateAll={updateQuotes} onBack={() => setRoute('home')} />
      )}

      {route === 'settings' && (
        <SettingsView onBack={() => setRoute('home')} onDataImported={loadAll} onLogout={handleLogout} />
      )}
    </div>
  );
}

