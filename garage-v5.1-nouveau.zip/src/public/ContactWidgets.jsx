import React from 'react';
import { Award, ShieldCheck, Eye, Wrench } from 'lucide-react';

const WHATSAPP_NUMBER = '33612345678';
const TIKTOK_HANDLE = 'auto.rs95';

export function ContactButtons({ context }) {
  const message = encodeURIComponent(context ? `Bonjour, je vous contacte au sujet de : ${context}` : 'Bonjour, je vous contacte depuis votre site Auto RS.');

  return (
    <div className="grid grid-cols-3 gap-2.5">
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`}
        target="_blank"
        rel="noreferrer"
        className="flex flex-col items-center gap-1.5 bg-[#16140f] border border-[#252119] rounded-xl py-3.5"
      >
        <WhatsAppIcon />
        <span className="text-[11px] text-[#a39a86] font-medium">WhatsApp</span>
      </a>
      <a
        href={`mailto:contact@autors-multiservices.fr?subject=${encodeURIComponent('Contact site Auto RS')}`}
        className="flex flex-col items-center gap-1.5 bg-[#16140f] border border-[#252119] rounded-xl py-3.5"
      >
        <span className="text-[#e3b341] text-lg">✉</span>
        <span className="text-[11px] text-[#a39a86] font-medium">Email</span>
      </a>
      <a
        href={`https://www.tiktok.com/@${TIKTOK_HANDLE}`}
        target="_blank"
        rel="noreferrer"
        className="flex flex-col items-center gap-1.5 bg-[#16140f] border border-[#252119] rounded-xl py-3.5"
      >
        <TikTokIcon />
        <span className="text-[11px] text-[#a39a86] font-medium">TikTok</span>
      </a>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="#25D366">
      <path d="M17.6 6.32A8.86 8.86 0 0 0 12.05 4a8.94 8.94 0 0 0-7.65 13.62L3 21l3.5-1.34a8.9 8.9 0 0 0 4.83 1.43 8.94 8.94 0 0 0 6.27-15.77zm-5.55 13.4a7.4 7.4 0 0 1-3.78-1.04l-.27-.16-2.79 1.06.74-2.71-.18-.28a7.43 7.43 0 1 1 6.28 3.13z" />
    </svg>
  );
}

function TikTokIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="#f5f1e8">
      <path d="M16.6 5.82A4.28 4.28 0 0 1 15.55 3h-3.1v12.3a2.6 2.6 0 1 1-1.84-2.49V9.7a5.8 5.8 0 1 0 5 5.74V9.4a7.3 7.3 0 0 0 4.27 1.37V7.6a4.27 4.27 0 0 1-3.28-1.78z" />
    </svg>
  );
}

export function TrustBanner() {
  const items = [
    { icon: <Award size={16} />, label: 'Mécanicien diplômé' },
    { icon: <ShieldCheck size={16} />, label: 'Satisfait ou remboursé' },
    { icon: <Wrench size={16} />, label: 'Préco. constructeur' },
    { icon: <Eye size={16} />, label: 'Devis transparent' },
  ];
  return (
    <div className="grid grid-cols-2 gap-2.5">
      {items.map((it) => (
        <div key={it.label} className="flex items-center gap-2 bg-[#16140f] border border-[#252119] rounded-xl px-3 py-3">
          <span className="text-[#e3b341] shrink-0">{it.icon}</span>
          <span className="text-[11.5px] text-[#a39a86] font-medium leading-tight">{it.label}</span>
        </div>
      ))}
    </div>
  );
}
