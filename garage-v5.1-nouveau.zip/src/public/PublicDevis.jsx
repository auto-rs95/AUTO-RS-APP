import React, { useState } from 'react';
import { ChevronLeft, AlertTriangle, Wrench, Check, ImagePlus, X } from 'lucide-react';
import { PublicAPI } from '../supabaseApi.js';
import { CATEGORIES_PANNE, CATEGORIES_ENTRETIEN, estimateEntretienTotal, formatEUR } from '../data.js';
import AddressAutocomplete from './AddressAutocomplete.jsx';

const STEPS = ['categorie', 'selection', 'vehicule', 'estimation', 'coordonnees'];

export default function PublicDevis({ onBack }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [sent, setSent] = useState(false);

  const [categorie, setCategorie] = useState(null); // 'panne' | 'entretien'
  const [selected, setSelected] = useState([]);
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState([]);
  const [adresse, setAdresse] = useState('');
  const [plaque, setPlaque] = useState('');
  const [marque, setMarque] = useState('');
  const [modele, setModele] = useState('');
  const [moteur, setMoteur] = useState('');
  const [annee, setAnnee] = useState('');
  const [kilometrage, setKilometrage] = useState('');
  const [clientNom, setClientNom] = useState('');
  const [clientTelephone, setClientTelephone] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (sent) return <ConfirmationScreen onBack={onBack} />;

  function chooseCategorie(c) {
    setCategorie(c);
    setStepIndex(1);
  }

  function toggleOption(opt) {
    setSelected((prev) => (prev.includes(opt) ? prev.filter((x) => x !== opt) : [...prev, opt]));
  }

  function handlePhotos(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    Promise.all(
      files.map(
        (f) =>
          new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.readAsDataURL(f);
          })
      )
    ).then((urls) => setPhotos((prev) => [...prev, ...urls]));
    e.target.value = '';
  }

  function removePhoto(idx) {
    setPhotos(photos.filter((_, i) => i !== idx));
  }

  function goNext() {
    // Pour "panne", pas d'étape estimation (pas de prix indicatif fiable sans diagnostic).
    if (categorie === 'panne' && STEPS[stepIndex + 1] === 'estimation') {
      setStepIndex(stepIndex + 2);
    } else {
      setStepIndex(stepIndex + 1);
    }
  }

  function goBack() {
    if (stepIndex === 0) {
      onBack();
      return;
    }
    if (categorie === 'panne' && STEPS[stepIndex - 1] === 'estimation') {
      setStepIndex(stepIndex - 2);
    } else {
      setStepIndex(stepIndex - 1);
    }
  }

  async function handleSubmit() {
    if (!clientNom.trim() || !clientTelephone.trim()) return;
    setSubmitting(true);
    const estimation = categorie === 'entretien' ? estimateEntretienTotal(selected) : null;
    await PublicAPI.submitQuoteRequest({
      clientNom: clientNom.trim(),
      clientTelephone: clientTelephone.trim(),
      clientEmail: clientEmail.trim(),
      plaque: plaque.trim().toUpperCase(),
      vehiculeMarque: marque.trim(),
      vehiculeModele: modele.trim(),
      kilometrage: kilometrage === '' ? null : Number(kilometrage),
      categoriePanne: selected,
      descriptionLibre: [
        description.trim(),
        adresse ? `Adresse : ${adresse}` : '',
        moteur ? `Moteur : ${moteur}` : '',
        annee ? `Année : ${annee}` : '',
        estimation ? `Estimation indicative : ${formatEUR(estimation)}` : '',
      ].filter(Boolean).join('\n'),
      photos,
      type: 'prestationMecanique',
      lignes: [],
    });
    setSubmitting(false);
    setSent(true);
  }

  const step = STEPS[stepIndex];
  const accent = categorie === 'panne' ? '#d97a6c' : '#7fc28a';
  const options = categorie === 'panne' ? CATEGORIES_PANNE : CATEGORIES_ENTRETIEN;
  const estimation = categorie === 'entretien' ? estimateEntretienTotal(selected) : 0;

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={goBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>Demande de devis</h1>
      </div>

      {step !== 'categorie' && (
        <div className="max-w-2xl mx-auto px-6 mb-6">
          <div className="flex gap-1.5">
            {STEPS.filter((s) => !(categorie === 'panne' && s === 'estimation')).map((s) => (
              <div key={s} className="flex-1 h-1 rounded-full" style={{ backgroundColor: STEPS.indexOf(s) <= stepIndex ? accent : '#252119' }} />
            ))}
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto px-6 space-y-5">
        {step === 'categorie' && (
          <>
            <p className="text-[#8a8478] text-sm mb-2">Quel est votre besoin ?</p>
            <CategorieOption icon={<AlertTriangle size={22} />} title="Panne / Diagnostic" subtitle="Voyant, bruit, fumée, perte de puissance…" accent="#d97a6c" onClick={() => chooseCategorie('panne')} />
            <CategorieOption icon={<Wrench size={22} />} title="Entretien" subtitle="Vidange, filtres, plaquettes, distribution…" accent="#7fc28a" onClick={() => chooseCategorie('entretien')} />
          </>
        )}

        {step === 'selection' && (
          <>
            <Field label="Sélectionnez ce qui s'applique">
              <div className="space-y-2">
                {options.map((opt) => {
                  const optId = typeof opt === 'string' ? opt : opt.id;
                  const optLabel = typeof opt === 'string' ? opt : opt.label;
                  const active = selected.includes(optId);
                  return (
                    <button
                      key={optId}
                      onClick={() => toggleOption(optId)}
                      className="w-full flex items-center gap-3 p-3.5 rounded-xl border text-left transition-colors"
                      style={active ? { backgroundColor: `${accent}1a`, borderColor: accent, color: '#f5f1e8' } : { borderColor: '#252119', color: '#8a8478', backgroundColor: '#16140f' }}
                    >
                      <span className="text-sm font-medium flex-1">{optLabel}</span>
                      {active && <Check size={16} style={{ color: accent }} />}
                    </button>
                  );
                })}
              </div>
            </Field>

            {categorie === 'entretien' && (
              <Field label="Adresse d'intervention">
                <AddressAutocomplete value={adresse} onChange={setAdresse} placeholder="Adresse complète" className="input" />
              </Field>
            )}

            <Field label="Description libre">
              <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} className="input resize-none" placeholder="Détaillez votre besoin…" />
            </Field>

            <div>
              <label className="block text-xs font-medium text-[#8a8478] mb-1.5">Photos / vidéos (optionnel)</label>
              {photos.length > 0 && (
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {photos.map((p, i) => (
                    <div key={i} className="relative aspect-square rounded-lg overflow-hidden bg-[#16140f] border border-[#252119]">
                      <img src={p} alt="" className="w-full h-full object-cover" />
                      <button onClick={() => removePhoto(i)} className="absolute top-1 right-1 bg-black/60 rounded-full p-1 text-white">
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <label className="w-full flex items-center justify-center gap-2 bg-[#16140f] border border-dashed border-[#252119] text-[#8a8478] font-medium rounded-xl py-3.5 cursor-pointer">
                <ImagePlus size={16} /> Ajouter des photos
                <input type="file" accept="image/*" multiple capture="environment" className="hidden" onChange={handlePhotos} />
              </label>
            </div>

            <NextButton onClick={goNext} disabled={selected.length === 0} accent={accent} />
          </>
        )}

        {step === 'vehicule' && (
          <>
            <Field label="Plaque d'immatriculation">
              <input value={plaque} onChange={(e) => setPlaque(e.target.value)} placeholder="AB-123-CD" className="input font-mono" autoFocus />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Marque">
                <input value={marque} onChange={(e) => setMarque(e.target.value)} placeholder="Renault" className="input" />
              </Field>
              <Field label="Modèle">
                <input value={modele} onChange={(e) => setModele(e.target.value)} placeholder="Clio" className="input" />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Motorisation">
                <input value={moteur} onChange={(e) => setMoteur(e.target.value)} placeholder="1.5 dCi" className="input" />
              </Field>
              <Field label="Année">
                <input type="number" value={annee} onChange={(e) => setAnnee(e.target.value)} placeholder="2018" className="input font-mono" />
              </Field>
            </div>
            <Field label="Kilométrage">
              <input type="number" value={kilometrage} onChange={(e) => setKilometrage(e.target.value)} placeholder="85000" className="input font-mono" />
            </Field>
            <NextButton onClick={goNext} accent={accent} />
          </>
        )}

        {step === 'estimation' && (
          <>
            <div className="bg-[#16140f] border border-[#252119] rounded-2xl p-6 text-center">
              <p className="text-[#8a8478] text-xs uppercase tracking-wide font-bold mb-2">Estimation indicative</p>
              <p className="text-[#e3b341] text-4xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{formatEUR(estimation)}</p>
              <p className="text-[#5a5448] text-[12px] mt-3">Basée sur les éléments sélectionnés. Le tarif définitif sera confirmé après inspection.</p>
            </div>
            <NextButton onClick={goNext} accent={accent} label="Continuer" />
          </>
        )}

        {step === 'coordonnees' && (
          <>
            <Field label="Votre nom *">
              <input value={clientNom} onChange={(e) => setClientNom(e.target.value)} placeholder="Jean Dupont" className="input" autoFocus />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Téléphone *">
                <input value={clientTelephone} onChange={(e) => setClientTelephone(e.target.value)} placeholder="06 12 34 56 78" className="input font-mono" />
              </Field>
              <Field label="Email">
                <input type="email" value={clientEmail} onChange={(e) => setClientEmail(e.target.value)} placeholder="email@exemple.com" className="input" />
              </Field>
            </div>
            <button
              onClick={handleSubmit}
              disabled={!clientNom.trim() || !clientTelephone.trim() || submitting}
              className="w-full flex items-center justify-center gap-2 text-[#0c0c0b] font-bold rounded-xl py-3.5 disabled:opacity-40"
              style={{ backgroundColor: accent }}
            >
              {submitting ? 'Envoi…' : 'Recevoir mon devis'}
            </button>
          </>
        )}
      </div>

      <GlobalStyles />
    </div>
  );
}

function CategorieOption({ icon, title, subtitle, accent, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-4 bg-[#16140f] border border-[#252119] rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${accent}1a`, color: accent }}>
        {icon}
      </div>
      <div>
        <h3 className="text-[#f5f1e8] text-base font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{title}</h3>
        <p className="text-[12.5px] text-[#8a8478] mt-0.5">{subtitle}</p>
      </div>
    </button>
  );
}

function NextButton({ onClick, disabled, accent, label = 'Continuer' }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full text-[#0c0c0b] font-bold rounded-xl py-3.5 disabled:opacity-40"
      style={{ backgroundColor: accent }}
    >
      {label}
    </button>
  );
}

function ConfirmationScreen({ onBack }) {
  return (
    <div className="min-h-screen bg-[#0c0c0b] flex flex-col items-center justify-center px-6 text-center">
      <div className="w-16 h-16 rounded-full bg-[#7fc28a]/15 flex items-center justify-center mb-5">
        <Check size={28} className="text-[#7fc28a]" />
      </div>
      <h1 className="text-[#f5f1e8] text-2xl font-bold mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>Demande envoyée</h1>
      <p className="text-[#8a8478] text-sm max-w-xs">Votre demande de devis a bien été transmise. Vous serez recontacté rapidement.</p>
      <button onClick={onBack} className="mt-8 text-[#e3b341] text-sm font-semibold">Retour à l'accueil</button>
      <GlobalStyles />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function GlobalStyles() {
  return (
    <style>{`
      .input { width: 100%; background: #16140f; border: 1px solid #252119; border-radius: 10px; padding: 11px 13px; color: #f5f1e8; font-size: 14.5px; outline: none; }
      .input:focus { border-color: #e3b341; }
      .input::placeholder { color: #5a5448; }
    `}</style>
  );
}
