import React, { useState, useEffect } from 'react';
import { ChevronLeft, Images } from 'lucide-react';
import { GalleryAPI } from '../supabaseApi.js';
import AutoSlideshow from './AutoSlideshow.jsx';

export default function PublicGallery({ onBack }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    GalleryAPI.listPublic().then((g) => {
      setItems(g);
      setLoading(false);
    });
  }, []);

  const photos = items.map((g) => g.photo);

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>Nos réalisations</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6">
        {loading ? (
          <p className="text-[#5a5448] text-sm text-center py-10">Chargement…</p>
        ) : photos.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
              <Images size={20} className="text-[#3a342a]" />
            </div>
            <p className="text-[#8a8478] text-sm">Aucune photo pour l'instant.</p>
          </div>
        ) : (
          <>
            <AutoSlideshow photos={photos} className="w-full h-64 rounded-2xl mb-6 border border-[#252119]" />
            <div className="grid grid-cols-2 gap-2.5">
              {items.map((g) => (
                <div key={g.id} className="rounded-xl overflow-hidden border border-[#252119]">
                  <img src={g.photo} alt={g.legende || ''} className="w-full h-36 object-cover" />
                  {g.legende && <p className="text-[11px] text-[#8a8478] px-2.5 py-2 bg-[#16140f]">{g.legende}</p>}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
