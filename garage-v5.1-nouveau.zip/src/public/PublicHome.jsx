import React from 'react';
import { Calendar, FileText, Car, Coffee, Laptop, Users, Tv, UtensilsCrossed, Moon, Images, Info } from 'lucide-react';
import { TrustBanner, ContactButtons } from './ContactWidgets.jsx';

const ACTIVITES = [
  { icon: <Coffee size={20} />, label: 'Café' },
  { icon: <Laptop size={20} />, label: 'Travail' },
  { icon: <Users size={20} />, label: 'Famille' },
  { icon: <Tv size={20} />, label: 'Série' },
  { icon: <UtensilsCrossed size={20} />, label: 'Repas' },
  { icon: <Moon size={20} />, label: 'Sieste' },
];

export default function PublicHome({ onNavigate }) {
  return (
    <div className="min-h-screen bg-[#0c0c0b]">
      {/* ---------- HERO ---------- */}
      <div className="relative overflow-hidden">
        {/* Chevrons façon carrosserie en fond */}
        <div className="absolute inset-0 opacity-[0.06] pointer-events-none" style={{
          backgroundImage: 'repeating-linear-gradient(135deg, #e3b341 0px, #e3b341 2px, transparent 2px, transparent 40px)',
        }} />
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#e3b341] opacity-[0.07] rounded-full blur-3xl -translate-y-1/3 translate-x-1/3" />
        <div className="absolute -right-16 top-8 opacity-[0.08] pointer-events-none">
          <svg width="220" height="220" viewBox="0 0 100 100" className="animate-[spin_8s_linear_infinite]">
            <circle cx="50" cy="50" r="42" fill="none" stroke="#e3b341" strokeWidth="3" />
            <circle cx="50" cy="50" r="10" fill="none" stroke="#e3b341" strokeWidth="3" />
            {[...Array(8)].map((_, i) => {
              const angle = (i * Math.PI) / 4;
              const x1 = 50 + 14 * Math.cos(angle);
              const y1 = 50 + 14 * Math.sin(angle);
              const x2 = 50 + 40 * Math.cos(angle);
              const y2 = 50 + 40 * Math.sin(angle);
              return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#e3b341" strokeWidth="3" />;
            })}
          </svg>
        </div>

        <div className="relative max-w-2xl mx-auto px-6 pt-16 pb-14">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#e3b341] to-[#9a6f1f] flex items-center justify-center shadow-lg shadow-black/40">
              <span className="text-[#0c0c0b] text-base font-black tracking-tighter" style={{ fontFamily: "'Oswald', sans-serif" }}>RS</span>
            </div>
            <div>
              <p className="text-[#f5f1e8] text-sm font-bold leading-none tracking-tight">AUTO RS</p>
              <p className="text-[9px] text-[#8a7a4a] uppercase tracking-[0.2em] font-semibold mt-0.5">Multi Services</p>
            </div>
          </div>

          <p className="text-[#e3b341] text-[11px] uppercase tracking-[0.25em] font-bold mb-4">Garage mobile</p>
          <h1
            className="text-[#f5f1e8] leading-[0.95] mb-5"
            style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 700, fontSize: 'clamp(2.6rem, 9vw, 3.4rem)', letterSpacing: '-0.02em' }}
          >
            VOTRE GARAGE<br />VIENT À<br /><span className="text-[#e3b341]">VOUS.</span>
          </h1>
          <p className="text-[#a39a86] text-[15px] max-w-sm leading-relaxed">
            Entretien, diagnostic, réparation — directement chez vous ou sur votre lieu de travail. À Argenteuil et ses environs.
          </p>
        </div>
      </div>

      {/* ---------- 3 ACTIONS ---------- */}
      <div className="max-w-2xl mx-auto px-6 -mt-2 pb-4 space-y-2.5">
        <ActionRow icon={<Calendar size={19} />} title="Prendre rendez-vous" subtitle="Réparation, entretien, visite avant achat" onClick={() => onNavigate('rdv')} primary />
        <ActionRow icon={<FileText size={19} />} title="Demande de devis" subtitle="Panne ou entretien — réponse rapide" onClick={() => onNavigate('devis')} />
        <ActionRow icon={<Car size={19} />} title="Véhicules en vente" subtitle="Occasions vérifiées par nos soins" onClick={() => onNavigate('vehicules')} />
      </div>

      {/* ---------- TEMPS CLIENT ---------- */}
      <div className="max-w-2xl mx-auto px-6 pt-20 pb-2">
        <div className="h-px bg-gradient-to-r from-transparent via-[#2a2620] to-transparent mb-14" />
        <p className="text-[#e3b341] text-[11px] uppercase tracking-[0.25em] font-bold text-center mb-3">Pendant l'intervention</p>
        <h2
          className="text-[#f5f1e8] text-center leading-tight mb-10"
          style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600, fontSize: 'clamp(1.5rem, 5vw, 1.9rem)' }}
        >
          Et vous, que ferez-vous<br />de votre temps ?
        </h2>
      </div>

      <div className="max-w-2xl mx-auto px-6">
        <div className="grid grid-cols-3 gap-2.5">
          {ACTIVITES.map((a) => (
            <div key={a.label} className="bg-[#16140f] border border-[#252119] rounded-xl py-5 flex flex-col items-center gap-2">
              <span className="text-[#e3b341]">{a.icon}</span>
              <span className="text-[11px] text-[#a39a86] font-medium">{a.label}</span>
            </div>
          ))}
        </div>
        <p className="text-center text-[#f5f1e8] text-[15px] mt-8 leading-relaxed">
          Pendant ce temps,<br /><span className="text-[#e3b341] font-semibold">Auto RS s'occupe de votre véhicule.</span>
        </p>
      </div>

      {/* ---------- CONFIANCE ---------- */}
      <div className="max-w-2xl mx-auto px-6 pt-16">
        <div className="h-px bg-gradient-to-r from-transparent via-[#2a2620] to-transparent mb-8" />
        <TrustBanner />
      </div>

      {/* ---------- CONTACT ---------- */}
      <div className="max-w-2xl mx-auto px-6 pt-10">
        <p className="text-[#8a8478] text-[11px] uppercase tracking-[0.2em] font-bold text-center mb-3">Nous contacter</p>
        <ContactButtons />
      </div>

      {/* ---------- LIENS SECONDAIRES ---------- */}
      <div className="max-w-2xl mx-auto px-6 pt-12 pb-6">
        <div className="h-px bg-gradient-to-r from-transparent via-[#2a2620] to-transparent mb-6" />
        <div className="grid grid-cols-3 gap-2.5">
          <SecondaryLink icon={<FileText size={16} />} label="Tarifs" onClick={() => onNavigate('tarifs')} />
          <SecondaryLink icon={<Images size={16} />} label="Réalisations" onClick={() => onNavigate('galerie')} />
          <SecondaryLink icon={<Info size={16} />} label="À propos" onClick={() => onNavigate('apropos')} />
        </div>
      </div>

      <p className="text-center text-[10px] text-[#4a4438] pb-10 font-mono uppercase tracking-wider">
        Garage mobile · Argenteuil et environs
      </p>
    </div>
  );
}

function ActionRow({ icon, title, subtitle, onClick, primary }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 rounded-xl p-4 text-left active:scale-[0.98] transition-transform border ${
        primary ? 'bg-[#e3b341] border-[#e3b341]' : 'bg-[#16140f] border-[#252119]'
      }`}
    >
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${primary ? 'bg-[#0c0c0b]/15 text-[#0c0c0b]' : 'bg-[#1f1b13] text-[#e3b341]'}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <h3 className={`text-[15px] font-bold ${primary ? 'text-[#0c0c0b]' : 'text-[#f5f1e8]'}`}>{title}</h3>
        <p className={`text-[12px] mt-0.5 ${primary ? 'text-[#0c0c0b]/70' : 'text-[#8a8478]'}`}>{subtitle}</p>
      </div>
    </button>
  );
}

function SecondaryLink({ icon, label, onClick }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 py-3 text-[#8a8478]">
      {icon}
      <span className="text-[11px] font-medium">{label}</span>
    </button>
  );
}
