import React, { useState, useRef, useEffect } from 'react';
import { MapPin } from 'lucide-react';

// Autocomplétion d'adresse via l'API officielle française (gratuite, sans clé).
export default function AddressAutocomplete({ value, onChange, placeholder, className }) {
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const debounceRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(e) {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, []);

  function handleInputChange(e) {
    const val = e.target.value;
    onChange(val);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (val.trim().length < 3) {
      setSuggestions([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`https://api-adresse.data.gouv.fr/search/?q=${encodeURIComponent(val)}&limit=5`);
        if (!res.ok) return;
        const json = await res.json();
        setSuggestions(json.features || []);
        setShowSuggestions(true);
      } catch (e) {
        setSuggestions([]);
      }
    }, 300);
  }

  function selectSuggestion(feature) {
    onChange(feature.properties.label);
    setSuggestions([]);
    setShowSuggestions(false);
  }

  return (
    <div ref={containerRef} className="relative">
      <input
        value={value}
        onChange={handleInputChange}
        onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
        placeholder={placeholder}
        className={className}
        autoComplete="off"
      />
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute z-20 left-0 right-0 mt-1 bg-[#16140f] border border-[#2a2620] rounded-xl overflow-hidden shadow-xl shadow-black/40">
          {suggestions.map((f) => (
            <button
              key={f.properties.id}
              onClick={() => selectSuggestion(f)}
              className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-left hover:bg-[#1f1b13] border-b border-[#2a2620] last:border-b-0"
            >
              <MapPin size={13} className="text-[#e3b341] shrink-0" />
              <span className="text-[13px] text-[#e0dcd2] truncate">{f.properties.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
