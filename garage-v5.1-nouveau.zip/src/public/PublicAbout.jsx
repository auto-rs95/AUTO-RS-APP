import React, { useState, useEffect } from 'react';
import { ChevronLeft, Award, ShieldCheck, Eye, Wrench, RefreshCcw } from 'lucide-react';
import { CompanyAPI } from '../supabaseApi.js';
import { DEFAULT_COMPANY } from '../data.js';

const ARGUMENTS = [
  { icon: <Award size={18} />, title: 'Mécanicien diplômé', desc: 'Formation certifiée et expérience confirmée sur tous types de véhicules.' },
  { icon: <ShieldCheck size={18} />, title: 'Travail garanti', desc: "Satisfait ou remboursé sur chaque intervention réalisée." },
  { icon: <Wrench size={18} />, title: 'Préconisations constructeur', desc: 'Pièces et procédures conformes aux recommandations officielles.' },
  { icon: <RefreshCcw size={18} />, title: 'Garantie +1 an', desc: "Toutes les interventions sont couvertes plus d'un an." },
  { icon: <Eye size={18} />, title: 'Transparence totale', desc: 'Devis clair avant toute intervention, aucune surprise.' },
];

export default function PublicAbout({ onBack }) {
  const [texte, setTexte] = useState(DEFAULT_COMPANY.aProposTexte);

  useEffect(() => {
    CompanyAPI.get().then((c) => {
      if (c?.aProposTexte) setTexte(c.aProposTexte);
    });
  }, []);

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>À propos</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6 space-y-8">
        <p className="text-[#c4bfb2] text-[15px] leading-relaxed whitespace-pre-line">{texte}</p>

        <div className="space-y-2.5">
          {ARGUMENTS.map((a) => (
            <div key={a.title} className="flex items-start gap-3.5 bg-[#16140f] border border-[#252119] rounded-xl p-4">
              <div className="w-9 h-9 rounded-lg bg-[#1f1b13] text-[#e3b341] flex items-center justify-center shrink-0">
                {a.icon}
              </div>
              <div>
                <h3 className="text-[#f5f1e8] text-sm font-bold">{a.title}</h3>
                <p className="text-[#8a8478] text-[12.5px] mt-0.5 leading-relaxed">{a.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
