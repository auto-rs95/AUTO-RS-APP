import React, { useState, useEffect } from 'react';
import { ChevronLeft, Gauge, Fuel, Settings2, Car, Lock } from 'lucide-react';
import { PublicAPI } from '../supabaseApi.js';
import { formatEUR, formatKm, vehiclePhotoPrincipale, statutVenteInfo } from '../data.js';
import AutoSlideshow from './AutoSlideshow.jsx';
import { ContactButtons } from './ContactWidgets.jsx';

export default function PublicVehicles({ onBack }) {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    PublicAPI.listPublishedVehicles().then((v) => {
      setVehicles(v);
      setLoading(false);
    });
  }, []);

  if (selected) {
    return <VehicleDetailPublic vehicle={selected} onBack={() => setSelected(null)} />;
  }

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>Véhicules en vente</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6 space-y-3">
        {loading ? (
          <p className="text-[#5a5448] text-sm text-center py-10">Chargement…</p>
        ) : vehicles.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-full bg-[#16140f] flex items-center justify-center mx-auto mb-4">
              <Car size={20} className="text-[#3a342a]" />
            </div>
            <p className="text-[#8a8478] text-sm">Aucun véhicule disponible pour le moment.</p>
          </div>
        ) : (
          vehicles.map((v) => {
            const photo = vehiclePhotoPrincipale(v);
            const statut = statutVenteInfo(v.statutVente);
            const isVendu = v.statutVente === 'vendu';
            return (
              <button
                key={v.id}
                onClick={() => !isVendu && setSelected(v)}
                disabled={isVendu}
                className={`w-full text-left bg-[#16140f] border border-[#252119] rounded-2xl overflow-hidden transition-transform ${
                  isVendu ? 'opacity-60 cursor-default' : 'active:scale-[0.98]'
                }`}
              >
                <div className="relative">
                  {photo ? (
                    <img src={photo} alt="" className={`w-full h-44 object-cover ${isVendu ? 'grayscale' : ''}`} />
                  ) : (
                    <div className="w-full h-44 bg-[#1c1a14] flex items-center justify-center">
                      <Car size={32} className="text-[#3a342a]" />
                    </div>
                  )}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-sm rounded-full px-2.5 py-1">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: statut.color }} />
                    <span className="text-[11px] text-white font-medium">{statut.label}</span>
                  </div>
                  {isVendu && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Lock size={24} className="text-white/70" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-[#f5f1e8] text-lg font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{v.marque} {v.modele}</h3>
                    {v.prixVente != null && v.prixVente !== '' && (
                      <span className="font-mono text-base font-semibold text-[#e3b341]">{formatEUR(v.prixVente)}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-2 text-xs text-[#8a8478]">
                    <span className="flex items-center gap-1"><Gauge size={12} />{formatKm(v.kilometrage)}</span>
                    {v.carburant && <span className="flex items-center gap-1"><Fuel size={12} />{v.carburant}</span>}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}

function VehicleDetailPublic({ vehicle, onBack }) {
  const photos = vehicle.photos || [];
  const statut = statutVenteInfo(vehicle.statutVente);

  const details = [
    ['Marque', vehicle.marque || '—'],
    ['Modèle', vehicle.modele || '—'],
    ['Kilométrage', formatKm(vehicle.kilometrage)],
    ['Carburant', vehicle.carburant || '—'],
    ['Boîte', vehicle.boite || '—'],
    ['Plaque', vehicle.plaque || '—'],
  ];

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{vehicle.marque} {vehicle.modele}</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6 space-y-5">
        {photos.length > 0 ? (
          <AutoSlideshow photos={photos} intervalMs={3500} className="w-full h-56 rounded-2xl border border-[#252119]" />
        ) : (
          <div className="w-full h-48 bg-[#16140f] border border-[#252119] rounded-xl flex items-center justify-center">
            <Car size={32} className="text-[#3a342a]" />
          </div>
        )}

        <div className="flex items-center justify-between">
          {vehicle.prixVente != null && vehicle.prixVente !== '' && (
            <p className="text-[#e3b341] text-3xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{formatEUR(vehicle.prixVente)}</p>
          )}
          <span className="flex items-center gap-1.5 bg-[#16140f] border border-[#252119] rounded-full px-3 py-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: statut.color }} />
            <span className="text-[12px] text-[#e0dcd2] font-medium">{statut.label}</span>
          </span>
        </div>

        <div className="bg-[#16140f] border border-[#252119] rounded-2xl overflow-hidden">
          {details.map(([label, value], i) => (
            <div key={label} className={`flex items-center justify-between px-4 py-3 ${i % 2 === 1 ? 'bg-[#1a1814]' : ''}`}>
              <span className="text-[13px] text-[#8a8478]">{label}</span>
              <span className="text-[13.5px] text-[#f5f1e8] font-medium">{value}</span>
            </div>
          ))}
        </div>

        {vehicle.remarques && (
          <div>
            <h2 className="text-[#8a8478] text-xs uppercase tracking-wide font-bold mb-2">Description</h2>
            <div className="bg-[#16140f] border border-[#252119] rounded-xl p-4">
              <p className="text-sm text-[#c4bfb2] whitespace-pre-wrap leading-relaxed">{vehicle.remarques}</p>
            </div>
          </div>
        )}

        <div>
          <h2 className="text-[#8a8478] text-xs uppercase tracking-wide font-bold mb-2">Nous contacter au sujet de ce véhicule</h2>
          <ContactButtons context={`${vehicle.marque} ${vehicle.modele}`} />
        </div>
      </div>
    </div>
  );
}
