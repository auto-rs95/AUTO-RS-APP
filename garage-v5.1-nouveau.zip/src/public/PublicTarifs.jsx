import React from 'react';
import { ChevronLeft, Wrench, Disc, Snowflake, Cog, ShieldCheck } from 'lucide-react';

const CATEGORIES = [
  {
    icon: <Wrench size={18} />,
    titre: 'Entretien',
    accent: '#e3b341',
    items: [
      ['Vidange + filtre à huile', 'à partir de 60 €'],
      ['Filtre à air / habitacle', 'à partir de 25 €'],
      ['Révision complète', 'à partir de 120 €'],
      ['Nettoyage filtre à particules', 'à partir de 150 €'],
    ],
  },
  {
    icon: <Disc size={18} />,
    titre: 'Freinage',
    accent: '#5b9bd5',
    items: [
      ['Plaquettes avant (jeu)', 'à partir de 90 €'],
      ['Plaquettes + disques avant', 'à partir de 180 €'],
      ['Plaquettes arrière (jeu)', 'à partir de 80 €'],
      ['Plaquettes + disques arrière', 'à partir de 160 €'],
    ],
  },
  {
    icon: <Snowflake size={18} />,
    titre: 'Climatisation',
    accent: '#7fc28a',
    items: [
      ['Recharge clim', 'à partir de 70 €'],
      ['Diagnostic clim', 'à partir de 40 €'],
    ],
  },
  {
    icon: <Cog size={18} />,
    titre: 'Distribution & accessoires',
    accent: '#c98bd6',
    items: [
      ['Kit distribution + pose', 'à partir de 350 €'],
      ["Courroie d'accessoires", 'à partir de 90 €'],
      ['Diagnostic courroie/chaîne', 'à partir de 40 €'],
    ],
  },
];

export default function PublicTarifs({ onBack }) {
  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>Nos tarifs</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6">
        <p className="text-[#8a8478] text-sm mb-3">
          Tarifs indicatifs "à partir de", hors pièces spécifiques. Un devis précis et gratuit est établi avant toute intervention.
        </p>

        <div className="flex items-center gap-2 bg-[#16140f] border border-[#252119] rounded-xl px-3.5 py-3 mb-6">
          <ShieldCheck size={16} className="text-[#7fc28a] shrink-0" />
          <p className="text-[12px] text-[#c4bfb2]">
            Travail selon préconisations constructeur · Garantie pièces et main d'œuvre +1 an
          </p>
        </div>

        <div className="space-y-4">
          {CATEGORIES.map((cat) => (
            <div key={cat.titre} className="bg-[#16140f] border border-[#252119] rounded-2xl p-5" style={{ borderLeftWidth: '3px', borderLeftColor: cat.accent }}>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${cat.accent}1a`, color: cat.accent }}>
                  {cat.icon}
                </div>
                <h2 className="text-[#f5f1e8] text-base font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{cat.titre}</h2>
              </div>
              <div className="space-y-2.5">
                {cat.items.map(([label, prix]) => (
                  <div key={label} className="flex items-center justify-between">
                    <span className="text-[13.5px] text-[#c4bfb2]">{label}</span>
                    <span className="font-mono text-sm font-semibold text-[#f5f1e8]">{prix}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#1c1a14] border border-[#252119] rounded-xl p-4 mt-6">
          <p className="text-[12px] text-[#8a8478]">
            Déplacement : 7 km offerts depuis Argenteuil, puis 2€/km. Le montant exact est calculé et affiché avant toute validation de rendez-vous.
          </p>
        </div>
      </div>
    </div>
  );
}
