import React, { useState, useEffect } from 'react';

export default function AutoSlideshow({ photos, intervalMs = 2500, className }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (photos.length <= 1) return;
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % photos.length);
    }, intervalMs);
    return () => clearInterval(timer);
  }, [photos.length, intervalMs]);

  if (photos.length === 0) return null;

  return (
    <div className={`relative overflow-hidden ${className || ''}`}>
      {photos.map((p, i) => (
        <img
          key={i}
          src={p}
          alt=""
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-1000"
          style={{ opacity: i === index ? 1 : 0 }}
        />
      ))}
      {photos.length > 1 && (
        <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5">
          {photos.map((_, i) => (
            <span
              key={i}
              className="w-1.5 h-1.5 rounded-full transition-colors"
              style={{ backgroundColor: i === index ? '#e3b341' : 'rgba(255,255,255,0.3)' }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
