import React, { useState, useEffect } from 'react';
import { ChevronLeft, Wrench, Car, Check, MapPin, Loader2, Clock, CalendarX } from 'lucide-react';
import { PublicAPI, CompanyAPI, SlotsAPI } from '../supabaseApi.js';
import { geocodeAddress } from '../geocoding.js';
import { distanceKm, computeFraisDeplacement, formatEUR, formatDate, DEFAULT_COMPANY } from '../data.js';
import AddressAutocomplete from './AddressAutocomplete.jsx';

const SYMPTOMES = ['Voyant allumé', 'Fumée', 'Bruit anormal', 'Fuite', 'Ne démarre pas', 'Autre'];

export default function PublicRDV({ onBack }) {
  const [type, setType] = useState(null);
  const [sent, setSent] = useState(false);

  if (sent) return <ConfirmationScreen onBack={onBack} />;

  if (!type) {
    return (
      <div className="min-h-screen bg-[#0c0c0b] pb-12">
        <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
          <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
          <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>Prendre rendez-vous</h1>
        </div>
        <div className="max-w-2xl mx-auto px-6 space-y-3">
          <p className="text-[#8a8478] text-sm mb-2">Quel type de rendez-vous souhaitez-vous ?</p>
          <TypeOption icon={<Wrench size={22} />} title="Réparation / Entretien" subtitle="Diagnostic, panne, entretien courant" accent="#e3b341" onClick={() => setType('reparation')} />
          <TypeOption icon={<Car size={22} />} title="Visite avant achat" subtitle="Inspection d'un véhicule envisagé à l'achat" accent="#5b9bd5" onClick={() => setType('visite_achat')} />
        </div>
      </div>
    );
  }

  return <RDVForm type={type} onBack={() => setType(null)} onSent={() => setSent(true)} />;
}

function TypeOption({ icon, title, subtitle, accent, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-4 bg-[#16140f] border border-[#252119] rounded-2xl p-4 text-left active:scale-[0.98] transition-transform">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${accent}1a`, color: accent }}>{icon}</div>
      <div>
        <h3 className="text-[#f5f1e8] text-base font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{title}</h3>
        <p className="text-[12.5px] text-[#8a8478] mt-0.5">{subtitle}</p>
      </div>
    </button>
  );
}

function groupByDate(slots) {
  const groups = {};
  slots.forEach((s) => {
    if (!groups[s.date]) groups[s.date] = [];
    groups[s.date].push(s);
  });
  return groups;
}

function RDVForm({ type, onBack, onSent }) {
  const [vehiculeInfo, setVehiculeInfo] = useState('');
  const [adresse, setAdresse] = useState('');
  const [voitureAVisiter, setVoitureAVisiter] = useState('');
  const [symptomes, setSymptomes] = useState([]);
  const [clientNom, setClientNom] = useState('');
  const [clientTelephone, setClientTelephone] = useState('');
  const [notes, setNotes] = useState('');

  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(true);
  const [selectedSlotId, setSelectedSlotId] = useState(null);

  const [frais, setFrais] = useState(null);
  const [calculating, setCalculating] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    SlotsAPI.listPublicFuture().then((s) => {
      setSlots(s.filter((slot) => !slot.reserve));
      setLoadingSlots(false);
    });
  }, []);

  function toggleSymptome(s) {
    setSymptomes((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  }

  async function handleAdresseChange(val) {
    setAdresse(val);
  }

  async function computeDistance() {
    if (!adresse.trim()) {
      setFrais(null);
      return;
    }
    setCalculating(true);
    try {
      const company = (await CompanyAPI.get()) || DEFAULT_COMPANY;
      const baseAdresse = company.adresseBase || 'Argenteuil';
      const [baseCoords, clientCoords] = await Promise.all([
        geocodeAddress(baseAdresse + ', France'),
        geocodeAddress(adresse + ', France'),
      ]);
      if (baseCoords && clientCoords) {
        const dist = distanceKm(baseCoords.lat, baseCoords.lon, clientCoords.lat, clientCoords.lon);
        setFrais(computeFraisDeplacement(dist, company));
      } else {
        setFrais(null);
      }
    } catch (e) {
      setFrais(null);
    }
    setCalculating(false);
  }

  const selectedSlot = slots.find((s) => s.id === selectedSlotId);
  const grouped = groupByDate(slots);
  const dateKeys = Object.keys(grouped).sort();

  async function handleSubmit() {
    if (!clientNom.trim() || !clientTelephone.trim() || !adresse.trim() || !selectedSlotId) return;
    setSubmitting(true);

    const reserved = await SlotsAPI.reserve(selectedSlotId, clientNom.trim(), clientTelephone.trim());
    if (!reserved) {
      setSubmitting(false);
      alert('Ce créneau vient d\'être réservé par quelqu\'un d\'autre. Merci d\'en choisir un autre.');
      const fresh = await SlotsAPI.listPublicFuture();
      setSlots(fresh.filter((s) => !s.reserve));
      setSelectedSlotId(null);
      return;
    }

    await PublicAPI.submitAppointment({
      date: selectedSlot.date,
      heure: selectedSlot.heure,
      clientNom: clientNom.trim(),
      clientTelephone: clientTelephone.trim(),
      adresse: adresse.trim(),
      vehiculeInfo: type === 'reparation' ? vehiculeInfo.trim() : voitureAVisiter.trim(),
      typePrestation: type === 'reparation' ? 'Réparation / Entretien' : 'Visite avant achat',
      notes: notes.trim(),
      typeDemande: type,
      symptomes,
      distanceKm: frais?.distance ?? null,
      fraisDeplacement: frais?.montant ?? null,
      statut: 'prevu',
    });
    setSubmitting(false);
    onSent();
  }

  const isReparation = type === 'reparation';

  return (
    <div className="min-h-screen bg-[#0c0c0b] pb-12">
      <div className="max-w-2xl mx-auto px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-1 -ml-1 text-[#8a8478]"><ChevronLeft size={22} /></button>
        <h1 className="text-[#f5f1e8] text-xl font-bold" style={{ fontFamily: "'Oswald', sans-serif" }}>{isReparation ? 'Réparation / Entretien' : 'Visite avant achat'}</h1>
      </div>

      <div className="max-w-2xl mx-auto px-6 space-y-5">
        {isReparation ? (
          <Field label="Véhicule concerné">
            <input value={vehiculeInfo} onChange={(e) => setVehiculeInfo(e.target.value)} placeholder="Marque, modèle, plaque…" className="input" autoFocus />
          </Field>
        ) : (
          <Field label="Voiture à visiter">
            <input value={voitureAVisiter} onChange={(e) => setVoitureAVisiter(e.target.value)} placeholder="Marque, modèle, adresse du vendeur…" className="input" autoFocus />
          </Field>
        )}

        <Field label="Adresse du rendez-vous *">
          <AddressAutocomplete value={adresse} onChange={handleAdresseChange} placeholder="Adresse complète" className="input" />
          <button onClick={computeDistance} className="text-[11px] text-[#e3b341] font-medium mt-1.5">
            {calculating ? 'Calcul en cours…' : 'Calculer les frais de déplacement'}
          </button>
        </Field>

        {frais && (
          <div className="bg-[#1c1a14] border border-[#252119] rounded-lg p-3.5 flex items-start gap-2.5">
            <MapPin size={15} className="text-[#e3b341] shrink-0 mt-0.5" />
            <div className="text-[12.5px] text-[#c4bfb2]">
              <p>Distance estimée : <span className="font-mono text-[#f5f1e8]">{frais.distance.toFixed(1)} km</span></p>
              <p className="mt-1">Frais de déplacement : <span className="font-mono font-semibold text-[#e3b341]">{frais.montant > 0 ? formatEUR(frais.montant) : 'Offert'}</span></p>
            </div>
          </div>
        )}

        <Field label="Choisissez un créneau disponible *">
          {loadingSlots ? (
            <p className="text-[#5a5448] text-sm">Chargement des créneaux…</p>
          ) : dateKeys.length === 0 ? (
            <div className="flex items-center gap-2.5 bg-[#16140f] border border-[#252119] rounded-xl p-4">
              <CalendarX size={18} className="text-[#5a5448]" />
              <p className="text-[#8a8478] text-sm">Aucun créneau disponible pour le moment. Contactez-nous directement.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {dateKeys.map((dateKey) => (
                <div key={dateKey}>
                  <p className="text-[#8a8478] text-[11px] uppercase tracking-wide font-bold mb-1.5">{formatDate(dateKey)}</p>
                  <div className="flex flex-wrap gap-2">
                    {grouped[dateKey].map((s) => (
                      <button
                        key={s.id}
                        onClick={() => setSelectedSlotId(s.id)}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-mono font-medium border"
                        style={selectedSlotId === s.id ? { backgroundColor: '#e3b341', borderColor: '#e3b341', color: '#0c0c0b' } : { borderColor: '#252119', color: '#c4bfb2', backgroundColor: '#16140f' }}
                      >
                        <Clock size={12} /> {s.heure}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Field>

        {isReparation && (
          <Field label="Symptômes observés">
            <div className="flex flex-wrap gap-2">
              {SYMPTOMES.map((s) => (
                <button key={s} onClick={() => toggleSymptome(s)} className={`px-3 py-1.5 rounded-full text-xs font-medium border ${symptomes.includes(s) ? 'bg-[#e3b341] text-[#0c0c0b] border-[#e3b341]' : 'text-[#8a8478] border-[#252119]'}`}>
                  {s}
                </button>
              ))}
            </div>
          </Field>
        )}

        <Field label="Votre nom *">
          <input value={clientNom} onChange={(e) => setClientNom(e.target.value)} placeholder="Jean Dupont" className="input" />
        </Field>

        <Field label="Votre téléphone *">
          <input value={clientTelephone} onChange={(e) => setClientTelephone(e.target.value)} placeholder="06 12 34 56 78" className="input font-mono" />
        </Field>

        <Field label="Précisions (optionnel)">
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} className="input resize-none" placeholder="Tout détail utile…" />
        </Field>

        <button
          onClick={handleSubmit}
          disabled={!clientNom.trim() || !clientTelephone.trim() || !adresse.trim() || !selectedSlotId || submitting}
          className="w-full flex items-center justify-center gap-2 bg-[#e3b341] disabled:bg-[#252119] disabled:text-[#5a5448] text-[#0c0c0b] font-bold rounded-xl py-3.5"
        >
          {submitting ? 'Envoi…' : 'Confirmer le rendez-vous'}
        </button>
      </div>

      <GlobalStyles />
    </div>
  );
}

function ConfirmationScreen({ onBack }) {
  return (
    <div className="min-h-screen bg-[#0c0c0b] flex flex-col items-center justify-center px-6 text-center">
      <div className="w-16 h-16 rounded-full bg-[#7fc28a]/15 flex items-center justify-center mb-5">
        <Check size={28} className="text-[#7fc28a]" />
      </div>
      <h1 className="text-[#f5f1e8] text-2xl font-bold mb-2" style={{ fontFamily: "'Oswald', sans-serif" }}>Rendez-vous confirmé</h1>
      <p className="text-[#8a8478] text-sm max-w-xs">Votre créneau est réservé. Vous recevrez un rappel avant l'intervention.</p>
      <button onClick={onBack} className="mt-8 text-[#e3b341] text-sm font-semibold">Retour à l'accueil</button>
      <GlobalStyles />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs font-medium text-[#8a8478] mb-1.5">{label}</label>
      {children}
    </div>
  );
}

function GlobalStyles() {
  return (
    <style>{`
      .input { width: 100%; background: #16140f; border: 1px solid #252119; border-radius: 10px; padding: 11px 13px; color: #f5f1e8; font-size: 14.5px; outline: none; }
      .input:focus { border-color: #e3b341; }
      .input::placeholder { color: #5a5448; }
    `}</style>
  );
}
