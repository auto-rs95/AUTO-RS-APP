import React, { useState } from 'react';
import PublicHome from './public/PublicHome.jsx';
import PublicVehicles from './public/PublicVehicles.jsx';
import PublicTarifs from './public/PublicTarifs.jsx';
import PublicRDV from './public/PublicRDV.jsx';
import PublicDevis from './public/PublicDevis.jsx';
import PublicGallery from './public/PublicGallery.jsx';
import PublicAbout from './public/PublicAbout.jsx';

export default function PublicSite() {
  const [route, setRoute] = useState('home');

  return (
    <div style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Oswald:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
        .font-display { font-family: 'Oswald', system-ui, sans-serif; font-weight: 600; letter-spacing: -0.01em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        body { background: #0c0c0b; }
        input[type="date"]::-webkit-calendar-picker-indicator,
        input[type="time"]::-webkit-calendar-picker-indicator { filter: invert(0.8); }
      `}</style>

      {route === 'home' && <PublicHome onNavigate={setRoute} />}
      {route === 'vehicules' && <PublicVehicles onBack={() => setRoute('home')} />}
      {route === 'tarifs' && <PublicTarifs onBack={() => setRoute('home')} />}
      {route === 'rdv' && <PublicRDV onBack={() => setRoute('home')} />}
      {route === 'devis' && <PublicDevis onBack={() => setRoute('home')} />}
      {route === 'galerie' && <PublicGallery onBack={() => setRoute('home')} />}
      {route === 'apropos' && <PublicAbout onBack={() => setRoute('home')} />}
    </div>
  );
}
